import { cookies } from 'next/headers';
import { supabase } from '@/lib/supabaseClient';

export async function withAuth() {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  return session;
}
