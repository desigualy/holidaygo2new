// middleware/withTracking.ts

export function trackIntent(action: string, meta: Record<string, any> = {}) {
  try {
    fetch('/api/recordUserIntent', {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ action, meta }),
    });
  } catch {
    // fail silently
  }
}
