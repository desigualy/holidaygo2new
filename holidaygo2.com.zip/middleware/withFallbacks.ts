// middleware/withFallbacks.ts

export function withFallbacks<T>(
  fn: () => Promise<T>,
  fallback: T
): Promise<T> {
  return fn().catch(() => fallback);
}
