// AccessibilityPreferences CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllAccessibilityPreferences() {
  const { data, error } = await supabase.from('accessibility_preferences').select('*');
  if (error) throw error;
  return data;
}

export async function getAccessibilityPreferencesById(id: string) {
  const { data, error } = await supabase.from('accessibility_preferences').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createAccessibilityPreferences(payload: any) {
  const { data, error } = await supabase.from('accessibility_preferences').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateAccessibilityPreferences(id: string, updates: any) {
  const { data, error } = await supabase.from('accessibility_preferences').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteAccessibilityPreferences(id: string) {
  const { error } = await supabase.from('accessibility_preferences').delete().eq('id', id);
  if (error) throw error;
}
