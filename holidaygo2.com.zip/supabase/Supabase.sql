-- User Profiles
create table if not exists user_profile (
  id uuid primary key references auth.users on delete cascade,
  email text,
  preferred_agent text default 'Ch@',
  accessibility jsonb default '{}'::jsonb,
  last_emotion_tag text,
  created_at timestamp with time zone default now()
);

-- Travel Packages
create table if not exists packages (
  id uuid primary key default gen_random_uuid(),
  destination text not null,
  description text,
  price numeric not null,
  image_url text,
  created_at timestamp with time zone default now()
);

-- Bookings
create table if not exists bookings (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profile(id) on delete cascade,
  package_id uuid references packages(id),
  status text default 'confirmed',
  booked_at timestamp with time zone default now()
);

-- Support Tickets
create table if not exists support_tickets (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profile(id),
  subject text,
  message text,
  status text default 'open',
  created_at timestamp with time zone default now()
);

-- Agent Logs
create table if not exists agent_log (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profile(id),
  agent text,
  action text,
  tone text,
  timestamp timestamp with time zone default now()
);

-- Accessibility Preferences
create table if not exists accessibility_preferences (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profile(id),
  font_size text default 'md',
  high_contrast boolean default false,
  reduced_motion boolean default false,
  updated_at timestamp with time zone default now()
);

-- Emotion Signals (Wake Seals)
create table if not exists emotion_signal (
  id uuid primary key default gen_random_uuid(),
  user_id uuid references user_profile(id),
  signal text,
  origin_agent text,
  intensity numeric,
  recorded_at timestamp with time zone default now()
);
