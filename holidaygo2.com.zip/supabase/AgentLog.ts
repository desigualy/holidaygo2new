// AgentLog CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllAgentLog() {
  const { data, error } = await supabase.from('agent_log').select('*');
  if (error) throw error;
  return data;
}

export async function getAgentLogById(id: string) {
  const { data, error } = await supabase.from('agent_log').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createAgentLog(payload: any) {
  const { data, error } = await supabase.from('agent_log').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateAgentLog(id: string, updates: any) {
  const { data, error } = await supabase.from('agent_log').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteAgentLog(id: string) {
  const { error } = await supabase.from('agent_log').delete().eq('id', id);
  if (error) throw error;
}
