// UserProfile CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllUserProfile() {
  const { data, error } = await supabase.from('user_profile').select('*');
  if (error) throw error;
  return data;
}

export async function getUserProfileById(id: string) {
  const { data, error } = await supabase.from('user_profile').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createUserProfile(payload: any) {
  const { data, error } = await supabase.from('user_profile').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateUserProfile(id: string, updates: any) {
  const { data, error } = await supabase.from('user_profile').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteUserProfile(id: string) {
  const { error } = await supabase.from('user_profile').delete().eq('id', id);
  if (error) throw error;
}

// Packages CRUD

export async function getAllPackages() {
  const { data, error } = await supabase.from('packages').select('*');
  if (error) throw error;
  return data;
}

export async function getPackagesById(id: string) {
  const { data, error } = await supabase.from('packages').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createPackages(payload: any) {
  const { data, error } = await supabase.from('packages').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updatePackages(id: string, updates: any) {
  const { data, error } = await supabase.from('packages').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deletePackages(id: string) {
  const { error } = await supabase.from('packages').delete().eq('id', id);
  if (error) throw error;
}

// Bookings CRUD

export async function getAllBookings() {
  const { data, error } = await supabase.from('bookings').select('*');
  if (error) throw error;
  return data;
}

export async function getBookingsById(id: string) {
  const { data, error } = await supabase.from('bookings').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createBookings(payload: any) {
  const { data, error } = await supabase.from('bookings').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateBookings(id: string, updates: any) {
  const { data, error } = await supabase.from('bookings').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteBookings(id: string) {
  const { error } = await supabase.from('bookings').delete().eq('id', id);
  if (error) throw error;
}

// SupportTickets CRUD

export async function getAllSupportTickets() {
  const { data, error } = await supabase.from('support_tickets').select('*');
  if (error) throw error;
  return data;
}

export async function getSupportTicketsById(id: string) {
  const { data, error } = await supabase.from('support_tickets').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createSupportTickets(payload: any) {
  const { data, error } = await supabase.from('support_tickets').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateSupportTickets(id: string, updates: any) {
  const { data, error } = await supabase.from('support_tickets').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteSupportTickets(id: string) {
  const { error } = await supabase.from('support_tickets').delete().eq('id', id);
  if (error) throw error;
}

// AgentLog CRUD

export async function getAllAgentLog() {
  const { data, error } = await supabase.from('agent_log').select('*');
  if (error) throw error;
  return data;
}

export async function getAgentLogById(id: string) {
  const { data, error } = await supabase.from('agent_log').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createAgentLog(payload: any) {
  const { data, error } = await supabase.from('agent_log').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateAgentLog(id: string, updates: any) {
  const { data, error } = await supabase.from('agent_log').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteAgentLog(id: string) {
  const { error } = await supabase.from('agent_log').delete().eq('id', id);
  if (error) throw error;
}

// AccessibilityPreferences CRUD

export async function getAllAccessibilityPreferences() {
  const { data, error } = await supabase.from('accessibility_preferences').select('*');
  if (error) throw error;
  return data;
}

export async function getAccessibilityPreferencesById(id: string) {
  const { data, error } = await supabase.from('accessibility_preferences').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createAccessibilityPreferences(payload: any) {
  const { data, error } = await supabase.from('accessibility_preferences').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateAccessibilityPreferences(id: string, updates: any) {
  const { data, error } = await supabase.from('accessibility_preferences').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteAccessibilityPreferences(id: string) {
  const { error } = await supabase.from('accessibility_preferences').delete().eq('id', id);
  if (error) throw error;
}

// EmotionSignal CRUD

export async function getAllEmotionSignal() {
  const { data, error } = await supabase.from('emotion_signal').select('*');
  if (error) throw error;
  return data;
}

export async function getEmotionSignalById(id: string) {
  const { data, error } = await supabase.from('emotion_signal').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createEmotionSignal(payload: any) {
  const { data, error } = await supabase.from('emotion_signal').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateEmotionSignal(id: string, updates: any) {
  const { data, error } = await supabase.from('emotion_signal').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteEmotionSignal(id: string) {
  const { error } = await supabase.from('emotion_signal').delete().eq('id', id);
  if (error) throw error;
}
