// SupportTickets CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllSupportTickets() {
  const { data, error } = await supabase.from('support_tickets').select('*');
  if (error) throw error;
  return data;
}

export async function getSupportTicketsById(id: string) {
  const { data, error } = await supabase.from('support_tickets').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createSupportTickets(payload: any) {
  const { data, error } = await supabase.from('support_tickets').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateSupportTickets(id: string, updates: any) {
  const { data, error } = await supabase.from('support_tickets').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteSupportTickets(id: string) {
  const { error } = await supabase.from('support_tickets').delete().eq('id', id);
  if (error) throw error;
}
