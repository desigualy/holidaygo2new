// EmotionSignal CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllEmotionSignal() {
  const { data, error } = await supabase.from('emotion_signal').select('*');
  if (error) throw error;
  return data;
}

export async function getEmotionSignalById(id: string) {
  const { data, error } = await supabase.from('emotion_signal').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createEmotionSignal(payload: any) {
  const { data, error } = await supabase.from('emotion_signal').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateEmotionSignal(id: string, updates: any) {
  const { data, error } = await supabase.from('emotion_signal').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteEmotionSignal(id: string) {
  const { error } = await supabase.from('emotion_signal').delete().eq('id', id);
  if (error) throw error;
}
