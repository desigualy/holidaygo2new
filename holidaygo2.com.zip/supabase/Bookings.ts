// Bookings CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllBookings() {
  const { data, error } = await supabase.from('bookings').select('*');
  if (error) throw error;
  return data;
}

export async function getBookingsById(id: string) {
  const { data, error } = await supabase.from('bookings').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createBookings(payload: any) {
  const { data, error } = await supabase.from('bookings').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateBookings(id: string, updates: any) {
  const { data, error } = await supabase.from('bookings').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteBookings(id: string) {
  const { error } = await supabase.from('bookings').delete().eq('id', id);
  if (error) throw error;
}
