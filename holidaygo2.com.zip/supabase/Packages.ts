// Packages CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllPackages() {
  const { data, error } = await supabase.from('packages').select('*');
  if (error) throw error;
  return data;
}

export async function getPackagesById(id: string) {
  const { data, error } = await supabase.from('packages').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createPackages(payload: any) {
  const { data, error } = await supabase.from('packages').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updatePackages(id: string, updates: any) {
  const { data, error } = await supabase.from('packages').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deletePackages(id: string) {
  const { error } = await supabase.from('packages').delete().eq('id', id);
  if (error) throw error;
}
