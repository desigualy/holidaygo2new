// UserProfile CRUD

import { supabase } from '@/lib/supabaseClient';

export async function getAllUserProfile() {
  const { data, error } = await supabase.from('user_profile').select('*');
  if (error) throw error;
  return data;
}

export async function getUserProfileById(id: string) {
  const { data, error } = await supabase.from('user_profile').select('*').eq('id', id).single();
  if (error) throw error;
  return data;
}

export async function createUserProfile(payload: any) {
  const { data, error } = await supabase.from('user_profile').insert(payload).select().single();
  if (error) throw error;
  return data;
}

export async function updateUserProfile(id: string, updates: any) {
  const { data, error } = await supabase.from('user_profile').update(updates).eq('id', id).select().single();
  if (error) throw error;
  return data;
}

export async function deleteUserProfile(id: string) {
  const { error } = await supabase.from('user_profile').delete().eq('id', id);
  if (error) throw error;
}
