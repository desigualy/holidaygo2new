// layout/PublicLayout.tsx

import { ReactNode } from 'react';
import Layout from '@/components/layout/Layout';
import { ChAtProvider } from '@/context/ChAtContext';
import { AgentEngineProvider } from '@/context/AgentEngine';
import { SessionProvider } from '@/context/SessionContext';
import { ThemeProvider } from '@/context/ThemeContext';

export default function PublicLayout({ children }: { children: ReactNode }) {
  return (
    <SessionProvider>
      <ThemeProvider>
        <ChAtProvider>
          <AgentEngineProvider>
            <Layout>{children}</Layout>
          </AgentEngineProvider>
        </ChAtProvider>
      </ThemeProvider>
    </SessionProvider>
  );
}
