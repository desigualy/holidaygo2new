// This utility file helps in resolving potential issues related to the package-lock file.
import { execSync } from 'child_process';

export const fixPackageLockError = () => {
  try {
    console.log('Attempting to fix package-lock error...');
    execSync('rm -rf node_modules/ package-lock.json && npm install', { stdio: 'inherit' });
    console.log('Package lock error fixed. Dependencies reinstalled.');
  } catch (error) {
    console.error('Error fixing package-lock:', error);
  }
};
