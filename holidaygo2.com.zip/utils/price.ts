// utils/price.ts

export function formatGBP(amount: number): string {
  return `£${amount.toFixed(2)}`;
}

export function priceRangeLabel(price: number): 'low' | 'mid' | 'high' {
  if (price < 300) return 'low';
  if (price > 800) return 'high';
  return 'mid';
}
