'use client';

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { useAgentEngine } from '@/context/AgentEngine';

interface Props {
  destination: string;
}

export default function CARTA({ destination }: Props) {
  const [coords, setCoords] = useState<{ lat: number; lng: number } | null>(null);
  const [status, setStatus] = useState<string>('Routing...');
  const { setDestinationContext } = useAgentEngine();

  useEffect(() => {
    const geocode = async () => {
      const apiKey = process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY;
      if (!apiKey) {
        setStatus('Missing Maps API key.');
        return;
      }

      try {
        const res = await fetch(
          `https://maps.googleapis.com/maps/api/geocode/json?address=${encodeURIComponent(
            destination
          )}&key=${apiKey}`
        );
        const json = await res.json();

        if (json.status === 'OK' && json.results[0]) {
          const loc = json.results[0].geometry.location;
          setCoords(loc);
          setDestinationContext(destination);
          supabase
            .from('user_location_logs')
            .insert([{ destination, lat: loc.lat, lng: loc.lng }]);
          setStatus('Trail locked. CARTA has the path.');
        } else {
          setStatus('No coordinates found. Fallback engaged.');
        }
      } catch {
        setStatus('CARTA failed to geocode — Oracle alerted.');
      }
    };

    if (destination) geocode();
  }, [destination]);

  return (
    <div
      className="fixed bottom-4 left-4 p-3 text-sm rounded bg-blue-900 text-blue-100 shadow backdrop-blur-md"
      role="status"
      aria-live="polite"
    >
      <span className="text-cyan-300 font-bold">CARTA:</span> {status}
    </div>
  );
}
