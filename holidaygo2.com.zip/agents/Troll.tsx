'use client';

import { useEffect, useState } from 'react';

export default function Troll() {
  const [disruption, setDisruption] = useState<string | null>(null);

  useEffect(() => {
    // Simulate async disruption feed or mood pulse
    setTimeout(() => {
      const chaos = [
        '🔥 Airport strike expected in Milan on Friday.',
        '⚠️ London train cancellations affecting Gatwick routes.',
        '🌧️ Flooding risk in Venice — high tide alerts active.',
        '💬 Troll: No disruption today. Carry on — I’m bored.',
      ];
      const pick = chaos[Math.floor(Math.random() * chaos.length)];
      setDisruption(pick);
    }, 700);
  }, []);

  return (
    <div
      className="fixed top-4 left-4 p-3 text-sm rounded bg-red-900 text-red-100 shadow backdrop-blur-md max-w-sm"
      role="status"
      aria-live="assertive"
    >
      <span className="text-red-300 font-bold">Troll:</span> {disruption || 'Listening for chaos...'}
    </div>
  );
}
