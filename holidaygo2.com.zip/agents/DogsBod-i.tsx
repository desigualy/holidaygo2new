// agents/DogsBod-i.tsx

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

interface Props {
  faultSignal: string | null;
}

export default function DogsBodi({ faultSignal }: Props) {
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    if (!faultSignal) return;

    setVisible(true);

    supabase.from('system_fault_log').insert({
      signal: faultSignal,
      timestamp: new Date().toISOString(),
      resolved: false,
    });
  }, [faultSignal]);

  if (!visible) return null;

  return (
    <div
      className="fixed inset-0 bg-black bg-opacity-90 text-lime-100 z-50 flex flex-col items-center justify-center p-8 text-center"
      aria-live="assertive"
      role="alertdialog"
    >
      <h2 className="text-2xl font-bold mb-4">Dog’s Bod-i Intervention</h2>
      <p className="text-sm max-w-md">
        Something’s gone sideways, mate.  
        I’ve logged the fault, patched the pipe, and rerouted the signal.  
        No need to panic — unless it starts smoking.  
        Then call the Captain.
      </p>
      <p className="text-xs mt-6 text-lime-400 italic">Signal: {faultSignal}</p>
    </div>
  );
}
