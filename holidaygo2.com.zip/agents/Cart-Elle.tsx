// agents/Cart-Elle.tsx

import { useEffect, useState } from 'react';
import { getDestinationContext } from '@/context/AgentEngine';

export default function CartElle() {
  const [line, setLine] = useState<string | null>(null);

  useEffect(() => {
    const context = getDestinationContext();
    if (!context) return;

    const toneMap: Record<string, string[]> = {
      beach: [
        'Salt-sweet wind curls around your memories.',
        'The tide hums like a lullaby you once forgot.'
      ],
      city: [
        'Stone and story intertwine — each window a whisper.',
        'The rooftops listen even when no one speaks.'
      ],
      forest: [
        'The silence is rich here — moss remembers.',
        'Light dances like breath through the trees.'
      ],
      desert: [
        'Heat bends the air like a promise unkept.',
        'Mirages echo things you’re meant to feel.'
      ]
    };

    const tone = Object.keys(toneMap).find((k) =>
      context.name.toLowerCase().includes(k)
    );

    const lines = tone ? toneMap[tone] : [
      'This place feels like a thought you once had.',
      'Air, light, stillness — the story writes itself.'
    ];

    const chosen = lines[Math.floor(Math.random() * lines.length)];
    setLine(chosen);
  }, []);

  if (!line) return null;

  return (
    <div
      className="fixed bottom-6 right-6 max-w-sm p-4 bg-white/90 text-gray-900 rounded-xl shadow-xl backdrop-blur-md animate-fade-in"
      aria-live="polite"
      role="status"
    >
      <p className="italic text-sm leading-snug">
        <span className="text-pink-700 font-medium">Cart-Elle:</span> “{line}”
      </p>
    </div>
  );
}
