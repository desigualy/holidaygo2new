// agents/ChAt.tsx
import { useEffect, useState } from 'react';
import useSpeechInput from '@/hooks/useSpeechInput';
import { routeLLM } from '@/lib/llmRouter';
import { supabase } from '@/lib/supabaseClient';
import ChatWindow from '@/components/ChatWindow';
import { useAgentEngine } from '@/context/AgentEngine';
import ChAtIntro from '@/agents/ChAtIntro'; // Import Ch@ Intro component

export default function ChAt() {
  const { agentState, setAgentState } = useAgentEngine();
  const [response, setResponse] = useState<string | null>(null);
  const [status, setStatus] = useState<string>('Standing by…');
  const { transcript, listening, startListening } = useSpeechInput();
  const [introSeen, setIntroSeen] = useState<boolean>(false); // Track if intro was shown

  useEffect(() => {
    const runLLM = async () => {
      if (!transcript) return;
      setStatus('Processing…');

      const res = await routeLLM(transcript);
      setResponse(res);
      setAgentState({ chAt: transcript, lastTopic: res });
      supabase.from('query_logs').insert([{ query: transcript, response: res }]);
      setStatus('Response received.');
    };

    runLLM();
  }, [transcript]);

  const handleStartChat = () => {
    setIntroSeen(true); // Mark the intro as seen when they start chatting
    startListening(); // Start listening for speech input when they are ready
  };

  return (
    <div>
      {/* Show the intro section only if it hasn't been seen */}
      {!introSeen ? (
        <ChAtIntro onStartChat={handleStartChat} />
      ) : (
        <ChatWindow
          input={transcript}
          output={response}
          status={status}
          persona="Ch@"
        />
      )}
    </div>
  );
}
