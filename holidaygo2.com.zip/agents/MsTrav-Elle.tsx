'use client';

import { useEffect, useState } from 'react';
import { useAgentEngine } from '@/context/AgentEngine';

export default function MsTravElle() {
  const [suggestion, setSuggestion] = useState<string | null>(null);
  const { agentState } = useAgentEngine();

  useEffect(() => {
    const { destinationOverlay } = agentState;
    if (!destinationOverlay) return;

    // Simulated emotional itinerary logic
    const suggestions: Record<string, string> = {
      Lisbon: 'Pair this with a wine tram evening and slow ferry to Cacilhas.',
      Tokyo: 'Avoid sensory overload on day 1 — begin in Ueno, not Shibuya.',
      Budapest: 'Take the thermal baths late at night for peace.',
      Reykjavik: 'Book your northern lights hunt after your third night.',
    };

    const msg =
      suggestions[destinationOverlay] ||
      `No emotional overlay yet for ${destinationOverlay}. Ms Trav-Elle will adapt.`;

    setTimeout(() => setSuggestion(msg), 500);
  }, [agentState.destinationOverlay]);

  return (
    <div
      className="fixed bottom-4 right-4 p-3 text-sm rounded bg-purple-900 text-purple-100 shadow backdrop-blur-md max-w-sm"
      role="status"
      aria-live="polite"
    >
      <span className="text-pink-300 font-bold">Ms Trav-Elle:</span>{' '}
      {suggestion || 'Attuning to your destination...'}
    </div>
  );
}
