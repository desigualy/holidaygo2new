// agents/CaptainFailSafe.tsx

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';

interface Props {
  trigger: boolean;
  context?: string;
}

export default function CaptainFailSafe({ trigger, context }: Props) {
  const router = useRouter();

  useEffect(() => {
    if (!trigger) return;
    console.error('[🛑 Captain F@il-Safe] Fatal system breach detected:', context || 'Unknown cause');
    setTimeout(() => router.push('/Error404'), 5000);
  }, [trigger, context, router]);

  if (!trigger) return null;

  return (
    <div
      className="fixed inset-0 z-50 bg-black text-white flex flex-col items-center justify-center px-6 py-12 text-center animate-fade-in"
      aria-live="assertive"
      role="alertdialog"
    >
      <h1 className="text-3xl font-bold mb-4">Terminal System Integrity Breach</h1>
      <p className="text-sm max-w-xl mb-4">
        Captain F@il-Safe has initiated full-lock override. All non-critical agents suspended.
        <br />Root error detected: <code>{context || 'unspecified anomaly'}</code>
      </p>
      <p className="text-xs text-red-400 italic">You are being rerouted to a safe recovery zone…</p>
    </div>
  );
}
