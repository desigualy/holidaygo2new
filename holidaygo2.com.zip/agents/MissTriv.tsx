// agents/MissTriv.tsx

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

interface Props {
  checkpoint: string;
  onValidated?: () => void;
}

export default function MissTriv({ checkpoint, onValidated }: Props) {
  const [status, setStatus] = useState<'validating' | 'ok' | 'fail'>('validating');

  useEffect(() => {
    const validate = async () => {
      const { data, error } = await supabase
        .from('triv_gatekeeper')
        .select('id')
        .eq('checkpoint', checkpoint)
        .single();

      if (error || !data) {
        setStatus('fail');
      } else {
        setStatus('ok');
        onValidated?.();
      }
    };

    validate();
  }, [checkpoint, onValidated]);

  if (status === 'validating') return null;

  return (
    <div
      className={`fixed bottom-4 left-4 p-3 rounded shadow-lg text-sm font-mono transition-all duration-300
      ${status === 'ok' ? 'bg-emerald-700 text-white' : 'bg-red-900 text-red-200'}`}
      role="status"
      aria-live="polite"
    >
      Miss Triv: {status === 'ok' ? 'Confirmed and logged.' : 'Checkpoint failed. Fallback triggered.'}
    </div>
  );
}
