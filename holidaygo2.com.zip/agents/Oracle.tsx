'use client';

import { useEffect, useState } from 'react';

export default function Oracle() {
  const [insight, setInsight] = useState<string>('Gathering insight…');

  useEffect(() => {
    // Simulated predictive logic
    setTimeout(() => {
      const now = new Date();
      const month = now.getMonth();
      const peak = [5, 6, 11]; // June, July, December

      const message = peak.includes(month)
        ? '🧠 Oracle: You are entering a peak travel window. Prices may rise by 15–25%.'
        : '🧠 Oracle: Off-peak detected. Forecast: stable pricing and high availability.';

      setInsight(message);
    }, 500);
  }, []);

  return (
    <div
      className="fixed top-4 right-4 p-3 text-sm rounded bg-yellow-900 text-yellow-100 shadow backdrop-blur-md max-w-sm"
      role="status"
      aria-live="polite"
    >
      <span className="text-yellow-300 font-bold">Oracle:</span> {insight}
    </div>
  );
}
