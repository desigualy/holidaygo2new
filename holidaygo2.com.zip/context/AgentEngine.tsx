'use client';

import { createContext, useContext, useState } from 'react';

interface AgentState {
  chAt?: string;
  travElle?: string;
  oraclePing?: boolean;
  lastTopic?: string;
  destinationOverlay?: string;
}

interface AgentContextType {
  agentState: AgentState;
  setAgentState: (s: Partial<AgentState>) => void;
  getDestinationContext: () => { name: string };
  setDestinationContext: (name: string) => void;
}

const AgentContext = createContext<AgentContextType | null>(null);

export function AgentEngineProvider({ children }: { children: React.ReactNode }) {
  const [agentState, setAgentStateRaw] = useState<AgentState>({
    chAt: '',
    travElle: '',
    oraclePing: false,
    lastTopic: '',
    destinationOverlay: '',
  });

  const setAgentState = (s: Partial<AgentState>) => {
    setAgentStateRaw((prev) => ({ ...prev, ...s }));
  };

  const getDestinationContext = () => {
    return {
      name: agentState.destinationOverlay || 'Unknown Destination',
    };
  };

  const setDestinationContext = (name: string) => {
    setAgentState({ destinationOverlay: name });
    if (typeof window !== 'undefined') {
      localStorage.setItem('destinationContext', JSON.stringify({ name }));
    }
  };

  return (
    <AgentContext.Provider
      value={{ agentState, setAgentState, getDestinationContext, setDestinationContext }}
    >
      {children}
    </AgentContext.Provider>
  );
}

export function useAgentEngine() {
  const ctx = useContext(AgentContext);
  if (!ctx) throw new Error('useAgentEngine must be used within AgentEngineProvider');
  return ctx;
}

// 🔁 Legacy direct access support (Cart-Elle, Mapseer)
export const getDestinationContext = () => {
  if (typeof window !== 'undefined') {
    const raw = localStorage.getItem('destinationContext');
    return raw ? JSON.parse(raw) : { name: 'Unknown' };
  }
  return { name: 'Unavailable' };
};
