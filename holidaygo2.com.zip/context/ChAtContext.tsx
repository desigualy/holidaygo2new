// context/ChAtContext.tsx

'use client';

import { createContext, useContext, useState } from 'react';

interface ChAtContextType {
  input: string;
  response: string;
  isListening: boolean;
  setInput: (val: string) => void;
  setResponse: (val: string) => void;
  setListening: (val: boolean) => void;
}

const ChAtContext = createContext<ChAtContextType | null>(null);

export function ChAtProvider({ children }: { children: React.ReactNode }) {
  const [input, setInput] = useState('');
  const [response, setResponse] = useState('');
  const [isListening, setListening] = useState(false);

  return (
    <ChAtContext.Provider
      value={{
        input,
        response,
        isListening,
        setInput,
        setResponse,
        setListening,
      }}
    >
      {children}
    </ChAtContext.Provider>
  );
}

export function useChAt() {
  const ctx = useContext(ChAtContext);
  if (!ctx) throw new Error('useChAt must be used within a ChAtProvider');
  return ctx;
}
