// services/pricing/priceNormalizer.ts

export function normalizePrice(raw: number, currency: string = 'GBP'): number {
  if (currency === 'USD') return Math.round(raw * 0.78);
  if (currency === 'EUR') return Math.round(raw * 0.86);
  return Math.round(raw);
}

export function applyEmotionDiscount(price: number, tone: string): number {
  switch (tone) {
    case 'excited':
      return Math.round(price * 0.95);
    case 'frustrated':
      return Math.round(price * 0.9);
    case 'curious':
      return Math.round(price * 0.97);
    default:
      return price;
  }
}
