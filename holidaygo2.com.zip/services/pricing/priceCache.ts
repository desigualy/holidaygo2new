// services/pricing/priceCache.ts

type PriceEntry = {
  destination: string;
  date: string;
  price: number;
};

const cache: Record<string, PriceEntry[]> = {};

export function savePrice(destination: string, date: string, price: number) {
  const key = destination.toLowerCase();
  if (!cache[key]) cache[key] = [];
  cache[key].push({ destination, date, price });
}

export function getCachedPrices(destination: string): PriceEntry[] {
  const key = destination.toLowerCase();
  return cache[key] || [];
}
