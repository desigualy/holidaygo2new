import { createClient } from "@/lib/supabaseClient";

const supabase = createClient();

export const fetchHolidayDeals = async (filters = {}) => {
  let query = supabase.from('holiday_deals').select('*');

  if (filters.destination) {
    query = query.eq('destination', filters.destination);
  }

  const { data, error } = await query;

  if (error) {
    throw new Error(error.message);
  }

  return data;
};
