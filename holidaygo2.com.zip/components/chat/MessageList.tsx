// components/chat/MessageList.tsx

interface Props {
  userMessage: string;
  agentReply: string;
}

export default function MessageList({ userMessage, agentReply }: Props) {
  return (
    <div className="flex flex-col gap-2 mb-2">
      {userMessage && (
        <div className="bg-gray-100 px-3 py-2 rounded self-end max-w-xs text-sm shadow">
          <p className="text-right text-gray-700">{userMessage}</p>
        </div>
      )}
      {agentReply && (
        <div className="bg-blue-100 px-3 py-2 rounded self-start max-w-xs text-sm shadow">
          <p className="text-gray-800 italic">“{agentReply}”</p>
        </div>
      )}
    </div>
  );
}
