// components/chat/TypingIndicator.tsx

export default function TypingIndicator() {
  return (
    <div className="flex items-center gap-2 mt-2 text-sm text-gray-500 font-mono animate-pulse">
      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce" />
      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-100" />
      <span className="w-2 h-2 bg-gray-400 rounded-full animate-bounce delay-200" />
      <span>Ch@ is thinking…</span>
    </div>
  );
}
