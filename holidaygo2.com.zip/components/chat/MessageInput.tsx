// components/chat/MessageInput.tsx

interface Props {
  value: string;
  onChange: (text: string) => void;
}

export default function MessageInput({ value, onChange }: Props) {
  return (
    <input
      type="text"
      value={value}
      onChange={(e) => onChange(e.target.value)}
      placeholder="Ask Ch@ something..."
      className="w-full px-3 py-2 mt-2 border border-gray-300 rounded text-sm shadow focus:outline-none focus:ring focus:ring-blue-500"
    />
  );
}
