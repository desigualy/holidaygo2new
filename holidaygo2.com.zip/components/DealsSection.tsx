'use client';

import { useEffect, useState } from 'react';
import { ResultCard } from '@/components/search/ResultCard';

interface HolidayPackage {
  id: string;
  destination: string;
  description: string;
  image_url: string;
  price: number;
}

export default function DealsSection() {
  const [packages, setPackages] = useState<HolidayPackage[]>([]);

  useEffect(() => {
    setPackages([
      {
        id: '1',
        destination: 'Lisbon',
        description: '2 nights in Alfama, hotel + tram pass.',
        image_url: '/images/lisbon.jpg',
        price: 179,
      },
      {
        id: '2',
        destination: 'Prague',
        description: 'Weekend city break, 4-star hotel, breakfast.',
        image_url: '/images/prague.jpg',
        price: 149,
      },
    ]);
  }, []);

  return (
    <section className="mt-10 space-y-4">
      <h2 className="text-xl font-bold text-cyan-300">Top Picks</h2>
      <div className="grid gap-4">
        {packages.map((pkg) => (
          <ResultCard key={pkg.id} pkg={pkg} />
        ))}
      </div>
    </section>
  );
}
