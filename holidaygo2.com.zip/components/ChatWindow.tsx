'use client';

interface ChatWindowProps {
  input: string | null;
  output: string | null;
  status: string;
  persona: string;
}

export default function ChatWindow({ input, output, status, persona }: ChatWindowProps) {
  return (
    <div className="p-4 space-y-3 border rounded-lg shadow bg-slate-800 text-slate-100">
      <h2 className="text-lg font-bold text-cyan-300">{persona}</h2>
      <div className="text-sm text-slate-300">
        <strong>Heard:</strong> {input || '…'}
      </div>
      <div className="text-sm text-slate-300">
        <strong>Response:</strong> {output || '…'}
      </div>
      <div className="text-xs text-yellow-400">
        <em>{status}</em>
      </div>
    </div>
  );
}
