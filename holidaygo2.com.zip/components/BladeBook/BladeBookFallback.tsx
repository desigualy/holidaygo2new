// components/BladeBook/BladeBookFallback.tsx

import { useEffect, useState } from 'react';

export default function BladeBookFallback() {
  const [quote, setQuote] = useState<string | null>(null);

  useEffect(() => {
    const responses = [
      "The blade returns thin truths — a whisper, not a scream.",
      "What’s hidden isn’t always lost. Look again.",
      "Thread pulled. Shadows moved. One moment…",
      "The deeper the thread, the older the echo.",
      "Signals retrieved from the unspoken net…",
      "Sanitised anomaly detected. Suggest human inspection.",
      "Only Ms Trav-Elle knows what to do with these kinds of echoes.",
    ];

    const chosen = responses[Math.floor(Math.random() * responses.length)];
    setQuote(chosen);
  }, []);

  if (!quote) return null;

  return (
    <div
      className="fixed bottom-5 right-5 bg-black text-green-200 border border-green-700 p-4 rounded shadow-xl font-mono text-xs max-w-sm animate-fade-in"
      role="alert"
      aria-live="polite"
    >
      <p><strong>BladeBook:</strong> “{quote}”</p>
    </div>
  );
}
