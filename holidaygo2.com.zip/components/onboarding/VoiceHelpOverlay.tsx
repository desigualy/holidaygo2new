// components/onboarding/VoiceHelpOverlay.tsx

export default function VoiceHelpOverlay() {
  return (
    <div className="mt-6 p-4 border border-blue-300 bg-blue-50 text-blue-800 rounded shadow text-sm">
      <p className="mb-2">
        You can start by saying things like:
      </p>
      <ul className="list-disc list-inside space-y-1">
        <li>“Find me a weekend in Paris under £500.”</li>
        <li>“Where can I go with sunshine next week?”</li>
        <li>“Book me something romantic but quiet.”</li>
      </ul>
      <p className="mt-3 italic text-xs text-blue-500">
        Voice input is active system-wide. You don’t need to click anything. Just speak naturally.
      </p>
    </div>
  );
}
