// components/onboarding/OnboardingFlow.tsx

import { useEffect, useState } from 'react';
import VoiceHelpOverlay from './VoiceHelpOverlay';

export default function OnboardingFlow() {
  const [step, setStep] = useState(0);

  const steps = [
    "Welcome to HolidayGo2 — a voice-first travel experience.",
    "Meet Ch@, your conversational companion.",
    "Ms Trav-Elle will guide your emotional journeys.",
    "Prefer typing? That’s okay — but try saying it.",
    "You can speak anywhere on this site.",
    "Let’s begin when you’re ready. Just say: ‘I want to explore.’",
  ];

  useEffect(() => {
    const timer = setTimeout(() => {
      if (step < steps.length - 1) setStep(step + 1);
    }, 4000);
    return () => clearTimeout(timer);
  }, [step]);

  return (
    <div className="fixed inset-0 z-50 bg-white/95 flex items-center justify-center text-center p-6">
      <div className="max-w-md">
        <p className="text-xl font-semibold text-gray-800 mb-4 animate-fade-in">
          {steps[step]}
        </p>
        {step === steps.length - 1 && <VoiceHelpOverlay />}
      </div>
    </div>
  );
}
