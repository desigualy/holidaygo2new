// components/agents/AgentPicker.tsx
import React from "react";
import { Button } from "@/components/ui/button";

const AgentPicker: React.FC = () => {
  const handleAgentSelect = (agent: string) => {
    console.log("Selected Agent:", agent);
    // Logic to switch or interact with different agents
  };

  return (
    <div className="agent-picker">
      <h2 className="text-xl font-semibold mb-4">Pick an Agent</h2>
      <div className="space-x-4">
        <Button onClick={() => handleAgentSelect("Ch@")}>Ch@</Button>
        <Button onClick={() => handleAgentSelect("Ms. Trav-Elle")}>Ms. Trav-Elle</Button>
        <Button onClick={() => handleAgentSelect("Oracle")}>Oracle</Button>
        <Button onClick={() => handleAgentSelect("Captain F@il-Safe")}>Captain F@il-Safe</Button>
      </div>
    </div>
  );
};

export default AgentPicker;
