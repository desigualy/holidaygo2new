// agents/ChAtIntro.tsx
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Chat } from "lucide-react";

const ChAtIntro: React.FC = () => {
  return (
    <Card className="w-full bg-gradient-to-b from-blue-500 via-blue-700 to-blue-900 text-white">
      <CardHeader>
        <CardTitle className="text-2xl font-semibold">Meet Ch@, Your Virtual Assistant</CardTitle>
      </CardHeader>
      <CardContent className="flex flex-col items-center text-center space-y-4">
        <div className="h-20 w-20 rounded-full bg-white p-4 flex items-center justify-center">
          <Chat className="h-12 w-12 text-blue-500" />
        </div>
        <p className="text-lg font-medium">
          Ch@ is here to assist you with your travel planning. Whether you're looking for the best deals, need help with
          bookings, or simply want travel advice, Ch@ is ready to help.
        </p>
        <button className="px-6 py-2 bg-blue-500 hover:bg-blue-700 rounded-md text-white">
          Start Chatting
        </button>
      </CardContent>
    </Card>
  );
};

export default ChAtIntro;
