// components/Patchlings/Patchlings.tsx

import PatchField from './PatchField';

interface Patch {
  id: string;
  status: 'active' | 'drifting' | 'restored';
}

interface Props {
  patches: Patch[];
}

export default function Patchlings({ patches }: Props) {
  if (!patches || patches.length === 0) return null;

  return (
    <div className="fixed bottom-6 left-6 flex flex-col gap-2 z-50">
      {patches.map((patch) => (
        <PatchField key={patch.id} id={patch.id} status={patch.status} />
      ))}
    </div>
  );
}
