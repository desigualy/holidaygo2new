// components/Patchlings/PatchField.tsx

interface PatchProps {
  id: string;
  status: 'active' | 'drifting' | 'restored';
}

export default function PatchField({ id, status }: PatchProps) {
  const colorMap = {
    active: 'bg-lime-500',
    drifting: 'bg-yellow-400',
    restored: 'bg-blue-500',
  };

  const labelMap = {
    active: 'Patch Active',
    drifting: 'Signal Drifting',
    restored: 'Thread Restored',
  };

  return (
    <div className="flex items-center gap-2 p-2 text-xs font-mono bg-black/80 rounded border border-lime-300 shadow text-white max-w-xs">
      <div className={`w-2 h-2 rounded-full ${colorMap[status]}`} />
      <span>{id}:</span>
      <span className="italic">{labelMap[status]}</span>
    </div>
  );
}
