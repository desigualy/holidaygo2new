'use client';

import Link from 'next/link';

export default function Header() {
  return (
    <header className="bg-black border-b border-slate-800 px-6 py-4 flex justify-between items-center shadow z-10">
      <Link href="/" className="text-cyan-400 font-bold text-xl">
        HolidayGo2
      </Link>
      <nav className="flex gap-4 text-sm text-slate-300">
        <Link href="/flights" className="hover:text-white">Flights</Link>
        <Link href="/hotels" className="hover:text-white">Hotels</Link>
        <Link href="/packages" className="hover:text-white">Packages</Link>
        <Link href="/search" className="hover:text-white">Search</Link>
        <Link href="/profile" className="hover:text-white">Profile</Link>
      </nav>
    </header>
  );
}
