'use client';

export default function Footer() {
  return (
    <footer className="bg-black border-t border-slate-800 text-xs text-slate-500 text-center py-4">
      &copy; {new Date().getFullYear()} HolidayGo2.com · All rights reserved.
    </footer>
  );
}
