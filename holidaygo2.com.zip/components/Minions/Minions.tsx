// components/Minions/Minions.tsx

interface MinionProps {
  label: string;
  status: 'idle' | 'patched' | 'rerouted';
}

export default function Minions({ label, status }: MinionProps) {
  const statusMap = {
    idle: 'text-gray-400',
    patched: 'text-green-400',
    rerouted: 'text-yellow-300',
  };

  const statusLabel = {
    idle: 'Standing by',
    patched: 'Patched',
    rerouted: 'Rerouted',
  };

  return (
    <div className="flex items-center gap-2 text-xs font-mono">
      <span className="text-lime-400">⛭</span>
      <span className="text-sky-200">{label}</span>
      <span className={statusMap[status]}>{statusLabel[status]}</span>
    </div>
  );
}
