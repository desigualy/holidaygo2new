// components/Minions/MinionNetworkOverlay.tsx

import { useEffect, useState } from 'react';

interface Props {
  isActive: boolean;
}

export default function MinionNetworkOverlay({ isActive }: Props) {
  const [line, setLine] = useState<string | null>(null);

  useEffect(() => {
    if (!isActive) return;

    const pulses = [
      'Patchling swarm stabilised routing node.',
      'Minion mesh realigned to fallback tier.',
      'Synthetic pulse grid re-established.',
      'Error overlay absorbed by Minion mesh.',
      'Non-critical fault rerouted to buffer swarm.',
    ];

    setLine(pulses[Math.floor(Math.random() * pulses.length)]);
  }, [isActive]);

  if (!isActive || !line) return null;

  return (
    <div
      className="fixed inset-0 bg-black/80 text-lime-300 text-xs font-mono flex items-center justify-center z-50"
      role="alert"
      aria-live="assertive"
    >
      <div className="bg-black p-4 rounded border border-lime-500 shadow-md text-center">
        <p><strong>Minion Overlay:</strong> {line}</p>
      </div>
    </div>
  );
}
