// app/components/careers/ProspectorApplication.tsx
import React, { useEffect, useState } from "react";
import { zodResolver } from "@hookform/resolvers/zod";
import { useForm } from "react-hook-form";
import * as z from "zod";
import { Card, CardContent, CardHeader, CardTitle, CardDescription, CardFooter } from "@/components/ui/card";
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Checkbox } from "@/components/ui/checkbox";
import { toast } from "sonner";
import { FileText, Upload, User, Mail, Phone, MapPin, Briefcase, Calendar } from "lucide-react";

// Form schema for validation
const formSchema = z.object({
  firstName: z.string().min(2, { message: "First name must be at least 2 characters." }),
  lastName: z.string().min(2, { message: "Last name must be at least 2 characters." }),
  email: z.string().email({ message: "Please enter a valid email address." }),
  phone: z.string().min(5, { message: "Please enter a valid phone number." }),
  location: z.string().min(2, { message: "Please enter your location." }),
  salesExperience: z.string().min(1, { message: "Please select your sales experience." }),
  travelIndustryExperience: z.string().min(1, { message: "Please select your travel industry experience." }),
  availabilityDate: z.string().min(1, { message: "Please enter when you can start." }),
  motivationLetter: z.string().min(50, { message: "Please write at least 50 characters about your motivation." }),
  referralSource: z.string().optional(),
  agreeToTerms: z.boolean().refine(value => value === true, {
    message: "You must agree to the terms and conditions."
  }),
  willingToTravel: z.boolean().optional(),
});

type FormValues = z.infer<typeof formSchema>;

const ProspectorApplication: React.FC = () => {
  const form = useForm<FormValues>({
    resolver: zodResolver(formSchema),
    defaultValues: {
      firstName: "",
      lastName: "",
      email: "",
      phone: "",
      location: "",
      salesExperience: "",
      travelIndustryExperience: "",
      availabilityDate: "",
      motivationLetter: "",
      referralSource: "",
      agreeToTerms: false,
      willingToTravel: false,
    },
  });

  const handleSubmit = (values: FormValues) => {
    console.log('Form submitted:', values);
    setTimeout(() => {
      toast.success("Application submitted successfully!");
      form.reset();
    }, 1000);
  };

  return (
    <Card className="w-full">
      <CardHeader>
        <CardTitle className="text-2xl">Apply to Join Our Sales Team</CardTitle>
        <CardDescription>
          HolidayGo2 is looking for motivated canvassers and prospectors to join our growing sales team.
        </CardDescription>
      </CardHeader>
      <CardContent>
        <Form {...form}>
          <form onSubmit={form.handleSubmit(handleSubmit)} className="space-y-6">
            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="firstName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>First Name *</FormLabel>
                    <FormControl>
                      <div className="flex">
                        <User className="mr-2 h-4 w-4 text-muted-foreground self-center" />
                        <Input placeholder="John" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="lastName"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Last Name *</FormLabel>
                    <FormControl>
                      <div className="flex">
                        <User className="mr-2 h-4 w-4 text-muted-foreground self-center" />
                        <Input placeholder="Doe" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <div className="grid grid-cols-1 gap-6 md:grid-cols-2">
              <FormField
                control={form.control}
                name="email"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Email *</FormLabel>
                    <FormControl>
                      <div className="flex">
                        <Mail className="mr-2 h-4 w-4 text-muted-foreground self-center" />
                        <Input placeholder="john.doe@example.com" type="email" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
              <FormField
                control={form.control}
                name="phone"
                render={({ field }) => (
                  <FormItem>
                    <FormLabel>Phone Number *</FormLabel>
                    <FormControl>
                      <div className="flex">
                        <Phone className="mr-2 h-4 w-4 text-muted-foreground self-center" />
                        <Input placeholder="+1 (123) 456-7890" {...field} />
                      </div>
                    </FormControl>
                    <FormMessage />
                  </FormItem>
                )}
              />
            </div>

            <FormField
              control={form.control}
              name="location"
              render={({ field }) => (
                <FormItem>
                  <FormLabel>Location *</FormLabel>
                  <FormControl>
                    <div className="flex">
                      <MapPin className="mr-2 h-4 w-4 text-muted-foreground self-center" />
                      <Input placeholder="City, Country" {...field} />
                    </div>
                  </FormControl>
                  <FormDescription>
                    Please enter your current location
                  </FormDescription>
                  <FormMessage />
                </FormItem>
              )}
            />
            <Button type="submit" className="w-full">Submit Application</Button>
          </form>
        </Form>
      </CardContent>
      <CardFooter className="flex flex-col space-y-2 text-sm text-muted-foreground border-t pt-6">
        <p>Your application will be reviewed by our recruiting team. We aim to respond to all applications within 5 business days.</p>
        <p>If you have any questions, please contact our HR team at <span className="text-primary">careers@holidaygo2.com</span>.</p>
      </CardFooter>
    </Card>
  );
};

export default ProspectorApplication;
