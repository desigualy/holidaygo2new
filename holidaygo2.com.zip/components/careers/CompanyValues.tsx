// @/components/careers/CompanyValues.js
import { Card, CardContent } from "@/components/ui/card";
import { User, Briefcase, Globe } from "lucide-react";

const CompanyValues = () => (
  <Card className="bg-primary/5 border-none">
    <CardContent className="grid grid-cols-1 md:grid-cols-3 gap-6 p-6">
      <div className="text-center">
        <div className="rounded-full bg-primary/10 p-3 w-fit mx-auto mb-3">
          <User className="h-6 w-6 text-primary" />
        </div>
        <h3 className="font-semibold text-lg mb-1">People First</h3>
        <p className="text-sm text-muted-foreground">
          We value diversity, inclusion, and work-life balance. Our culture supports your personal and professional growth.
        </p>
      </div>
      <div className="text-center">
        <div className="rounded-full bg-primary/10 p-3 w-fit mx-auto mb-3">
          <Briefcase className="h-6 w-6 text-primary" />
        </div>
        <h3 className="font-semibold text-lg mb-1">Meaningful Work</h3>
        <p className="text-sm text-muted-foreground">
          Help millions of travelers find the perfect holiday and create memories that last a lifetime.
        </p>
      </div>
      <div className="text-center">
        <div className="rounded-full bg-primary/10 p-3 w-fit mx-auto mb-3">
          <Globe className="h-6 w-6 text-primary" />
        </div>
        <h3 className="font-semibold text-lg mb-1">Global Presence</h3>
        <p className="text-sm text-muted-foreground">
          With offices in 8 countries and team members from over 35 nationalities, we're a truly global company.
        </p>
      </div>
    </CardContent>
  </Card>
);

export default CompanyValues;
