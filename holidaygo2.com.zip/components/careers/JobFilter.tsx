// @/components/careers/JobFilter.js
import { Button, Card, CardContent, CardHeader, CardTitle } from "@/components/ui/button";
import { Label } from "@/components/ui/label";

const JobFilter = ({ departments, selectedDepartment, onDepartmentChange }) => (
  <Card>
    <CardHeader>
      <CardTitle>Filter By</CardTitle>
    </CardHeader>
    <CardContent>
      <div className="space-y-2">
        <Label>Department</Label>
        {departments.map((dept) => (
          <Button 
            key={dept} 
            variant={selectedDepartment === dept ? "default" : "ghost"} 
            onClick={() => onDepartmentChange(dept)}
          >
            {dept}
          </Button>
        ))}
      </div>
    </CardContent>
  </Card>
);

export default JobFilter;
