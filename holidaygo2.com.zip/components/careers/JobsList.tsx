// @/components/careers/JobsList.js
import JobCard from "./JobCard";

const JobsList = ({ jobs, onSelectJob }) => (
  <div>
    {jobs.length === 0 ? (
      <Card>
        <CardContent>No jobs available at the moment.</CardContent>
      </Card>
    ) : (
      jobs.map((job) => (
        <JobCard key={job.id} job={job} onClick={onSelectJob} />
      ))
    )}
  </div>
);

export default JobsList;
