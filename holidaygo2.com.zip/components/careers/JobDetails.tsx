// @/components/careers/JobDetails.js
import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";

const JobDetails = ({ job, onBack }) => {
  const [showApplicationForm, setShowApplicationForm] = useState(false);

  return (
    <Card>
      <CardHeader>
        <CardTitle>{job.title}</CardTitle>
      </CardHeader>
      <CardContent>
        {showApplicationForm ? (
          <div>
            <Button onClick={() => setShowApplicationForm(false)}>Back</Button>
            <form> {/* Application Form here */} </form>
          </div>
        ) : (
          <div>
            <p>{job.description}</p>
            <Button onClick={() => setShowApplicationForm(true)}>Apply Now</Button>
          </div>
        )}
      </CardContent>
    </Card>
  );
};

export default JobDetails;
