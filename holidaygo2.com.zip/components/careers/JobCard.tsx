// @/components/careers/JobCard.js
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { MapPin, Building, Clock } from "lucide-react";

const JobCard = ({ job, onClick }) => (
  <Card 
    className="hover:border-primary/50 transition-colors cursor-pointer"
    onClick={() => onClick(job)}
  >
    <CardContent className="p-6">
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-4">
        <div>
          <h3 className="text-lg font-semibold">{job.title}</h3>
          <p className="text-muted-foreground">{job.department}</p>
        </div>
        <div className="mt-2 sm:mt-0">
          <Button size="sm">View Details</Button>
        </div>
      </div>
      
      <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 mb-4">
        <div className="flex items-center text-sm text-muted-foreground">
          <MapPin className="h-4 w-4 mr-1" />
          <span>{job.location}</span>
        </div>
        <div className="flex items-center text-sm text-muted-foreground">
          <Building className="h-4 w-4 mr-1" />
          <span>{job.locationType}</span>
        </div>
        <div className="flex items-center text-sm text-muted-foreground">
          <Clock className="h-4 w-4 mr-1" />
          <span>{job.type}</span>
        </div>
      </div>
      
      <p className="text-sm line-clamp-2">{job.description}</p>
      
      <div className="flex justify-between items-center mt-4 pt-3 border-t text-sm">
        <span className="text-muted-foreground">Posted {job.postedDate}</span>
        {job.salary && <span className="font-medium">{job.salary}</span>}
      </div>
    </CardContent>
  </Card>
);

export default JobCard;
