'use client';

import React from 'react';
import Link from 'next/link';
import { usePathname } from 'next/navigation';

interface SettingsNavItemProps {
  href: string;
  label: string;
}

export const SettingsNavItem = ({ href, label }: SettingsNavItemProps) => {
  const pathname = usePathname();
  const isActive = pathname === href;

  return (
    <Link
      href={href}
      className={`block px-4 py-2 rounded-lg ${
        isActive ? 'bg-blue-600 text-white' : 'text-gray-700 hover:bg-gray-200'
      }`}
    >
      {label}
    </Link>
  );
};
