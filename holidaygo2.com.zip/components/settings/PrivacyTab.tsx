'use client';

import React from 'react';

export const PrivacyTab = () => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Privacy Settings</h2>
      <p className="text-sm text-gray-600">Control who sees your information.</p>
      <form className="space-y-4">
        <label>
          <input type="checkbox" className="mr-2" /> Make my profile public
        </label>
        <label>
          <input type="checkbox" className="mr-2" /> Allow others to message me
        </label>
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md">
          Save Changes
        </button>
      </form>
    </div>
  );
};
