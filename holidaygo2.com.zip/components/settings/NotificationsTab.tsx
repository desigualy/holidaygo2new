'use client';

import React from 'react';

export const NotificationsTab = () => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Notification Settings</h2>
      <p className="text-sm text-gray-600">Manage how you receive notifications.</p>
      <form className="space-y-4">
        <label>
          <input type="checkbox" className="mr-2" /> Receive Email Notifications
        </label>
        <label>
          <input type="checkbox" className="mr-2" /> Receive SMS Alerts
        </label>
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md">
          Save Changes
        </button>
      </form>
    </div>
  );
};
