'use client';

import React from 'react';

export const PaymentMethodsTab = () => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Payment Methods</h2>
      <p className="text-sm text-gray-600">Manage your saved payment methods.</p>
      <form className="space-y-4">
        <input
          type="text"
          placeholder="Credit Card Number"
          className="w-full p-2 border rounded-md"
        />
        <input
          type="text"
          placeholder="Expiry Date"
          className="w-full p-2 border rounded-md"
        />
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md">
          Save Changes
        </button>
      </form>
    </div>
  );
};
