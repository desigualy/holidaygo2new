'use client';

import React from 'react';

export const AccountTab = () => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Account Information</h2>
      <p className="text-sm text-gray-600">Manage your email, name, and login preferences.</p>
      <form className="space-y-4">
        <input type="email" placeholder="Email" className="w-full p-2 border rounded-md" />
        <input type="text" placeholder="Full Name" className="w-full p-2 border rounded-md" />
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md">
          Save Changes
        </button>
      </form>
    </div>
  );
};
