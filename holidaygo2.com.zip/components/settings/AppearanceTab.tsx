'use client';

import React from 'react';

export const AppearanceTab = () => {
  return (
    <div className="space-y-4">
      <h2 className="text-xl font-bold">Appearance Settings</h2>
      <p className="text-sm text-gray-600">Customize the look and feel of the platform.</p>
      <form className="space-y-4">
        <label>
          <input type="radio" name="theme" className="mr-2" /> Light Mode
        </label>
        <label>
          <input type="radio" name="theme" className="mr-2" /> Dark Mode
        </label>
        <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md">
          Save Changes
        </button>
      </form>
    </div>
  );
};
