'use client';

import React from 'react';

interface Destination {
  name: string;
  image: string;
  priceFrom: string;
  slug: string;
}

export const PopularDestination = ({ destinations }: { destinations: Destination[] }) => {
  return (
    <section className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-6 py-6">
      {destinations.map((dest) => (
        <div key={dest.slug} className="bg-white shadow-md rounded-xl overflow-hidden">
          <img src={dest.image} alt={dest.name} className="w-full h-48 object-cover" />
          <div className="p-4">
            <h3 className="text-lg font-semibold">{dest.name}</h3>
            <p className="text-sm text-gray-500">From {dest.priceFrom}</p>
          </div>
        </div>
      ))}
    </section>
  );
};
