// components/hotels/HotelCard.tsx
import React from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { MapPin, Star } from "lucide-react";

interface HotelCardProps {
  name: string;
  location: string;
  rating: number;
  price: string;
  imageUrl: string;
}

const HotelCard: React.FC<HotelCardProps> = ({ name, location, rating, price, imageUrl }) => {
  return (
    <Card className="max-w-xs">
      <CardHeader>
        <CardTitle>{name}</CardTitle>
        <p className="text-sm text-muted-foreground">{location}</p>
      </CardHeader>
      <CardContent>
        <div className="flex items-center mb-4">
          <MapPin className="h-4 w-4 text-muted-foreground" />
          <span className="ml-1 text-sm">{location}</span>
        </div>
        <img src={imageUrl} alt={name} className="w-full h-48 object-cover rounded-md mb-4" />
        <div className="flex items-center">
          <Star className="h-4 w-4 text-yellow-400" />
          <span className="ml-2 text-sm">{rating} / 5</span>
        </div>
        <p className="mt-2 text-lg font-bold">{price}</p>
      </CardContent>
    </Card>
  );
};

export default HotelCard;
