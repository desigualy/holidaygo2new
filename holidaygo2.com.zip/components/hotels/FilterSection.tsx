'use client';

import React from 'react';

interface Props {
  onFilterChange: (filters: Record<string, any>) => void;
}

export const FilterSection = ({ onFilterChange }: Props) => {
  return (
    <aside className="p-4 bg-gray-100 rounded-xl space-y-4">
      <h2 className="text-lg font-bold">Filters</h2>
      {/* Example filter */}
      <div>
        <label className="block font-medium">Price Range</label>
        <input
          type="range"
          min="50"
          max="1000"
          onChange={(e) => onFilterChange({ price: e.target.value })}
          className="w-full"
        />
      </div>
    </aside>
  );
};
