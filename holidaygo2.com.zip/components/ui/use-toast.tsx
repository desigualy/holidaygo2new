'use client';

import React, { useState } from 'react';

export const useToast = () => {
  const [toast, setToast] = useState<string | null>(null);

  const showToast = (message: string) => setToast(message);
  const hideToast = () => setToast(null);

  return {
    toast,
    showToast,
    hideToast,
  };
};

export const ToastComponent = ({ toast, hideToast }: { toast: string | null; hideToast: () => void }) => {
  if (!toast) return null;

  return (
    <div className="toast" onClick={hideToast}>
      <p>{toast}</p>
    </div>
  );
};
