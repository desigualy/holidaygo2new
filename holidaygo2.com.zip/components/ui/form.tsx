'use client';

import React from 'react';

interface FormProps {
  onSubmit: (data: any) => void;
  children: React.ReactNode;
}

export const Form = ({ onSubmit, children }: FormProps) => {
  return (
    <form onSubmit={onSubmit} className="space-y-4">
      {children}
      <button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-md">
        Submit
      </button>
    </form>
  );
};
