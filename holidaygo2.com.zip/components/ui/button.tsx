// app/components/ui/button.tsx

import React from 'react';

interface ButtonProps {
  children: React.ReactNode;
  className?: string;
  onClick?: () => void;
}

const Button: React.FC<ButtonProps> = ({ children, className, onClick }) => {
  return (
    <button
      className={`px-4 py-2 rounded-md bg-primary text-white hover:bg-primary/80 ${className}`}
      onClick={onClick}
    >
      {children}
    </button>
  );
};

export default Button;
