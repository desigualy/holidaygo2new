// components/ui/skeleton.tsx
import React from "react";
import { cn } from "@/lib/utils";

const Skeleton: React.FC = () => {
  return (
    <div className="animate-pulse rounded-md bg-muted h-12 w-full mb-4"></div>
  );
};

export { Skeleton };
