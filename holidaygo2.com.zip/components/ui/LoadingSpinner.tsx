// components/ui/LoadingSpinner.tsx
import React from 'react';
import { cn } from '@/lib/utils';

interface LoadingSpinnerProps {
  fullScreen?: boolean;
  size?: 'sm' | 'md' | 'lg';
  text?: string;
  className?: string;
}

export const LoadingSpinner = ({
  fullScreen = false,
  size = 'md',
  text,
  className,
}: LoadingSpinnerProps) => {
  const sizeClasses = {
    sm: 'h-6 w-6 border-2',
    md: 'h-10 w-10 border-t-2 border-b-2',
    lg: 'h-16 w-16 border-4',
  };

  return (
    <div
      className={cn(
        `flex flex-col items-center justify-center ${
          fullScreen ? 'h-screen' : 'h-full py-8'
        }`,
        className
      )}
    >
      <div
        className={cn(
          `animate-spin rounded-full ${sizeClasses[size]} border-t-primary`,
          className
        )}
      ></div>
      {text && <p className="mt-4 text-sm text-muted-foreground">{text}</p>}
    </div>
  );
};

export default LoadingSpinner;
