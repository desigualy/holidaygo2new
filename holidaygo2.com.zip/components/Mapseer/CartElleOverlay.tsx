'use client';

import { useEffect, useState } from 'react';
import { getDestinationContext } from '@/context/AgentEngine';

export default function CartElleOverlay() {
  const [mood, setMood] = useState('calm');

  useEffect(() => {
    const ctx = getDestinationContext();
    setMood(ctx?.emotionalTone || 'curious');
  }, []);

  return (
    <div className="text-sm italic text-pink-600 mt-2">
      Emotional forecast: {mood === 'calm' ? 'serene skies' : 'shifting winds'}
    </div>
  );
}
