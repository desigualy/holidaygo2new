'use client';

import { useEffect, useRef } from 'react';
import Script from 'next/script';

declare global {
  interface Window {
    google: any;
    initMap: () => void;
  }
}

export default function CartaMap() {
  const mapRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (typeof window !== 'undefined') {
      window.initMap = function () {
        if (!window.google || !mapRef.current) return;

        new window.google.maps.Map(mapRef.current, {
          center: { lat: 48.8566, lng: 2.3522 }, // Paris
          zoom: 5,
        });
      };
    }
  }, []);

  return (
    <>
      <Script
        src={`https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&callback=initMap`}
        async
        defer
      />
      <div
        ref={mapRef}
        id="map"
        className="w-full h-96 rounded shadow border border-slate-800"
      />
    </>
  );
}
