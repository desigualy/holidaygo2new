// components/Mapseer/MapseerToggle.tsx

import { useState } from 'react';

interface Props {
  onToggle: (enabled: boolean) => void;
}

export default function MapseerToggle({ onToggle }: Props) {
  const [enabled, setEnabled] = useState(true);

  const toggle = () => {
    const next = !enabled;
    setEnabled(next);
    onToggle(next);
  };

  return (
    <button
      onClick={toggle}
      className={`px-4 py-2 text-sm rounded shadow font-medium transition ${
        enabled
          ? 'bg-blue-800 text-white'
          : 'bg-gray-200 text-gray-700'
      }`}
    >
      {enabled ? 'Hide Mapseer' : 'Show Mapseer'}
    </button>
  );
}
