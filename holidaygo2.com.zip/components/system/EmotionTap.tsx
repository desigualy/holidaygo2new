// components/system/EmotionTap.tsx
import React, { useState } from "react";
import { Button } from "@/components/ui/button";

const EmotionTap: React.FC = () => {
  const [emotion, setEmotion] = useState<string>("");

  const handleEmotionSelect = (emotion: string) => {
    setEmotion(emotion);
    // Additional logic for handling emotion-based input
    console.log("Selected Emotion:", emotion);
  };

  return (
    <div className="emotion-tap">
      <h2 className="text-xl font-semibold mb-4">Select Your Emotion</h2>
      <div className="flex space-x-4">
        <Button onClick={() => handleEmotionSelect("Happy")}>Happy</Button>
        <Button onClick={() => handleEmotionSelect("Sad")}>Sad</Button>
        <Button onClick={() => handleEmotionSelect("Angry")}>Angry</Button>
        <Button onClick={() => handleEmotionSelect("Surprised")}>Surprised</Button>
      </div>
      <p className="mt-4">Selected Emotion: {emotion}</p>
    </div>
  );
};

export default EmotionTap;
