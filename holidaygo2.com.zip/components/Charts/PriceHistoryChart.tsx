'use client';

interface Props {
  data: { date: string; price: number }[];
  label: string;
}

export default function PriceHistoryChart({ data, label }: Props) {
  return (
    <div className="bg-slate-800 p-4 rounded shadow text-white">
      <h2 className="text-lg font-semibold mb-2">{label}</h2>
      <ul className="text-sm space-y-1">
        {data.map((point, idx) => (
          <li key={idx}>
            {point.date}: £{point.price}
          </li>
        ))}
      </ul>
    </div>
  );
}
