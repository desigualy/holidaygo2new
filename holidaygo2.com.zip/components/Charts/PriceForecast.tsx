'use client';

import {
  LineChart,
  Line,
  XAxis,
  YAxis,
  Tooltip,
  ResponsiveContainer,
} from 'recharts';

interface ForecastPoint {
  date: string;
  price: number;
}

interface Props {
  data: ForecastPoint[];
  label: string;
}

export default function PriceForecast({ data, label }: Props) {
  return (
    <div className="bg-blue-900 text-white p-4 rounded shadow w-full h-72">
      <h2 className="text-lg font-semibold mb-2">{label}</h2>
      <ResponsiveContainer width="100%" height="100%">
        <LineChart data={data}>
          <XAxis dataKey="date" stroke="#ccc" />
          <YAxis stroke="#ccc" />
          <Tooltip />
          <Line type="monotone" dataKey="price" stroke="#38bdf8" strokeWidth={2} />
        </LineChart>
      </ResponsiveContainer>
    </div>
  );
}
