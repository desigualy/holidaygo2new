// components/Profile/ProfileSidebar.tsx

import Link from 'next/link';

interface Props {
  activeTab: string;
}

export default function ProfileSidebar({ activeTab }: Props) {
  const tabs = [
    { id: 'info', label: 'Personal Info' },
    { id: 'watchlist', label: 'Watchlist' },
    { id: 'history', label: 'History' },
    { id: 'settings', label: 'Settings' },
  ];

  return (
    <aside className="w-full sm:w-64 bg-white shadow-md rounded p-4">
      <h3 className="text-lg font-semibold mb-4">Profile</h3>
      <nav className="flex flex-col gap-2 text-sm">
        {tabs.map((tab) => (
          <Link
            key={tab.id}
            href={`/profile/${tab.id}`}
            className={`px-3 py-2 rounded ${
              activeTab === tab.id
                ? 'bg-blue-600 text-white'
                : 'text-gray-700 hover:bg-gray-100'
            }`}
          >
            {tab.label}
          </Link>
        ))}
      </nav>
    </aside>
  );
}
