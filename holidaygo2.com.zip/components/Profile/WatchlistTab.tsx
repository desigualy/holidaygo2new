// components/Profile/WatchlistTab.tsx

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { HolidayPackage } from '@/types/holiday';
import { ResultCard } from '@/components/search/ResultCard';

export default function WatchlistTab() {
  const [items, setItems] = useState<HolidayPackage[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchWatchlist = async () => {
      setLoading(true);
      const {
        data,
        error,
      } = await supabase.from('lov_watchlist').select('*').order('added_at', { ascending: false });
      if (data) setItems(data);
      setLoading(false);
    };

    fetchWatchlist();
  }, []);

  return (
    <div>
      <h2 className="text-lg font-semibold mb-4">Your Watchlist</h2>
      {loading && <p className="text-sm text-gray-500">Loading...</p>}
      {!loading && items.length === 0 && (
        <p className="text-sm text-gray-500">Nothing saved yet. Add packages to track here.</p>
      )}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4 mt-4">
        {items.map((pkg) => (
          <ResultCard key={pkg.id} pkg={pkg} />
        ))}
      </div>
    </div>
  );
}
