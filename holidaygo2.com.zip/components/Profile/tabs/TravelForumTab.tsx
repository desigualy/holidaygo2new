// components/profile/tabs/TravelForumTab.tsx
import React, { useState } from "react";
import { Button } from "@/components/ui/button";

const TravelForumTab: React.FC = () => {
  const [post, setPost] = useState<string>("");

  const handlePostChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    setPost(e.target.value);
  };

  const handlePostSubmit = () => {
    console.log("New Forum Post:", post);
    // Logic to submit a new post in the travel forum
    setPost(""); // Clear input after submit
  };

  return (
    <div className="travel-forum-tab">
      <h2 className="text-xl font-semibold mb-4">Travel Forum</h2>
      <div className="mb-4">
        <input
          type="text"
          placeholder="Share your travel tips..."
          className="p-2 w-full border rounded-md"
          value={post}
          onChange={handlePostChange}
        />
      </div>
      <Button onClick={handlePostSubmit}>Post</Button>
      <div className="mt-4">
        <h3>Recent Posts:</h3>
        {/* Logic for displaying recent posts will go here */}
      </div>
    </div>
  );
};

export default TravelForumTab;
