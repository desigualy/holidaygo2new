// components/profile/tabs/PersonalInfoTab.tsx

import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function PersonalInfoTab() {
  const [profile, setProfile] = useState<any>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const load = async () => {
      const { data, error } = await supabase.from('lov_users').select('*').single();
      if (data) setProfile(data);
      setLoading(false);
    };

    load();
  }, []);

  if (loading) {
    return <p className="text-sm text-gray-500">Loading your details...</p>;
  }

  if (!profile) {
    return <p className="text-sm text-red-500">Could not load your information.</p>;
  }

  return (
    <div className="space-y-4 text-sm">
      <div>
        <label className="block font-medium text-gray-700">Full Name</label>
        <input
          className="w-full mt-1 px-3 py-2 border border-gray-300 rounded"
          value={profile.name || ''}
          disabled
        />
      </div>
      <div>
        <label className="block font-medium text-gray-700">Email</label>
        <input
          className="w-full mt-1 px-3 py-2 border border-gray-300 rounded"
          value={profile.email || ''}
          disabled
        />
      </div>
    </div>
  );
}
