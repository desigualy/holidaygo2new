// components/profile/tabs/EmptyTab.tsx
import React from "react";

const EmptyTab: React.FC = () => {
  return (
    <div className="empty-tab">
      <h2 className="text-xl font-semibold mb-4">Empty Tab</h2>
      <p>This tab can be filled with dynamic content. Currently, it’s empty.</p>
    </div>
  );
};

export default EmptyTab;
