// components/profile/tabs/GroupTripsTab.tsx
import React, { useState } from 'react';
import { Button } from '@/components/ui/button';
import { Card, CardContent, CardFooter, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { CalendarDays, MapPin, Users } from 'lucide-react';
import { Badge } from '@/components/ui/badge';
import { useToast } from '@/hooks/use-toast';
import { Separator } from '@/components/ui/separator';

interface GroupTrip {
  id: string;
  destination: string;
  startDate: string;
  endDate: string;
  participants: number;
  description: string;
  isJoined: boolean;
}

const sampleGroupTrips: GroupTrip[] = [
  {
    id: '1',
    destination: 'Paris',
    startDate: '2025-05-15',
    endDate: '2025-05-22',
    participants: 5,
    description: 'A week in the city of love, exploring iconic landmarks and enjoying French cuisine.',
    isJoined: true,
  },
  {
    id: '2',
    destination: 'Tokyo',
    startDate: '2025-06-10',
    endDate: '2025-06-18',
    participants: 3,
    description: 'Experience the vibrant culture, delicious food, and modern technology of Japan\'s capital.',
    isJoined: false,
  },
  {
    id: '3',
    destination: 'Machu Picchu',
    startDate: '2025-07-01',
    endDate: '2025-07-08',
    participants: 8,
    description: 'Hike through the Andes to the lost city of the Incas, a breathtaking adventure.',
    isJoined: false,
  },
];

export const GroupTripsTab: React.FC = () => {
  const { toast } = useToast();
  const [trips, setTrips] = useState<GroupTrip[]>(sampleGroupTrips);

  const handleJoinTrip = (tripId: string) => {
    const updatedTrips = trips.map((trip) =>
      trip.id === tripId ? { ...trip, isJoined: true } : trip
    );
    setTrips(updatedTrips);
    toast({
      title: 'Trip joined',
      description: 'You\'ve successfully joined the trip.',
      variant: 'success',
    });
  };

  const handleLeaveTrip = (tripId: string) => {
    const updatedTrips = trips.map((trip) =>
      trip.id === tripId ? { ...trip, isJoined: false } : trip
    );
    setTrips(updatedTrips);
    toast({
      title: 'Trip left',
      description: 'You\'ve left the trip.',
      variant: 'muted',
    });
  };

  return (
    <div className="space-y-6">
      <h2 className="text-2xl font-bold">Group Trips</h2>
      <Separator />
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
        {trips.map((trip) => (
          <Card key={trip.id}>
            <CardHeader>
              <CardTitle className="flex justify-between items-start">
                {trip.destination}
                {trip.isJoined && <Badge variant="secondary">Joined</Badge>}
              </CardTitle>
              <CardDescription>{trip.description}</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <CalendarDays className="h-4 w-4" />
                {trip.startDate} - {trip.endDate}
              </div>
              <div className="flex items-center gap-2 text-sm text-muted-foreground">
                <Users className="h-4 w-4" />
                {trip.participants} Participants
              </div>
            </CardContent>
            <CardFooter className="flex justify-end">
              {trip.isJoined ? (
                <Button variant="outline" onClick={() => handleLeaveTrip(trip.id)}>
                  Leave Trip
                </Button>
              ) : (
                <Button onClick={() => handleJoinTrip(trip.id)}>Join Trip</Button>
              )}
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
};
