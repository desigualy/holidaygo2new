// components/Oracle/PriceOracle.tsx

interface Props {
  reason: string;
}

export default function PriceOracle({ reason }: Props) {
  return (
    <div
      className="absolute bottom-8 right-8 bg-white/80 text-black p-4 rounded shadow-lg text-xs max-w-xs font-mono"
      role="status"
      aria-live="polite"
    >
      <p>
        <strong>Oracle:</strong> Prediction path summoned due to <em>{reason}</em>.
      </p>
      <p className="mt-2 text-gray-600">
        Confidence matrix engaged. Forecast alignment in progress.
      </p>
    </div>
  );
}
