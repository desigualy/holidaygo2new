import { createClient } from "@/lib/supabaseClient";

const supabase = createClient();

export interface ProfileData {
  user_id: string;
  username: string;
  email: string;
  avatar_url?: string;
  created_at: string;
}

export const fetchProfileData = async (userId: string): Promise<ProfileData | null> => {
  try {
    const { data, error } = await supabase
      .from('profiles')
      .select('*')
      .eq('user_id', userId)
      .single();

    if (error) {
      throw new Error(`Failed to fetch profile: ${error.message}`);
    }

    return data as ProfileData;
  } catch (error: any) {
    console.error('Profile fetch error:', error.message);
    return null;
  }
};
