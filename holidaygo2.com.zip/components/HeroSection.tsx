// components/HeroSection.tsx

interface Props {
  userName?: string;
}

export default function HeroSection({ userName }: Props) {
  return (
    <section className="bg-gradient-to-br from-sky-100 to-white py-16 px-6 text-center">
      <h1 className="text-4xl sm:text-5xl font-extrabold text-gray-900 mb-4">
        {userName ? `Welcome back, ${userName}.` : 'Plan less. Discover more.'}
      </h1>
      <p className="text-lg text-gray-600 max-w-xl mx-auto">
        With the help of Ch@, Ms Trav-Elle, and your travel companions — find your next dream trip the natural way: through voice, feeling, and gentle curiosity.
      </p>
    </section>
  );
}
