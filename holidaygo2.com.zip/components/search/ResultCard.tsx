'use client';

interface PackageResult {
  id: string;
  destination: string;
  description: string;
  image_url: string;
  price: number;
}

interface Props {
  pkg: PackageResult;
}

export function ResultCard({ pkg }: Props) {
  return (
    <div className="border border-slate-700 rounded-lg p-4 bg-slate-900 text-white shadow">
      <img
        src={pkg.image_url}
        alt={pkg.destination}
        className="rounded w-full h-48 object-cover mb-3"
      />
      <h2 className="text-xl font-bold text-cyan-400">{pkg.destination}</h2>
      <p className="text-sm text-slate-300">{pkg.description}</p>
      <p className="mt-2 text-lg font-semibold text-green-300">£{pkg.price}</p>
    </div>
  );
}
