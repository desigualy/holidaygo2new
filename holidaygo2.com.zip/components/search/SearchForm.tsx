'use client';

import { useState } from 'react';

interface Props {
  onSearch: (query: string) => void;
}

export function SearchForm({ onSearch }: Props) {
  const [query, setQuery] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (query.trim()) onSearch(query.trim());
  };

  return (
    <form onSubmit={handleSubmit} className="flex gap-2">
      <input
        type="text"
        placeholder="Try Paris under £500"
        value={query}
        onChange={(e) => setQuery(e.target.value)}
        className="flex-grow p-2 rounded bg-slate-800 text-white"
      />
      <button
        type="submit"
        className="px-4 bg-blue-600 hover:bg-blue-700 rounded text-white"
      >
        Search
      </button>
    </form>
  );
}
