// app/components/home/LastMinuteDeals.tsx
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const LastMinuteDeals: React.FC = () => {
  return (
    <Card>
      <CardContent>
        <h2 className="text-2xl font-semibold mb-4">Last Minute Deals</h2>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          <div className="p-4 border rounded-lg">
            <img src="/images/rome.jpg" alt="Rome" className="w-full h-40 object-cover rounded-md mb-2" />
            <h3 className="font-semibold">Rome</h3>
            <p>Special offer: 30% off on flights to Rome!</p>
          </div>
          <div className="p-4 border rounded-lg">
            <img src="/images/barcelona.jpg" alt="Barcelona" className="w-full h-40 object-cover rounded-md mb-2" />
            <h3 className="font-semibold">Barcelona</h3>
            <p>Last minute holiday deals for Barcelona!</p>
          </div>
          <div className="p-4 border rounded-lg">
            <img src="/images/london.jpg" alt="London" className="w-full h-40 object-cover rounded-md mb-2" />
            <h3 className="font-semibold">London</h3>
            <p>Get amazing discounts on flights to London.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default LastMinuteDeals;
