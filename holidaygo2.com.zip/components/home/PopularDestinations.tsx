// app/components/home/PopularDestinations.tsx
import React from "react";
import { Card, CardContent } from "@/components/ui/card";

const PopularDestinations: React.FC = () => {
  return (
    <Card>
      <CardContent>
        <h2 className="text-2xl font-semibold mb-4">Popular Destinations</h2>
        <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
          <div className="p-4 border rounded-lg">
            <img src="/images/paris.jpg" alt="Paris" className="w-full h-40 object-cover rounded-md mb-2" />
            <h3 className="font-semibold">Paris</h3>
            <p>Explore the city of love and lights.</p>
          </div>
          <div className="p-4 border rounded-lg">
            <img src="/images/tokyo.jpg" alt="Tokyo" className="w-full h-40 object-cover rounded-md mb-2" />
            <h3 className="font-semibold">Tokyo</h3>
            <p>The vibrant capital of Japan.</p>
          </div>
          <div className="p-4 border rounded-lg">
            <img src="/images/newyork.jpg" alt="New York" className="w-full h-40 object-cover rounded-md mb-2" />
            <h3 className="font-semibold">New York</h3>
            <p>The city that never sleeps.</p>
          </div>
          <div className="p-4 border rounded-lg">
            <img src="/images/sydney.jpg" alt="Sydney" className="w-full h-40 object-cover rounded-md mb-2" />
            <h3 className="font-semibold">Sydney</h3>
            <p>Discover Australia’s iconic harbor city.</p>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};

export default PopularDestinations;
