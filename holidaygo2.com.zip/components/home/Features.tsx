// components/home/Features.tsx

const features = [
  {
    title: 'Voice-First Experience',
    desc: 'Interact naturally. Speak to book, plan, and explore — no typing required.',
  },
  {
    title: 'Agentic Guidance',
    desc: 'Ch@ and Ms Trav-Elle assist with planning, deals, and emotional support.',
  },
  {
    title: 'Predictive Intelligence',
    desc: 'The Oracle and Price Matrix analyze when to book — and when to wait.',
  },
  {
    title: 'Emotional Itineraries',
    desc: 'Cart-Elle maps not just places, but feelings. Travel where you resonate.',
  },
  {
    title: 'Forum & Community',
    desc: 'Ask, share, or vent. Troll keeps it real, fair, and witty.',
  },
  {
    title: 'Dark Web Trawler',
    desc: 'BladeBook returns hidden deals and cultural signals — curated by Ms Trav-Elle.',
  },
];

export default function Features() {
  return (
    <section className="py-12 bg-white px-4">
      <h2 className="text-3xl font-bold text-center text-gray-800 mb-8">Platform Features</h2>
      <div className="grid gap-6 sm:grid-cols-2 md:grid-cols-3 max-w-6xl mx-auto">
        {features.map((f, i) => (
          <div
            key={i}
            className="bg-gray-100 p-6 rounded-lg shadow-sm hover:shadow-md transition"
          >
            <h3 className="text-lg font-semibold text-gray-900 mb-2">{f.title}</h3>
            <p className="text-sm text-gray-700">{f.desc}</p>
          </div>
        ))}
      </div>
    </section>
  );
}
