// app/components/home/Newsletter.tsx
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Mail, CheckCircle, AlertCircle } from "lucide-react";

interface NewsletterProps {
  isVisible: boolean;
  onSubmit?: (email: string) => void;
}

export const Newsletter = ({ isVisible, onSubmit }: NewsletterProps) => {
  const [email, setEmail] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');
  const [errorMessage, setErrorMessage] = useState('');

  const validateEmail = (email: string): boolean => {
    const re = /^[^\s@]+@[^\s@]+\.[^\s@]+$/;
    return re.test(email);
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!validateEmail(email)) {
      setStatus('error');
      setErrorMessage('Please enter a valid email address');
      return;
    }

    setIsSubmitting(true);
    setStatus('idle');

    try {
      // Simulate API call
      await new Promise(resolve => setTimeout(resolve, 1000));

      // Call the onSubmit callback if provided
      if (onSubmit) {
        onSubmit(email);
      }

      setStatus('success');
      setEmail('');
    } catch (error) {
      console.error('Error submitting newsletter signup:', error);
      setStatus('error');
      setErrorMessage('Failed to subscribe. Please try again later.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <section
      id="newsletter"
      className="py-16 px-6 bg-gradient-to-b from-background to-blue-50 dark:to-blue-950/20"
    >
      <div className={`max-w-3xl mx-auto transition-all duration-700 ${
        isVisible ? 'opacity-100 translate-y-0' : 'opacity-0 translate-y-10'
      }`}>
        <div className="bg-white dark:bg-gray-800 rounded-xl p-8 shadow-sm border border-border">
          <div className="flex flex-col items-center text-center space-y-4">
            <div className="h-14 w-14 bg-primary/10 rounded-full flex items-center justify-center">
              <Mail className="h-7 w-7 text-primary" />
            </div>

            <h2 className="text-2xl font-bold">Get the best deals first</h2>

            <p className="text-muted-foreground max-w-md">
              Subscribe to our newsletter and we'll send you exclusive offers, travel tips, and destination guides.
            </p>

            <form onSubmit={handleSubmit} className="w-full max-w-md space-y-4 mt-4">
              <div className="relative">
                <Input
                  type="email"
                  placeholder="Your email address"
                  className="pl-4 pr-4 py-6 h-12 shadow-sm"
                  value={email}
                  onChange={(e) => setEmail(e.target.value)}
                  required
                />
              </div>

              {status === 'error' && (
                <div className="flex items-center text-red-500 text-sm">
                  <AlertCircle className="h-4 w-4 mr-2" />
                  <span>{errorMessage}</span>
                </div>
              )}

              {status === 'success' && (
                <div className="flex items-center text-green-500 text-sm">
                  <CheckCircle className="h-4 w-4 mr-2" />
                  <span>Thank you for subscribing!</span>
                </div>
              )}

              <Button
                type="submit"
                className="w-full"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Subscribing...' : 'Subscribe'}
              </Button>

              <p className="text-xs text-muted-foreground">
                By subscribing, you agree to receive marketing emails. You can unsubscribe at any time.
              </p>
            </form>
          </div>
        </div>
      </div>
    </section>
  );
};
