'use client';

export default function Hero() {
  return (
    <section className="bg-[url('https://images.unsplash.com/photo-1507525428034-b723cf961d3e?q=80&w=1600&auto=format&fit=crop')] bg-cover bg-center text-white">
      <div className="bg-black/60 py-24 px-6 text-center">
        <h1 className="text-4xl md:text-5xl font-bold mb-4">Where will your voice take you?</h1>
        <p className="text-lg text-slate-300 max-w-xl mx-auto">
          Discover AI-powered travel planning that listens, learns, and leads.  
          Say it. See it. Seal it.
        </p>
      </div>
    </section>
  );
}
