// components/NewsletterForm.tsx

import { useState } from 'react';
import { supabase } from '@/lib/supabaseClient';

export default function NewsletterForm() {
  const [email, setEmail] = useState('');
  const [status, setStatus] = useState<'idle' | 'success' | 'error'>('idle');

  const subscribe = async () => {
    if (!email || !email.includes('@')) {
      setStatus('error');
      return;
    }

    const { error } = await supabase.from('lov_newsletter').insert({ email });

    if (error) {
      setStatus('error');
    } else {
      setStatus('success');
      setEmail('');
    }
  };

  return (
    <div className="bg-white p-6 rounded shadow max-w-md mx-auto">
      <h3 className="text-lg font-semibold text-gray-800 mb-2">Subscribe to our newsletter</h3>
      <p className="text-sm text-gray-600 mb-4">
        Get travel inspiration, exclusive deals, and updates — voice-first.
      </p>
      <div className="flex gap-2">
        <input
          type="email"
          value={email}
          onChange={(e) => setEmail(e.target.value)}
          placeholder="you@email.com"
          className="w-full px-3 py-2 border border-gray-300 rounded text-sm"
        />
        <button
          onClick={subscribe}
          className="bg-blue-600 text-white px-4 py-2 rounded text-sm hover:bg-blue-700"
        >
          Subscribe
        </button>
      </div>
      {status === 'success' && (
        <p className="text-green-600 text-sm mt-2">You're in! Welcome aboard.</p>
      )}
      {status === 'error' && (
        <p className="text-red-500 text-sm mt-2">Something went wrong. Try again?</p>
      )}
    </div>
  );
}
