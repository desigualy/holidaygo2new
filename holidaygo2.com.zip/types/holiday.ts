// types/holiday.ts

export interface HolidayPackage {
  id: string;
  destination: string;
  description: string;
  price: number;
  image_url: string;
}
