export interface UserProfile {
  id: string;
  email: string;
  preferred_agent: string;
  accessibility: Record<string, any>;
  last_emotion_tag?: string;
  created_at: string;
}

export interface TravelPackage {
  id: string;
  destination: string;
  description: string;
  price: number;
  image_url: string;
  created_at: string;
}

export interface Booking {
  id: string;
  user_id: string;
  package_id: string;
  status: string;
  booked_at: string;
}

export interface SupportTicket {
  id: string;
  user_id: string;
  subject: string;
  message: string;
  status: string;
  created_at: string;
}

export interface AgentLog {
  id: string;
  user_id: string;
  agent: string;
  action: string;
  tone: string;
  timestamp: string;
}

export interface AccessibilityPrefs {
  id: string;
  user_id: string;
  font_size: 'sm' | 'md' | 'lg';
  high_contrast: boolean;
  reduced_motion: boolean;
  updated_at: string;
}

export interface EmotionSignal {
  id: string;
  user_id: string;
  signal: string;
  origin_agent: string;
  intensity: number;
  recorded_at: string;
}
