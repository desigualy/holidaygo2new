// types/agent.ts

export type AgentName =
  | 'Ch@'
  | 'Ms Trav-Elle'
  | 'Troll'
  | 'Cart-Elle'
  | 'CARTA'
  | 'The Oracle'
  | 'DogsBod-i'
  | 'He@l'
  | 'Miss Triv'
  | 'Captain F@il-Safe';

export interface AgentProfile {
  name: AgentName;
  tone: 'playful' | 'poetic' | 'disruptive' | 'silent' | 'supportive' | 'assertive';
  voice?: string;
  visible: boolean;
  domain: 'public' | 'support' | 'recovery' | 'visual' | 'fallback';
  catchphrase?: string;
}
