// types/user.ts

export interface UserProfile {
  id: string;
  email: string;
  preferredAgent: string;
  accessibility: {
    fontSize: 'sm' | 'md' | 'lg';
    highContrast: boolean;
    reducedMotion: boolean;
  };
  lastEmotionTag?: string;
}
