// @/data/jobPositions.js
export const jobPositions = [
  {
    id: "1",
    title: "Sales Executive",
    location: "New York",
    department: "Sales",
    salary: "50,000 USD",
    postedDate: "2025-05-10",
    description: "This is a description of the job.",
    responsibilities: ["Manage client accounts", "Develop sales strategies"],
    requirements: ["Bachelor's degree", "2+ years of experience"]
  },
  // Add more job positions as needed...
];
