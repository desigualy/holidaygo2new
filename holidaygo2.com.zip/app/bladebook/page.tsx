'use client';
export const runtime = 'edge';

import Link from 'next/link';

interface Entry {
  id: string;
  title: string;
  origin: string;
  rating: number;
}

export default function BladebookIndexPage() {
  const entries: Entry[] = [
    {
      id: 'b1',
      title: 'Crossing Kosovo by Bus — No ID Check',
      origin: 'TheMule',
      rating: 4.7,
    },
    {
      id: 'b2',
      title: 'Sleeping Rough in Zurich (and Surviving)',
      origin: 'GhostPass',
      rating: 4.2,
    },
    {
      id: 'b3',
      title: 'Berlin to Istanbul: 6 Border Crossings, 1 Ticket',
      origin: 'NomadicSoul',
      rating: 4.9,
    },
  ];

  return (
    <main className="px-6 py-10 max-w-4xl mx-auto text-white">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-cyan-400">BladeBook</h1>
        <Link href="/bladebook/new-entry" className="bg-teal-600 hover:bg-teal-700 text-sm px-4 py-2 rounded text-white">
          New Entry
        </Link>
      </div>

      <ul className="space-y-4">
        {entries.map((entry) => (
          <li key={entry.id} className="border border-slate-700 p-4 rounded bg-slate-900">
            <Link href={`/bladebook/entry/${entry.id}`} className="text-lg font-semibold text-teal-300">
              {entry.title}
            </Link>
            <p className="text-sm text-slate-400">by {entry.origin} · ★ {entry.rating.toFixed(1)}</p>
          </li>
        ))}
      </ul>
    </main>
  );
}
