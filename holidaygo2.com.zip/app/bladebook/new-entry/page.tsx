'use client';
export const runtime = 'edge';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function NewBladebookEntryPage() {
  const [title, setTitle] = useState('');
  const [origin, setOrigin] = useState('');
  const [story, setStory] = useState('');
  const [status, setStatus] = useState('');
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !origin || !story) {
      setStatus('All fields are required.');
      return;
    }

    // 🔁 Replace with Supabase insert later
    console.log('ENTRY:', { title, origin, story });
    setStatus('Submitted. Redirecting...');
    setTimeout(() => router.push('/bladebook'), 1000);
  };

  return (
    <main className="min-h-screen px-6 py-10 max-w-xl mx-auto text-white">
      <h1 className="text-3xl font-bold text-cyan-400 mb-6">Submit a BladeBook Entry</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Title"
          className="w-full p-2 rounded bg-slate-800 text-white"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
        />
        <input
          type="text"
          placeholder="Your Name / Handle"
          className="w-full p-2 rounded bg-slate-800 text-white"
          value={origin}
          onChange={(e) => setOrigin(e.target.value)}
        />
        <textarea
          placeholder="Your story…"
          className="w-full p-2 h-40 rounded bg-slate-800 text-white"
          value={story}
          onChange={(e) => setStory(e.target.value)}
        />
        <button type="submit" className="bg-teal-600 hover:bg-teal-700 px-4 py-2 rounded text-white">
          Submit
        </button>
        <p className="text-sm text-yellow-400">{status}</p>
      </form>
    </main>
  );
}
