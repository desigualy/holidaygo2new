'use client';
export const runtime = 'edge';

import { useParams } from 'next/navigation';

export default function BladebookEntryPage() {
  const { entryId } = useParams();

  const entries = {
    b1: {
      title: 'Crossing Kosovo by Bus — No ID Check',
      author: 'TheMule',
      body: `I crossed from Skopje into Kosovo with no ID scan. The bus just rolled through the checkpoint — no stop, no border patrol.\n\nI don't recommend this unless you're prepared for consequences, but it worked. Locals seemed unbothered.`,
    },
    b2: {
      title: 'Sleeping Rough in Zurich (and Surviving)',
      author: 'GhostPass',
      body: `Zurich is brutally expensive, but the train station's heated vestibule stayed open all night. Security passed twice, but no hassle.\n\nPro tip: free hot water at Coop cafeterias if you bring your own teabag.`,
    },
    b3: {
      title: 'Berlin to Istanbul: 6 Border Crossings, 1 Ticket',
      author: 'NomadicSoul',
      body: `Used the Balkan Flexipass. 6 countries, no digital ID required, just printed passes.\n\nMost conductors didn't even check. Overnight in Sofia train station was rough, but locals offered tea.`,
    },
  };

  const entry = entries[entryId as keyof typeof entries];

  if (!entry) {
    return (
      <main className="px-6 py-10 max-w-2xl mx-auto text-white">
        <h1 className="text-xl font-bold text-red-400">Entry Not Found</h1>
        <p className="text-slate-300">Sorry, that BladeBook entry doesn’t exist.</p>
      </main>
    );
  }

  return (
    <main className="px-6 py-10 max-w-2xl mx-auto text-white">
      <h1 className="text-3xl font-bold text-teal-300 mb-2">{entry.title}</h1>
      <p className="text-sm text-slate-400 mb-6">by {entry.author}</p>
      <article className="whitespace-pre-wrap text-slate-200 text-base leading-relaxed">
        {entry.body}
      </article>
    </main>
  );
}
