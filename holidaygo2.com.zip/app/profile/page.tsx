'use client';

import { useState, useEffect } from "react";
import { useRouter, useSearchParams } from "next/navigation";
import { ProfileSidebar } from "@/components/profile/ProfileSidebar";
import { PersonalInfoTab } from "@/components/profile/tabs/PersonalInfoTab";
import { EmptyTab } from "@/components/profile/tabs/EmptyTab";
import { WatchlistTab } from "@/components/profile/WatchlistTab";
import { TravelForumTab } from "@/components/profile/tabs/TravelForumTab";
import { GroupTripsTab } from "@/components/profile/tabs/GroupTripsTab";
import { ClipboardIcon, CreditCardIcon, HomeIcon, MessageSquareIcon, UserIcon, UsersIcon } from "lucide-react";
import { useAuthMiddleware } from "@/hooks/auth/middleware/auth-middleware";
import { LoadingSpinner } from "@/components/ui/LoadingSpinner";

export default function Profile() {
  const router = useRouter();
  const searchParams = useSearchParams();
  const { requireAuth, isLoading } = useAuthMiddleware();

  // Require authentication for this page
  requireAuth();

  // Extract tab from query params or default to dashboard
  const getInitialTab = () => {
    return searchParams.get("tab") || "dashboard";
  };

  const [activeTab, setActiveTab] = useState(getInitialTab());

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    router.push(`/profile?tab=${tab}`);
  };

  // Show loading state while checking auth
  if (isLoading) {
    return (
      <LoadingSpinner 
        fullScreen={true} 
        text="Loading your profile... Please wait while we retrieve your information."
        size="lg"
      />
    );
  }

  const renderTabContent = () => {
    switch (activeTab) {
      case "personal-info":
        return <PersonalInfoTab />;
      case "watchlist":
        return <WatchlistTab />;
      case "forum":
        return <TravelForumTab />;
      case "group-trips":
        return <GroupTripsTab />;
      case "dashboard":
        return (
          <EmptyTab 
            title="Dashboard" 
            icon={<HomeIcon size={24} />}
            description="View your travel activity, upcoming trips, and personalized recommendations."
            buttonText="Explore Deals"
            buttonAction={() => router.push("/deals")}
          />
        );
      case "favorites":
        return (
          <EmptyTab 
            title="Favorites" 
            icon={<ClipboardIcon size={24} />}
            description="Your saved destinations and travel packages will appear here."
            buttonText="Browse Destinations"
            buttonAction={() => router.push("/destinations")}
          />
        );
      case "history":
        return (
          <EmptyTab 
            title="Booking History" 
            icon={<UserIcon size={24} />}
            description="View your past bookings and travel history."
          />
        );
      case "payment":
        return (
          <EmptyTab 
            title="Payment Methods" 
            icon={<CreditCardIcon size={24} />}
            description="Manage your payment methods and billing information."
          />
        );
      default:
        return (
          <EmptyTab 
            title="Dashboard" 
            icon={<HomeIcon size={24} />}
            description="View your travel activity, upcoming trips, and personalized recommendations."
          />
        );
    }
  };

  return (
    <div className="container mx-auto py-8 px-4">
      <h1 className="text-2xl font-bold mb-8">My Profile</h1>

      <div className="flex flex-col md:flex-row gap-8">
        <ProfileSidebar activeTab={activeTab} onTabChange={handleTabChange} />

        <div className="flex-1 min-w-0">
          <div className="bg-background rounded-lg border p-6">
            {renderTabContent()}
          </div>
        </div>
      </div>
    </div>
  );
}
