// app/oracle/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import CMatrix from '@/components/Oracle/CMatrix';

export default function OraclePage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-4xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">The Oracle</h1>
        <p className="text-sm text-gray-600">
          Oracle does not speak. She shows patterns before they form. She watches, but never intervenes. She is the
          breath between collapse and continuation.
        </p>

        <div className="border p-4 rounded bg-white shadow-sm">
          <CMatrix />
        </div>

        <p className="text-xs text-gray-400">
          This module renders data from forecast logs, not real-time API calls. Accuracy is emotional, not numeric.
        </p>
      </section>
    </Layout>
  );
}
