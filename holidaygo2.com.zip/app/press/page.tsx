export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function PressPage() {
  const mentions = [
    {
      outlet: 'TechRadar',
      quote: '“HolidayGo2 is the first travel site designed with neurodiversity at its core.”',
    },
    {
      outlet: 'Skift',
      quote: '“Voice-first travel planning is no longer future tech — HolidayGo2 delivers it now.”',
    },
    {
      outlet: 'Wired UK',
      quote: '“A modular AI agent network that speaks with emotional tone? Stunning.”',
    },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Press Mentions</h1>
        <ul className="space-y-6">
          {mentions.map((m, i) => (
            <li key={i} className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
              <blockquote className="italic text-slate-300 mb-2">“{m.quote}”</blockquote>
              <div className="text-sm text-slate-400">— {m.outlet}</div>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
