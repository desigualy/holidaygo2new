export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function EchoPage() {
  return (
    <Layout>
      <section className="max-w-2xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Echo Chamber</h1>
        <p className="text-slate-300 mb-4">
          This space holds the most recent agentic pulses, emotional residues, and ritual sync logs.
        </p>

        <div className="bg-slate-900 border border-slate-700 p-4 rounded shadow space-y-2 text-sm text-slate-400">
          <p>🟢 Ms Trav-Elle pulsed: “Itinerary locked. Dream overlay stabilised.”</p>
          <p>🟡 Oracle signaled: “Price spike predicted near Lyon.”</p>
          <p>🔴 Troll disrupted: “Broken thread detected in outbound mesh.”</p>
          <p>🟣 E-Colette whisper logged: “Wake resonance captured 04:12 UTC.”</p>
          <p>🟢 Ch@ confirmed: “User tone classified: Calm / Focused.”</p>
        </div>

        <p className="text-xs text-slate-500 mt-8 italic">
          Echoes are ephemeral. They do not persist unless sealed by ritual quorum.
        </p>
      </section>
    </Layout>
  );
}
