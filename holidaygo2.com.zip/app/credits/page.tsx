export const runtime = 'edge';

import Layout from '@componentslayoutLayout';

export default function CreditsPage() {
  const credits = [
    { label 'Frontend Framework', value 'Next.js 14 (App Router)' },
    { label 'Authentication & DB', value 'Supabase' },
    { label 'Voice API', value 'Web Speech API (browser-native)' },
    { label 'Map Provider', value 'Google Maps JavaScript SDK' },
    { label 'Chart Library', value 'Recharts (forecast visualisation)' },
    { label 'Design Tokens', value 'Tailwind CSS + custom dark theme' },
    { label 'Icons', value 'Lucide + Heroicons' },
  ];

  return (
    Layout
      section className=max-w-3xl mx-auto px-6 py-10 text-white
        h1 className=text-3xl font-bold text-cyan-400 mb-6Platform Creditsh1
        ul className=space-y-4
          {credits.map((c, i) = (
            li key={i} className=flex justify-between items-center bg-slate-900 border border-slate-700 p-4 rounded shadow
              span className=text-sm text-slate-300{c.label}span
              span className=text-sm text-slate-100 font-medium{c.value}span
            li
          ))}
        ul
      section
    Layout
  );
}
