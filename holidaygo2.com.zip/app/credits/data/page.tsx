export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function DataCreditsPage() {
  const sources = [
    {
      name: 'OpenStreetMap',
      use: 'Map tiles and location lookup data',
    },
    {
      name: 'Amadeus API',
      use: 'Live flight data and price feeds',
    },
    {
      name: 'HotelsCombined API',
      use: 'Hotel meta-search and pricing',
    },
    {
      name: 'Google Maps JS SDK',
      use: 'Dynamic map rendering and geocoding',
    },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">External Data Credits</h1>
        <ul className="space-y-4">
          {sources.map((s, idx) => (
            <li key={idx} className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
              <div className="text-sm text-slate-300">
                <span className="font-semibold text-blue-300">{s.name}</span>: {s.use}
              </div>
            </li>
          ))}
        </ul>
        <p className="text-xs text-slate-600 mt-8">
          Data use conforms to public license terms of each provider. Last updated: May 2025.
        </p>
      </section>
    </Layout>
  );
}
