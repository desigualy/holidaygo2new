'use client';
export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function NewTicketPage() {
  const [subject, setSubject] = useState('');
  const [details, setDetails] = useState('');
  const [status, setStatus] = useState('');
  const router = useRouter();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    if (!subject || !details) {
      setStatus('All fields are required.');
      return;
    }

    // 🔁 Placeholder logic — replace with Supabase insert if needed
    console.log('SUPPORT TICKET:', { subject, details });
    setStatus('Ticket submitted.');
    setTimeout(() => router.push('/support/tickets'), 1000);
  };

  return (
    <Layout>
      <section className="max-w-xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">New Support Ticket</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <input
            type="text"
            placeholder="Subject"
            className="w-full p-2 rounded bg-slate-800 text-white"
            value={subject}
            onChange={(e) => setSubject(e.target.value)}
          />
          <textarea
            placeholder="Describe your issue..."
            className="w-full p-2 h-32 rounded bg-slate-800 text-white"
            value={details}
            onChange={(e) => setDetails(e.target.value)}
          />
          <button
            type="submit"
            className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-white"
          >
            Submit
          </button>
          <p className="text-sm text-yellow-400">{status}</p>
        </form>
      </section>
    </Layout>
  );
}
