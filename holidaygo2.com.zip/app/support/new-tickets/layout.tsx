// app/support/new-tickets/layout.tsx

export const runtime = 'edge';

export default function NewTicketsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
