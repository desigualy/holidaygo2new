// app/support/tickets/layout.tsx

export const runtime = 'edge';

export default function TicketsLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
