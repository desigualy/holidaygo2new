export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function TicketHistoryPage() {
  const tickets = [
    {
      id: 't1',
      subject: 'Map not loading on destination pages',
      status: 'Resolved',
      created: '2024-05-01',
    },
    {
      id: 't2',
      subject: 'Unable to login after email change',
      status: 'In Progress',
      created: '2024-05-14',
    },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-4">My Support Tickets</h1>
        <ul className="space-y-4">
          {tickets.map((ticket) => (
            <li
              key={ticket.id}
              className="bg-slate-900 border border-slate-700 p-4 rounded shadow"
            >
              <h2 className="text-lg font-semibold text-blue-300">{ticket.subject}</h2>
              <p className="text-sm text-slate-400 mb-1">
                Created: {ticket.created}
              </p>
              <span
                className={`text-xs font-medium ${
                  ticket.status === 'Resolved'
                    ? 'text-green-400'
                    : 'text-yellow-400'
                }`}
              >
                {ticket.status}
              </span>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
