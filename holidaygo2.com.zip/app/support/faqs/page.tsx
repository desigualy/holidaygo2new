export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function FAQsPage() {
  const faqs = [
    {
      question: 'Do I need an account to use HolidayGo2?',
      answer: 'Yes. Accounts are required to save searches, access past bookings, and use voice navigation features.',
    },
    {
      question: 'Is my data stored securely?',
      answer: 'All user data is encrypted and securely managed via Supabase authentication and storage policies.',
    },
    {
      question: 'Can I book a trip without using my voice?',
      answer: 'Yes. HolidayGo2 supports both voice and traditional input for all pages and searches.',
    },
    {
      question: 'What if I lose internet connection?',
      answer: 'Offline mode will activate and allow you to view saved trips, cached results, and your profile.',
    },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Frequently Asked Questions</h1>
        <ul className="space-y-6">
          {faqs.map((faq, idx) => (
            <li key={idx} className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
              <h2 className="text-lg font-semibold text-blue-300">{faq.question}</h2>
              <p className="text-sm text-slate-300 mt-2">{faq.answer}</p>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
