// app/support/FAQs/layout.tsx

export const runtime = 'edge';

export default function FaqsSupportLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
