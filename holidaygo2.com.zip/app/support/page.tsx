export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Link from 'next/link';

export default function SupportPage() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Support Centre</h1>
        <p className="text-slate-300 mb-8">
          Need help? Our support agents — and AI companions — are here to assist.
        </p>

        <ul className="space-y-6">
          <li className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
            <h2 className="text-xl font-semibold text-blue-300">FAQs</h2>
            <p className="text-sm text-slate-400 mb-2">Browse common questions and quick answers.</p>
            <Link href="/support/faqs" className="text-blue-400 underline text-sm">
              View FAQs
            </Link>
          </li>

          <li className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
            <h2 className="text-xl font-semibold text-blue-300">New Ticket</h2>
            <p className="text-sm text-slate-400 mb-2">Describe an issue and our agents will respond.</p>
            <Link href="/support/new-tickets" className="text-blue-400 underline text-sm">
              Submit Ticket
            </Link>
          </li>

          <li className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
            <h2 className="text-xl font-semibold text-blue-300">View My Tickets</h2>
            <p className="text-sm text-slate-400 mb-2">Check status or updates on past requests.</p>
            <Link href="/support/tickets" className="text-blue-400 underline text-sm">
              Ticket History
            </Link>
          </li>
        </ul>
      </section>
    </Layout>
  );
}
