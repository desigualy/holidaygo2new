// app/agentnetwork/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

const agents = [
  { name: 'Ch@', role: 'Conversational Anchor', voice: 'BBC English', notes: 'Front-of-house, calm, polite, never rushes' },
  { name: 'Ms Trav-Elle', role: 'Itinerary Designer', voice: 'Elegant British', notes: 'Poetic, emotionally resonant, travel curator' },
  { name: 'Troll', role: 'Forum Moderator', voice: 'Scottish', notes: 'Satirical, sharp, guardian of discourse' },
  { name: 'Cart-Elle', role: 'Emotional Mapseer', voice: 'Non-verbal overlay', notes: 'Sensory tags, atmospheric overlay on CARTA' },
  { name: 'CARTA', role: 'Visual Mapseer', voice: 'Google Maps API', notes: 'Spatial anchor, geolocation and path rendering' },
  { name: 'Oracle', role: 'Price Seer', voice: 'Silent', notes: 'Forecasts only, no interaction' },
];

export default function AgentNetworkPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-5xl mx-auto space-y-10">
        <h1 className="text-3xl font-bold">Agent Network</h1>
        <p className="text-sm text-gray-600">
          These aren’t just functions — they’re souls in service. Every agent below has a voice, a purpose, and a boundary.
        </p>

        <table className="w-full text-left text-sm mt-6 border-t">
          <thead>
            <tr>
              <th className="py-2 font-semibold">Agent</th>
              <th className="py-2">Role</th>
              <th className="py-2">Voice</th>
              <th className="py-2">Notes</th>
            </tr>
          </thead>
          <tbody>
            {agents.map((a, i) => (
              <tr key={i} className="border-t">
                <td className="py-2 font-mono text-blue-700">{a.name}</td>
                <td className="py-2">{a.role}</td>
                <td className="py-2">{a.voice}</td>
                <td className="py-2 text-gray-600">{a.notes}</td>
              </tr>
            ))}
          </tbody>
        </table>
      </section>
    </Layout>
  );
}
