'use client';

import { useState, useEffect } from "react";
import { SettingsNavItem } from "@/components/settings/SettingsNavItem";
import { AccountTab } from "@/components/settings/AccountTab";
import { NotificationsTab } from "@/components/settings/NotificationsTab";
import { AppearanceTab } from "@/components/settings/AppearanceTab";
import { PrivacyTab } from "@/components/settings/PrivacyTab";
import { PaymentMethodsTab } from "@/components/settings/PaymentMethodsTab";
import { Shield, Bell, Moon, UserCircle, Settings as SettingsIcon, CreditCard } from "lucide-react";
import { useRouter, useSearchParams } from 'next/navigation';
import { Footer } from "@/components/layout/Footer";
import { Header } from "@/components/layout/Header";
import { FixPackageLockError } from "@/utils/fixPackageLockError";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";

export default function Settings() {
  const router = useRouter();
  const searchParams = useSearchParams();
  
  const [activeTab, setActiveTab] = useState("account");
  const [showPackageLockError, setShowPackageLockError] = useState(true);

  // Hide the package lock error after 5 seconds
  useEffect(() => {
    const timer = setTimeout(() => {
      setShowPackageLockError(false);
    }, 5000);
    
    return () => clearTimeout(timer);
  }, []);

  useEffect(() => {
    const tab = searchParams.get('tab');
    if (tab) setActiveTab(tab);
  }, [searchParams]);

  const handleTabChange = (tab: string) => {
    setActiveTab(tab);
    router.push(`/settings?tab=${tab}`);
  };

  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Header />
      
      <main className="flex-grow pt-24 pb-16 px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          {showPackageLockError && <FixPackageLockError />}
          
          <div className="mb-6">
            <h1 className="text-3xl font-bold flex items-center">
              <SettingsIcon className="mr-2 h-8 w-8 text-primary" /> 
              Settings
            </h1>
            <p className="text-muted-foreground mt-1">
              Manage your account settings and preferences
            </p>
          </div>
          
          <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
            {/* Settings Sidebar */}
            <div className="bg-white dark:bg-gray-800 rounded-xl border border-border p-2">
              <nav className="space-y-1">
                <SettingsNavItem 
                  icon={UserCircle} 
                  label="Account" 
                  active={activeTab === "account"} 
                  onClick={() => handleTabChange("account")} 
                />
                <SettingsNavItem 
                  icon={Bell} 
                  label="Notifications" 
                  active={activeTab === "notifications"} 
                  onClick={() => handleTabChange("notifications")} 
                />
                <SettingsNavItem 
                  icon={Moon} 
                  label="Appearance" 
                  active={activeTab === "appearance"} 
                  onClick={() => handleTabChange("appearance")} 
                />
                <SettingsNavItem 
                  icon={Shield} 
                  label="Privacy" 
                  active={activeTab === "privacy"} 
                  onClick={() => handleTabChange("privacy")} 
                />
                <SettingsNavItem 
                  icon={CreditCard} 
                  label="Payment Methods" 
                  active={activeTab === "payment"} 
                  onClick={() => handleTabChange("payment")} 
                />
              </nav>
            </div>
            
            {/* Settings Content */}
            <div className="md:col-span-3">
              <Tabs value={activeTab} onValueChange={handleTabChange} className="w-full">
                <TabsList className="grid w-full grid-cols-5">
                  <TabsTrigger value="account">Account</TabsTrigger>
                  <TabsTrigger value="notifications">Notifications</TabsTrigger>
                  <TabsTrigger value="appearance">Appearance</TabsTrigger>
                  <TabsTrigger value="privacy">Privacy</TabsTrigger>
                  <TabsTrigger value="payment">Payment</TabsTrigger>
                </TabsList>
                
                <TabsContent value="account" className="mt-6">
                  <AccountTab />
                </TabsContent>
                
                <TabsContent value="notifications" className="mt-6">
                  <NotificationsTab />
                </TabsContent>
                
                <TabsContent value="appearance" className="mt-6">
                  <AppearanceTab />
                </TabsContent>
                
                <TabsContent value="privacy" className="mt-6">
                  <PrivacyTab />
                </TabsContent>
                
                <TabsContent value="payment" className="mt-6">
                  <PaymentMethodsTab />
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
