'use client';
export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { useState } from 'react';

export default function FeedbackPage() {
  const [message, setMessage] = useState('');
  const [status, setStatus] = useState('');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!message.trim()) {
      setStatus('Feedback cannot be empty.');
      return;
    }

    console.log('Feedback submitted:', message);
    setStatus('Thank you for your feedback!');
    setMessage('');
  };

  return (
    <Layout>
      <section className="max-w-xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Give Feedback</h1>
        <form onSubmit={handleSubmit} className="space-y-4">
          <textarea
            placeholder="Tell us what worked, what didn't, or what you'd love to see…"
            className="w-full h-32 p-3 rounded bg-slate-800 text-white"
            value={message}
            onChange={(e) => setMessage(e.target.value)}
          />
          <button
            type="submit"
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-white"
          >
            Submit Feedback
          </button>
          <p className="text-sm text-yellow-400">{status}</p>
        </form>
      </section>
    </Layout>
  );
}
