'use client';

import { useState, useEffect } from 'react';
import { HolidayPackage } from "@/types/holiday";
import { toast } from "sonner";
import { Tabs, TabsContent } from "@/components/ui/tabs";
import { checkPriceDrops } from '@/services/alertService';
import { DealsHeader } from '@/components/deals/DealsHeader';
import { DealsFilters } from '@/components/deals/DealsFilters';
import { DealsList } from '@/components/deals/DealsList';
import { savePriceHistoryToLocalStorage } from '@/services/priceHistoryService';
import { providers } from '@/data/providers';
import type { SearchFormValues } from '@/components/search/SearchForm';

export default function Deals() {
  const [dealPackages, setDealPackages] = useState<HolidayPackage[]>([]);
  const [filteredDeals, setFilteredDeals] = useState<HolidayPackage[]>([]);
  const [isLoading, setIsLoading] = useState(false);
  const [selectedTab, setSelectedTab] = useState("all");
  const [sortOrder, setSortOrder] = useState<'price-asc' | 'price-desc' | 'savings'>('savings');

  useEffect(() => {
    const sampleDeals: HolidayPackage[] = [/* your same mock data (deal1–deal5) here */];

    localStorage.setItem('allDeals', JSON.stringify(sampleDeals));

    sampleDeals.forEach(deal => {
      const pricePoints = [];
      const startDate = new Date();
      startDate.setMonth(startDate.getMonth() - 6);

      for (let i = 0; i < 12; i++) {
        const pointDate = new Date(startDate);
        pointDate.setDate(pointDate.getDate() + (i * 15));

        const priceVariation = (1 - (i / 24)) * 0.3;
        const randomVariation = (Math.random() - 0.3) * 0.1;

        pricePoints.push({
          date: pointDate.toISOString().split('T')[0],
          price: Math.round(deal.priceBreakdown.totalPrice * (1 + priceVariation + randomVariation)),
          isForecasted: false
        });
      }

      savePriceHistoryToLocalStorage(deal.id, pricePoints);
    });

    setDealPackages(sampleDeals);
    setFilteredDeals(sampleDeals);
  }, []);

  useEffect(() => {
    setIsLoading(true);

    setTimeout(() => {
      if (selectedTab === "all") {
        setFilteredDeals(dealPackages);
      } else if (selectedTab === "lastMinute") {
        const now = new Date();
        const lastMinuteDeals = dealPackages.filter(deal => {
          const diff = new Date(deal.departureDate).getTime() - now.getTime();
          const days = Math.ceil(diff / (1000 * 60 * 60 * 24));
          return days <= 30 && days >= 0;
        });
        setFilteredDeals(lastMinuteDeals);
      } else if (selectedTab === "familyDeals") {
        setFilteredDeals(dealPackages.filter(deal => deal.children > 0));
      } else if (selectedTab === "luxuryDeals") {
        setFilteredDeals(dealPackages.filter(deal => deal.hotelStars >= 4.8));
      }

      setIsLoading(false);
    }, 500);
  }, [selectedTab, dealPackages]);

  useEffect(() => {
    const sorted = [...filteredDeals];
    if (sortOrder === 'price-asc') {
      sorted.sort((a, b) => a.priceBreakdown.totalPrice - b.priceBreakdown.totalPrice);
    } else if (sortOrder === 'price-desc') {
      sorted.sort((a, b) => b.priceBreakdown.totalPrice - a.price
                          