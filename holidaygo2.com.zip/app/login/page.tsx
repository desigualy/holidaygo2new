'use client';
export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';

export default function LoginPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState('');
  const router = useRouter();

  const handleLogin = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('Logging in...');

    const { error } = await supabase.auth.signInWithPassword({ email, password });

    if (error) {
      setStatus('Login failed: ' + error.message);
    } else {
      setStatus('Login successful');
      router.push('/profile');
    }
  };

  return (
    <Layout>
      <section className="max-w-sm mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Login</h1>
        <form onSubmit={handleLogin} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            className="w-full p-2 rounded bg-slate-800 text-white"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-2 rounded bg-slate-800 text-white"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button
            type="submit"
            className="w-full py-2 bg-blue-600 hover:bg-blue-700 rounded"
          >
            Log In
          </button>
          <p className="text-sm text-yellow-400">{status}</p>
        </form>
      </section>
    </Layout>
  );
}
