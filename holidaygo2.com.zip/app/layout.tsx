// app/layout.tsx

import './globals.css';
import { AgentEngineProvider } from '@/context/AgentEngine';

export const metadata = {
  title: 'HolidayGo2.com',
  description: 'Your agent-powered travel companion.',
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en">
      <body>
        <AgentEngineProvider>
          {children}
        </AgentEngineProvider>
      </body>
    </html>
  );
}
