// app/error404/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function Error404Page() {
  return (
    <Layout>
      <section className="px-6 py-24 text-center max-w-xl mx-auto space-y-6">
        <h1 className="text-4xl font-bold text-red-700">Lost the trail?</h1>
        <p className="text-sm text-gray-600">
          We couldn’t find that route. Sometimes paths fade, links decay, or the soul forgets where it was going.
        </p>
        <a href="/" className="inline-block mt-4 px-6 py-2 bg-blue-600 text-white rounded text-sm hover:bg-blue-700">
          Return to Ch@
        </a>
        <p className="text-xs text-gray-400 mt-8">
          If this keeps happening, Troll or DogsBod-i will step in to reroute memory integrity.
        </p>
      </section>
    </Layout>
  );
}
