export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Link from 'next/link';

export default function UpgradeRequiredPage() {
  return (
    <Layout>
      <section className="min-h-[60vh] px-6 py-20 text-center text-white">
        <h1 className="text-3xl font-bold text-yellow-400 mb-4">Upgrade Required</h1>
        <p className="text-slate-300 mb-6 max-w-md mx-auto">
          This feature is for Premium members only. To unlock access, please upgrade your account.
        </p>
        <div className="flex justify-center gap-4">
          <Link
            href="/profile"
            className="px-4 py-2 bg-slate-700 hover:bg-slate-800 rounded text-sm"
          >
            Back to Profile
          </Link>
          <Link
            href="/upgrade"
            className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-sm"
          >
            Upgrade Now
          </Link>
        </div>
      </section>
    </Layout>
  );
}
