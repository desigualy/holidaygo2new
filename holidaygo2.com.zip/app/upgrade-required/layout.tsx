'use client';
export const runtime = 'edge';

import Link from 'next/link';

export default function UpgradeRequiredPage() {
  return (
    <main className="min-h-screen flex flex-col justify-center items-center px-6 text-white bg-slate-950 text-center">
      <h1 className="text-3xl font-bold text-yellow-400 mb-4">Upgrade Required</h1>
      <p className="text-slate-300 mb-6 max-w-md">
        This feature is available to Premium or Hotbox-tier users only. To continue, please upgrade your plan or return to free-tier access.
      </p>
      <div className="flex gap-4">
        <Link
          href="/profile"
          className="px-4 py-2 bg-gray-600 hover:bg-gray-700 rounded text-sm"
        >
          Return to Profile
        </Link>
        <Link
          href="/upgrade"
          className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-sm"
        >
          View Upgrade Options
        </Link>
      </div>
    </main>
  );
}
