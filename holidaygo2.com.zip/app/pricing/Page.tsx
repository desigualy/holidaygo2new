// app/pricing/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import PriceForecast from '@/components/Charts/PriceForecast';
import PriceHistoryChart from '@/components/Charts/PriceHistoryChart';

const forecastData = [
  { date: 'Mon', price: 410 },
  { date: 'Tue', price: 420 },
  { date: 'Wed', price: 440 },
  { date: 'Thu', price: 430 },
  { date: 'Fri', price: 455 },
];

const historyData = [
  { date: 'Jan', price: 390 },
  { date: 'Feb', price: 415 },
  { date: 'Mar', price: 430 },
  { date: 'Apr', price: 400 },
  { date: 'May', price: 420 },
];

export default function PricingPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-5xl mx-auto space-y-10">
        <h1 className="text-3xl font-bold">Pricing Intelligence</h1>
        <p className="text-sm text-gray-600">
          Forecasts provided by The Oracle — never promotional, always predictive. Ms Trav-Elle filters anomalies.
        </p>

        <PriceForecast data={forecastData} label="Forecast: Next 5 Days" />
        <PriceHistoryChart data={historyData} label="Historical Averages" />
      </section>
    </Layout>
  );
}
