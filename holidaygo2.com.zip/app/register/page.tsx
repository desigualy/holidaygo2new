'use client';
export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { useState } from 'react';
import { useRouter } from 'next/navigation';
import { supabase } from '@/lib/supabaseClient';

export default function RegisterPage() {
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [status, setStatus] = useState('');
  const router = useRouter();

  const handleRegister = async (e: React.FormEvent) => {
    e.preventDefault();
    setStatus('Registering...');

    const { error } = await supabase.auth.signUp({ email, password });

    if (error) {
      setStatus('Registration failed: ' + error.message);
    } else {
      setStatus('Registration successful');
      setTimeout(() => router.push('/profile'), 1000);
    }
  };

  return (
    <Layout>
      <section className="max-w-sm mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Create Account</h1>
        <form onSubmit={handleRegister} className="space-y-4">
          <input
            type="email"
            placeholder="Email"
            className="w-full p-2 rounded bg-slate-800 text-white"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <input
            type="password"
            placeholder="Password"
            className="w-full p-2 rounded bg-slate-800 text-white"
            value={password}
            onChange={(e) => setPassword(e.target.value)}
            required
          />
          <button
            type="submit"
            className="w-full py-2 bg-green-600 hover:bg-green-700 rounded"
          >
            Register
          </button>
          <p className="text-sm text-yellow-400">{status}</p>
        </form>
      </section>
    </Layout>
  );
}
