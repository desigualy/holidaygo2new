// app/reviews/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

const testimonials = [
  {
    name: 'Elise',
    quote:
      'I didn’t know what I needed until Ms Trav-Elle suggested a quiet retreat in Malta. I never would have searched for it — but it was exactly what I needed.',
  },
  {
    name: 'Marcus',
    quote:
      'I spoke to Ch@ out loud for ten minutes before realizing how much tension I’d been carrying. He helped me find a deal, but more importantly, he listened.',
  },
  {
    name: 'Sadia',
    quote:
      'The forum gave me answers — but Troll gave me courage. That agent’s no joke.',
  },
];

export default function ReviewsPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-4xl mx-auto space-y-10">
        <h1 className="text-3xl font-bold">Traveler Reflections</h1>
        <p className="text-sm text-gray-600">These aren’t reviews — they’re echoes.</p>

        {testimonials.map((item, i) => (
          <div key={i} className="border-l-4 border-blue-600 pl-4">
            <p className="text-gray-700 italic">“{item.quote}”</p>
            <p className="text-sm text-blue-800 mt-1">— {item.name}</p>
          </div>
        ))}
      </section>
    </Layout>
  );
}
