// app/Itinerary/page.tsx

import { Metadata } from 'next';
import Layout from '@/components/layout/Layout';

export const metadata: Metadata = {
  title: 'Your Itinerary · HolidayGo2',
  description: 'View and edit your current trip plan — emotional rhythm included.',
};

const example = [
  {
    day: 'Day 1',
    place: 'Barcelona, Gothic Quarter',
    mood: 'Excitement / Curiosity',
    detail: 'Evening tapas walk, optional bike rental.',
  },
  {
    day: 'Day 2',
    place: 'Montserrat Hike',
    mood: 'Calm / Elevation',
    detail: 'Day trip by train, packed lunch included.',
  },
  {
    day: 'Day 3',
    place: 'El Born + Farewell Dinner',
    mood: 'Nostalgia / Reflection',
    detail: 'Flamenco experience and final toast.',
  },
];

export default function ItineraryPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Your Emotional Itinerary</h1>
        <p className="text-sm text-gray-600 mb-6">
          Below is a sample structure curated by Ms Trav-Elle and Cart-Elle. Your version will evolve as you interact with the platform.
        </p>
        <ul className="space-y-4 text-sm">
          {example.map((item, i) => (
            <li key={i} className="bg-white p-4 border rounded shadow-sm">
              <p className="font-semibold text-gray-800">{item.day} · {item.place}</p>
              <p className="text-blue-700 italic">{item.mood}</p>
              <p className="text-gray-600">{item.detail}</p>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
