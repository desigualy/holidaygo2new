'use client';
export const runtime = 'edge';

import { useState } from 'react';
import { useParams, useRouter } from 'next/navigation';

export default function EditItineraryPage() {
  const { tripId } = useParams();
  const router = useRouter();

  const [destination, setDestination] = useState('Lisbon');
  const [date, setDate] = useState('2024-07-14');
  const [nights, setNights] = useState(4);
  const [total, setTotal] = useState(489);
  const [highlights, setHighlights] = useState('Belem Tower\nTram 28\nBairro Alto');

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    // 🔁 Replace with DB update logic
    console.log('UPDATED TRIP:', { destination, date, nights, highlights, total });
    router.push(`/itinerary/view/${tripId}`);
  };

  return (
    <main className="px-6 py-10 max-w-xl mx-auto text-white">
      <h1 className="text-3xl font-bold text-cyan-400 mb-6">Edit Itinerary</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          className="w-full p-2 rounded bg-slate-800 text-white"
          value={destination}
          onChange={(e) => setDestination(e.target.value)}
          placeholder="Destination"
        />
        <input
          type="date"
          className="w-full p-2 rounded bg-slate-800 text-white"
          value={date}
          onChange={(e) => setDate(e.target.value)}
        />
        <input
          type="number"
          className="w-full p-2 rounded bg-slate-800 text-white"
          value={nights}
          onChange={(e) => setNights(Number(e.target.value))}
          placeholder="Nights"
        />
        <textarea
          className="w-full p-2 h-24 rounded bg-slate-800 text-white"
          value={highlights}
          onChange={(e) => setHighlights(e.target.value)}
          placeholder="Highlights (one per line)"
        />
        <input
          type="number"
          className="w-full p-2 rounded bg-slate-800 text-white"
          value={total}
          onChange={(e) => setTotal(Number(e.target.value))}
          placeholder="Total Cost"
        />
        <button
          type="submit"
          className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-white"
        >
          Save Itinerary
        </button>
      </form>
    </main>
  );
}
