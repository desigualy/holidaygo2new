'use client';
export const runtime = 'edge';

import { useParams } from 'next/navigation';

interface TripData {
  destination: string;
  date: string;
  nights: number;
  highlights: string[];
  total: number;
}

export default function ViewItineraryPage() {
  const { tripId } = useParams();

  const trips: Record<string, TripData> = {
    t1: {
      destination: 'Lisbon',
      date: '2024-07-14',
      nights: 4,
      highlights: ['Belem Tower', 'Tram 28 ride', 'Bairro Alto food tour'],
      total: 489,
    },
    t2: {
      destination: 'Athens',
      date: '2024-08-09',
      nights: 5,
      highlights: ['Acropolis', 'Island ferry', 'Street art walk'],
      total: 525,
    },
  };

  const trip = trips[tripId as keyof typeof trips];

  if (!trip) {
    return (
      <main className="px-6 py-10 max-w-xl mx-auto text-white">
        <h1 className="text-xl font-bold text-red-400">Trip not found</h1>
        <p className="text-slate-400">No saved itinerary for ID: {tripId}</p>
      </main>
    );
  }

  return (
    <main className="px-6 py-10 max-w-xl mx-auto text-white">
      <h1 className="text-3xl font-bold text-cyan-400 mb-2">{trip.destination} Itinerary</h1>
      <p className="text-slate-300 mb-4">
        Departing: <strong>{trip.date}</strong> · {trip.nights} nights · £{trip.total}
      </p>

      <h2 className="text-xl font-semibold mb-2">Trip Highlights</h2>
      <ul className="list-disc list-inside text-slate-200 space-y-1">
        {trip.highlights.map((h, idx) => (
          <li key={idx}>{h}</li>
        ))}
      </ul>
    </main>
  );
}
