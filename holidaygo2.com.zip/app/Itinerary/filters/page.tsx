'use client';
export const runtime = 'edge';

import { useState } from 'react';
import { ResultCard } from '@/components/search/ResultCard';

interface TripOption {
  id: string;
  destination: string;
  description: string;
  image_url: string;
  price: number;
  duration: number;
}

export default function ItineraryFiltersPage() {
  const [maxPrice, setMaxPrice] = useState(500);
  const [duration, setDuration] = useState(4);

  const allTrips: TripOption[] = [
    {
      id: '1',
      destination: 'Porto',
      description: '3 nights · riverside hotel · wine tasting',
      image_url: '/images/porto.jpg',
      price: 389,
      duration: 3,
    },
    {
      id: '2',
      destination: 'Budapest',
      description: '4 nights · thermal spa · Danube dinner',
      image_url: '/images/budapest.jpg',
      price: 449,
      duration: 4,
    },
    {
      id: '3',
      destination: 'Copenhagen',
      description: '5 nights · design hotel · bike tour',
      image_url: '/images/copenhagen.jpg',
      price: 610,
      duration: 5,
    },
  ];

  const filtered = allTrips.filter((t) => t.price <= maxPrice && t.duration <= duration);

  return (
    <main className="px-6 py-10 max-w-5xl mx-auto text-white">
      <h1 className="text-3xl font-bold text-cyan-400 mb-6">Itinerary Filters</h1>

      <form className="grid gap-4 mb-6 md:grid-cols-2">
        <label className="flex flex-col">
          Max Price (£)
          <input
            type="range"
            min={100}
            max={1000}
            step={50}
            value={maxPrice}
            onChange={(e) => setMaxPrice(Number(e.target.value))}
          />
          <span className="text-sm text-slate-400">£{maxPrice}</span>
        </label>

        <label className="flex flex-col">
          Max Duration (nights)
          <input
            type="range"
            min={1}
            max={7}
            step={1}
            value={duration}
            onChange={(e) => setDuration(Number(e.target.value))}
          />
          <span className="text-sm text-slate-400">{duration} nights</span>
        </label>
      </form>

      {filtered.length === 0 ? (
        <p className="text-slate-400">No matching trips.</p>
      ) : (
        <div className="grid gap-4">
          {filtered.map((trip) => (
            <ResultCard key={trip.id} pkg={trip} />
          ))}
        </div>
      )}
    </main>
  );
}
