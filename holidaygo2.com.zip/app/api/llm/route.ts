// app/api/llm/route.ts

import { NextRequest, NextResponse } from 'next/server';

export async function POST(req: NextRequest) {
  const { input } = await req.json();

  // Replace this mock logic with your real LLM call
  const output = `Echo: ${input}`;

  return NextResponse.json({ output });
}
