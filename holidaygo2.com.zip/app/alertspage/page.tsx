'use client';

import { Bell, Clock, Filter, PlusCircle, Search } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from '@/components/ui/card';

export default function AlertsPage() {
  const mockAlerts = [
    {
      id: 1,
      destination: "Bali, Indonesia",
      price: 899,
      threshold: 950,
      createdAt: "2023-11-10",
      status: "active"
    },
    {
      id: 2,
      destination: "Barcelona, Spain",
      price: 349,
      threshold: 400,
      createdAt: "2023-11-05",
      status: "active"
    },
    {
      id: 3,
      destination: "Maldives",
      price: 1299,
      threshold: 1500,
      createdAt: "2023-10-28",
      status: "active"
    }
  ];

  return (
    <div className="container mx-auto py-8 px-4">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center mb-6 gap-4">
        <div>
          <h1 className="text-3xl font-bold flex items-center">
            <Bell className="mr-2 h-6 w-6" /> Price Alerts
          </h1>
          <p className="text-muted-foreground mt-1">
            Get notified when prices drop for your favorite destinations
          </p>
        </div>

        <div className="flex flex-col sm:flex-row gap-2 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2 top-1/2 transform -translate-y-1/2 h-4 w-4 text-muted-foreground" />
            <Input placeholder="Search alerts..." className="pl-8" />
          </div>
          <Button variant="outline" size="icon">
            <Filter className="h-4 w-4" />
          </Button>
          <Button>
            <PlusCircle className="mr-2 h-4 w-4" />
            Create Alert
          </Button>
        </div>
      </div>

      <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
        {mockAlerts.map(alert => (
          <Card key={alert.id}>
            <CardHeader>
              <CardTitle>{alert.destination}</CardTitle>
              <CardDescription className="flex items-center">
                <Clock className="h-4 w-4 mr-1" />
                Created on {alert.createdAt}
              </CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Current Price:</span>
                  <span className="font-semibold text-primary">£{alert.price}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Alert Threshold:</span>
                  <span className="font-semibold">£{alert.threshold}</span>
                </div>
                <div className="flex justify-between items-center">
                  <span className="text-muted-foreground">Status:</span>
                  <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-xs font-medium bg-green-100 text-green-800">
                    {alert.status}
                  </span>
                </div>
              </div>
            </CardContent>
            <CardFooter className="flex justify-between">
              <Button variant="outline" size="sm">Edit</Button>
              <Button variant="ghost" size="sm" className="text-destructive">Delete</Button>
            </CardFooter>
          </Card>
        ))}
      </div>
    </div>
  );
}
