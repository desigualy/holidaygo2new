export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Link from 'next/link';

export default function LegalIndexPage() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Legal & Compliance</h1>
        <p className="text-slate-300 mb-6">
          HolidayGo2 is committed to protecting your rights and ensuring transparency. Below are all formal policies, declarations, and compliance routes.
        </p>

        <ul className="space-y-4">
          <li>
            <Link href="/privacy" className="text-blue-400 underline text-sm">
              Privacy Policy
            </Link>
          </li>
          <li>
            <Link href="/terms" className="text-blue-400 underline text-sm">
              Terms & Conditions
            </Link>
          </li>
          <li>
            <Link href="/cookies" className="text-blue-400 underline text-sm">
              Cookie Policy
            </Link>
          </li>
          <li>
            <Link href="/accessibility" className="text-blue-400 underline text-sm">
              Accessibility Standards
            </Link>
          </li>
        </ul>
      </section>
    </Layout>
  );
}
