export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function VoiceControlHelpPage() {
  const commands = [
    { phrase: 'Search for Paris under 500', action: 'Performs a filtered package search' },
    { phrase: 'Show me my profile', action: 'Navigates to your profile dashboard' },
    { phrase: 'Open Bladebook', action: 'Takes you to the travel survival guide' },
    { phrase: 'What is the Oracle saying?', action: 'Displays predictive travel advice' },
    { phrase: 'Plan a trip to Lisbon', action: 'Triggers CARTA + itinerary lock' },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Voice Command Reference</h1>
        <p className="text-slate-300 mb-8">
          HolidayGo2 supports natural speech across search, navigation, and booking. No keywords. Just speak.
        </p>

        <ul className="space-y-4">
          {commands.map((cmd, idx) => (
            <li key={idx} className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
              <p className="text-lg text-blue-300 font-semibold">“{cmd.phrase}”</p>
              <p className="text-sm text-slate-400">{cmd.action}</p>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
