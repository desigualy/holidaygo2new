'use client';
export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { useEffect, useState } from 'react';

export default function FontAdjustmentsPage() {
  const [fontSize, setFontSize] = useState(100);

  useEffect(() => {
    document.documentElement.style.fontSize = `${fontSize}%`;
    return () => {
      document.documentElement.style.fontSize = '100%';
    };
  }, [fontSize]);

  return (
    <Layout>
      <section className="max-w-xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Adjust Font Size</h1>
        <p className="text-slate-300 mb-6">
          Increase or decrease text across the site to suit your reading preference.
        </p>

        <label className="block mb-6">
          <span className="text-sm text-slate-400">Font Size: {fontSize}%</span>
          <input
            type="range"
            min={80}
            max={150}
            step={5}
            value={fontSize}
            onChange={(e) => setFontSize(Number(e.target.value))}
            className="w-full mt-2"
          />
        </label>

        <div className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
          <p className="text-base text-slate-200">
            This is a live preview of your current font setting.
          </p>
        </div>
      </section>
    </Layout>
  );
}
