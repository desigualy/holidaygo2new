export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Link from 'next/link';

export default function AccessibilityPage() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Accessibility Options</h1>
        <p className="text-slate-300 mb-8">
          HolidayGo2 is built for neurodiverse, visually impaired, and voice-first users. You may customize the experience below.
        </p>

        <ul className="space-y-6">
          <li className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
            <h2 className="text-xl font-semibold text-blue-300">Voice Control</h2>
            <p className="text-sm text-slate-400 mb-2">Use natural commands like “Search Paris under 500.”</p>
            <Link href="/accessibility/voice-control" className="text-blue-400 underline text-sm">
              View supported voice commands
            </Link>
          </li>

          <li className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
            <h2 className="text-xl font-semibold text-blue-300">Font Adjustment</h2>
            <p className="text-sm text-slate-400 mb-2">Resize text to suit your reading style and comfort.</p>
            <Link href="/accessibility/font-adjustments" className="text-blue-400 underline text-sm">
              Adjust font size
            </Link>
          </li>
        </ul>
      </section>
    </Layout>
  );
}
