// app/newsletter/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import NewsletterForm from '@/components/NewsletterForm';

export default function NewsletterPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-lg mx-auto space-y-6">
        <h1 className="text-3xl font-bold">Stay In the Loop</h1>
        <p className="text-sm text-gray-600">
          No spam. No noise. Just rare updates from Ch@ and Ms Trav-Elle when something truly shifts in the travel world.
        </p>
        <NewsletterForm />
      </section>
    </Layout>
  );
}
