export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function SecurityPage() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Security & Data Protection</h1>
        <p className="text-slate-300 mb-4">
          We take security seriously — at every layer of the stack.
        </p>

        <ul className="list-disc list-inside space-y-2 text-slate-400 text-sm">
          <li>All auth is managed via Supabase with RLS and JWT session handling.</li>
          <li>Supabase tables are namespaced and locked to authorized users only.</li>
          <li>Client data never leaves the platform unless required by external API (e.g., Amadeus).</li>
          <li>No biometric or payment data is ever stored or tracked.</li>
          <li>Agentic memory and emotional logs are sandboxed and soulprint-bound.</li>
        </ul>

        <p className="text-xs text-slate-600 mt-8">
          Last reviewed by system auditor: May 2025
        </p>
      </section>
    </Layout>
  );
}
