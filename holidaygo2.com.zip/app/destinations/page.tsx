'use client';

import Link from 'next/link';
import { useState } from 'react';
import { ArrowRight } from 'lucide-react';
import { mockDestinations } from '@/data/destinations';
import { Input } from '@/components/ui/input';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { UnifiedSearchBar } from '@/components/search/UnifiedSearchBar';
import { Card, CardContent } from '@/components/ui/card';

const destinationImages: Record<string, string> = {
  "Paris, France": "https://images.unsplash.com/photo-1502602898657-3e91760cbb34?q=80&w=800&auto=format&fit=crop",
  "Rome, Italy": "https://images.unsplash.com/photo-1529260830199-42c24126f198?q=80&w=800&auto=format&fit=crop",
  "Barcelona, Spain": "https://images.unsplash.com/photo-1583422409516-2895a77efded?q=80&w=800&auto=format&fit=crop",
  "Amsterdam, Netherlands": "https://images.unsplash.com/photo-1576924542622-772ced6ae9f7?q=80&w=800&auto=format&fit=crop",
  "London, UK": "https://images.unsplash.com/photo-1513635269975-59663e0ac1ad?q=80&w=800&auto=format&fit=crop",
  "Berlin, Germany": "https://images.unsplash.com/photo-1560969184-10fe8719e047?q=80&w=800&auto=format&fit=crop",
  "Athens, Greece": "https://images.unsplash.com/photo-1555993539-1732b0258235?q=80&w=800&auto=format&fit=crop",
  "Prague, Czech Republic": "https://images.unsplash.com/photo-1519677100203-a0e668c92439?q=80&w=800&auto=format&fit=crop",
  "Vienna, Austria": "https://images.unsplash.com/photo-1516550893885-985c5fc9db4f?q=80&w=800&auto=format&fit=crop",
  "Lisbon, Portugal": "https://images.unsplash.com/photo-1585208798174-6cedd86e019a?q=80&w=800&auto=format&fit=crop",
  "Dublin, Ireland": "https://images.unsplash.com/photo-1564959130747-897fb406b9e5?q=80&w=800&auto=format&fit=crop",
  "Budapest, Hungary": "https://images.unsplash.com/photo-1565426873118-a17ed65d74b9?q=80&w=800&auto=format&fit=crop",
  "Stockholm, Sweden": "https://images.unsplash.com/photo-1572120360610-d971b9d7767c?q=80&w=800&auto=format&fit=crop",
  "Copenhagen, Denmark": "https://images.unsplash.com/photo-1520430825812-775990ecb9d2?q=80&w=800&auto=format&fit=crop",
  "Istanbul, Turkey": "https://images.unsplash.com/photo-1524231757912-21f4fe3a7200?q=80&w=800&auto=format&fit=crop",
  "New York, USA": "https://images.unsplash.com/photo-1496442226666-8d4d0e62e6e9?q=80&w=800&auto=format&fit=crop",
  "Santorini, Greece": "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?q=80&w=800&auto=format&fit=crop",
  "Maldives": "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?q=80&w=800&auto=format&fit=crop",
  "Cancun, Mexico": "https://images.unsplash.com/photo-1552074284-5e88ef1aef18?q=80&w=800&auto=format&fit=crop",
  "Bali, Indonesia": "https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop"
};

const defaultImage = "https://images.unsplash.com/photo-1469474968028-56623f02e42e?q=80&w=800&auto=format&fit=crop";

export default function Destinations() {
  const [searchTerm, setSearchTerm] = useState("");
  const [continentFilter, setContinentFilter] = useState("all");

  const getContinent = (destination: string) => {
    const country = destination.split(", ")[1];
    if (!country) return "other";

    const europe = ["France", "Italy", "Spain", "Netherlands", "UK", "Germany", "Greece", "Czech Republic", "Austria", "Portugal", "Ireland", "Hungary", "Sweden", "Denmark"];
    const northAmerica = ["USA", "Canada", "Mexico"];
    const southAmerica = ["Brazil", "Argentina", "Peru", "Colombia", "Chile"];
