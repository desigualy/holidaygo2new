// app/gallery/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

const images = [
  { src: '/gallery/beach.jpg', alt: 'Tide-kissed shores' },
  { src: '/gallery/mountain.jpg', alt: 'Morning mist over peaks' },
  { src: '/gallery/city.jpg', alt: 'Golden light on rooftops' },
];

export default function GalleryPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold mb-4">Visual Journal</h1>
        <p className="text-sm text-gray-600 mb-6">
          Curated by Cart-Elle. Every image is emotionally tagged and softly framed — not just where, but how it feels.
        </p>

        <div className="grid sm:grid-cols-2 md:grid-cols-3 gap-4">
          {images.map((img, i) => (
            <div key={i} className="overflow-hidden rounded shadow-sm">
              <img src={img.src} alt={img.alt} className="object-cover w-full h-48" />
              <p className="text-xs text-gray-500 mt-1 text-center">{img.alt}</p>
            </div>
          ))}
        </div>
      </section>
    </Layout>
  );
}
