export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Link from 'next/link';

export default function NotFoundPage() {
  return (
    <Layout>
      <section className="min-h-[60vh] px-6 py-20 text-center text-white">
        <h1 className="text-5xl font-bold text-red-400 mb-4">404</h1>
        <p className="text-lg text-slate-300 mb-6">
          The page you’re looking for doesn’t exist or was moved.
        </p>
        <Link
          href="/"
          className="inline-block px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded text-white text-sm"
        >
          Return Home
        </Link>
      </section>
    </Layout>
  );
}
