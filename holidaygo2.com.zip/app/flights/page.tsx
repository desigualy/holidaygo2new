'use client';

import { useState } from 'react';
import { Calendar as CalendarIcon, Search, Plane, MapPin, Users, ArrowRight, X, Clock, Loader2 } from 'lucide-react';
import { format } from 'date-fns';
import { cn } from '@/lib/utils';
import { Button } from '@/components/ui/button';
import { Calendar } from '@/components/ui/calendar';
import { Popover, PopoverContent, PopoverTrigger } from '@/components/ui/popover';
import { Input } from '@/components/ui/input';
import { Card, CardContent, CardDescription, CardHeader, CardTitle, CardFooter } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from '@/components/ui/tabs';
import { Alert, AlertDescription } from '@/components/ui/alert';
import { Badge } from '@/components/ui/badge';
import { ToggleGroup, ToggleGroupItem } from '@/components/ui/toggle-group';
import { toast } from 'sonner';
import { 
  searchFlights, 
  searchAirports, 
  FlightSearchParams, 
  Flight, 
  Airport 
} from '@/services/flightService';
import { useNavigate } from 'react-router-dom';
import { MultiCityForm } from '@/components/search/forms/components/MultiCityForm';
import { searchAirports as globalSearchAirports } from '@/data/airports';

export default function Flights() {
  const [from, setFrom] = useState('');
  const [to, setTo] = useState('');
  const [departDate, setDepartDate] = useState<Date>();
  const [returnDate, setReturnDate] = useState<Date>();
  const [passengers, setPassengers] = useState('1');
  const [cabinClass, setCabinClass] = useState<'economy' | 'premium_economy' | 'business' | 'first'>('economy');
  const [tripType, setTripType] = useState<'round-trip' | 'one-way' | 'multi-city'>('round-trip');
  const navigate = useNavigate();
  
  const [searchTriggered, setSearchTriggered] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [flights, setFlights] = useState<Flight[]>([]);
  const [airportSuggestions, setAirportSuggestions] = useState<{ from: Airport[], to: Airport[] }>({
    from: [],
    to: []
  });
  const [selectedSort, setSelectedSort] = useState<'price' | 'duration' | 'departure'>('price');
  
  const searchForAirports = async (query: string, type: 'from' | 'to') => {
    if (query.length >= 2) {
      const globalResults = globalSearchAirports(query);
      
      if (globalResults.length > 0) {
        const convertedResults: Airport[] = globalResults.map(airport => ({
          name: airport.name,
          iata: airport.iata,
          city: airport.city,
          country: airport.country
        }));
        
        if (type === 'from') {
          setAirportSuggestions(prev => ({ ...prev, from: convertedResults.slice(0, 10) }));
        } else {
          setAirportSuggestions(prev => ({ ...prev, to: convertedResults.slice(0, 10) }));
        }
      } else {
        const results = await searchAirports(query);
        if (type === 'from') {
          setAirportSuggestions(prev => ({ ...prev, from: results }));
        } else {
          setAirportSuggestions(prev => ({ ...prev, to: results }));
        }
      }
    } else {
      if (type === 'from') {
        setAirportSuggestions(prev => ({ ...prev, from: [] }));
      } else {
        setAirportSuggestions(prev => ({ ...prev, to: [] }));
      }
    }
  };
  
  const selectAirport = (airport: Airport, type: 'from' | 'to') => {
    if (type === 'from') {
      setFrom(airport.iata);
      setAirportSuggestions(prev => ({ ...prev, from: [] }));
    } else {
      setTo(airport.iata);
      setAirportSuggestions(prev => ({ ...prev, to: [] }));
    }
  };

  const handleSearch = async () => {
    if (tripType === 'multi-city') {
      return;
    }
    
    if (!from) {
      toast.error("Please select a departure airport");
      return;
    }
    
    if (!to) {
      toast.error("Please select a destination airport");
      return;
    }
    
    if (!departDate) {
      toast.error("Please select a departure date");
      return;
    }
    
    if (tripType === 'round-trip' && !returnDate) {
      toast.error("Please select a return date");
      return;
    }
    
    setIsLoading(true);
    setSearchTriggered(true);
    
    try {
      const searchParams: FlightSearchParams = {
        origin: from,
        destination: to,
        departureDate: departDate.toISOString().split('T')[0],
        adults: parseInt(passengers),
        tripType: tripType === 'round-trip' ? 'roundTrip' : 'oneWay',
        cabinClass: cabinClass
      };
      
      if (returnDate && tripType === 'round-trip') {
        searchParams.returnDate = returnDate.toISOString().split('T')[0];
      }
      
      const flightResults = await searchFlights(searchParams);
      setFlights(flightResults);
      
      if (flightResults.length === 0) {
        toast.info("No flights found matching your criteria. Try different dates or airports.");
      } else {
        toast.success(`Found ${flightResults.length} flights matching your criteria`);
      }
    } catch (error) {
      console.error('Search error:', error);
      toast.error("An error occurred while searching for flights. Please try again later.");
      setFlights([]);
    } finally {
      setIsLoading(false);
    }
  };
  
  const sortFlights = (flights: Flight[], sortBy: 'price' | 'duration' | 'departure') => {
    if (!flights.length) return [];
    
    const flightsCopy = [...flights];
    
    switch (sortBy) {
      case 'price':
        return flightsCopy.sort((a, b) => a.price - b.price);
      case 'duration':
        return flightsCopy.sort((a, b) => {
          const getDurationMinutes = (duration: string) => {
            const [hours, minutes] = duration.split('h ').map(part => parseInt(part.replace('m', '')));
            return hours * 60 + minutes;
          };
          return getDurationMinutes(a.duration) - getDurationMinutes(b.duration);
        });
      case 'departure':
        return flightsCopy.sort((a, b) => {
          const getMinutes = (time: string) => {
            const [hours, minutes] = time.split(':').map(Number);
            return hours * 60 + minutes;
          };
          return getMinutes(a.departure.time) - getMinutes(b.departure.time);
        });
      default:
        return flightsCopy;
    }
  };
  
  const sortedFlights = sortFlights(flights, selectedSort);

  const handleViewDestination = (city: string) => {
    setTo(city);
    setSearchTriggered(true);
    
    if (departDate && from) {
      handleSearch();
    } else {
      window.scrollTo({
        top: 0,
        behavior: 'smooth'
      });
      
      toast.info("Please complete your search details to view flights to " + city);
    }
  };

  return (
    <div className="container mx-auto px-4 py-6">
      <h1 className="text-3xl font-bold mb-6">Find the Best Flight Deals</h1>
      
      <Card className="mb-8">
        <CardHeader>
          <CardTitle>Flight Search</CardTitle>
          <CardDescription>Search for flights to destinations worldwide</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs 
            defaultValue={tripType} 
            className="w-full" 
            onValueChange={(value) => setTripType(value as 'round-trip' | 'one-way' | 'multi-city')}
            value={tripType}
          >
            <TabsList className="grid w-full grid-cols-3 mb-6">
              <TabsTrigger value="round-trip">Round Trip</TabsTrigger>
              <TabsTrigger value="one-way">One Way</TabsTrigger>
              <TabsTrigger value="multi-city">Multi-City</TabsTrigger>
            </TabsList>
            
            <TabsContent value="round-trip" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">From</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input
                      placeholder="City or Airport"
                      value={from}
                      onChange={(e) => {
                        setFrom(e.target.value);
                        searchForAirports(e.target.value, 'from');
                      }}
                      className="pl-10"
                    />
                    
                    {airportSuggestions.from.length > 0 && (
                      <div className="absolute z-10 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg mt-1 max-h-60 overflow-auto">
                        {airportSuggestions.from.map((airport) => (
                          <div 
                            key={airport.iata}
                            className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                            onClick={() => selectAirport(airport, 'from')}
                          >
                            <div className="flex justify-between">
                              <span className="font-medium">{airport.iata}</span>
                              <span className="text-sm text-gray-500">{airport.country}</span>
                            </div>
                            <div className="text-sm">{airport.name}, {airport.city}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">To</label>
                  <div className="relative">
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input
                      placeholder="City or Airport"
                      value={to}
                      onChange={(e) => {
                        setTo(e.target.value);
                        searchForAirports(e.target.value, 'to');
                      }}
                      className="pl-10"
                    />
                    
                    {airportSuggestions.to.length > 0 && (
                      <div className="absolute z-10 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg mt-1 max-h-60 overflow-auto">
                        {airportSuggestions.to.map((airport) => (
                          <div 
                            key={airport.iata}
                            className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                            onClick={() => selectAirport(airport, 'to')}
                          >
                            <div className="flex justify-between">
                              <span className="font-medium">{airport.iata}</span>
                              <span className="text-sm text-gray-500">{airport.country}</span>
                            </div>
                            <div className="text-sm">{airport.name}, {airport.city}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Depart</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !departDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {departDate ? format(departDate, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={departDate}
                        onSelect={setDepartDate}
                        initialFocus
                        disabled={(date) => date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">Return</label>
                  <Popover>
                    <PopoverTrigger asChild>
                      <Button
                        variant={"outline"}
                        className={cn(
                          "w-full justify-start text-left font-normal",
                          !returnDate && "text-muted-foreground"
                        )}
                      >
                        <CalendarIcon className="mr-2 h-4 w-4" />
                        {returnDate ? format(returnDate, "PPP") : <span>Pick a date</span>}
                      </Button>
                    </PopoverTrigger>
                    <PopoverContent className="w-auto p-0">
                      <Calendar
                        mode="single"
                        selected={returnDate}
                        onSelect={setReturnDate}
                        initialFocus
                        disabled={(date) => departDate ? date < departDate : date < new Date()}
                      />
                    </PopoverContent>
                  </Popover>
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">Passengers</label>
                  <div className="flex items-center space-x-2">
                    <Users className="h-4 w-4 text-gray-500" />
                    <Input
                      type="number"
                      min="1"
                      max="10"
                      value={passengers}
                      onChange={(e) => setPassengers(e.target.value)}
                      className="w-full"
                    />
                  </div>
                </div>
                
                <div className="space-y-2 col-span-3">
                  <label className="text-sm font-medium">Cabin Class</label>
                  <ToggleGroup type="single" value={cabinClass} onValueChange={(value) => {
                    if (value) setCabinClass(value as 'economy' | 'premium_economy' | 'business' | 'first');
                  }} className="justify-start">
                    <ToggleGroupItem value="economy" aria-label="Economy">Economy</ToggleGroupItem>
                    <ToggleGroupItem value="premium_economy" aria-label="Premium Economy">Premium Economy</ToggleGroupItem>
                    <ToggleGroupItem value="business" aria-label="Business">Business</ToggleGroupItem>
                    <ToggleGroupItem value="first" aria-label="First">First</ToggleGroupItem>
                  </ToggleGroup>
                </div>
              </div>
              
              <div className="flex items-center justify-end pt-4">
                <Button onClick={handleSearch} className="gap-2" disabled={isLoading}>
                  {isLoading ? (
                    <>
                      <Loader2 className="h-4 w-4 animate-spin" />
                      Searching...
                    </>
                  ) : (
                    <>
                      <Search className="h-4 w-4" />
                      Search Flights
                    </>
                  )}
                </Button>
              </div>
            </TabsContent>
            
            <TabsContent value="one-way" className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="space-y-2">
                  <label className="text-sm font-medium">From</label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input
                      placeholder="City or Airport"
                      value={from}
                      onChange={(e) => {
                        setFrom(e.target.value);
                        searchForAirports(e.target.value, 'from');
                      }}
                      className="pl-10"
                    />
                    
                    {airportSuggestions.from.length > 0 && (
                      <div className="absolute z-10 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg mt-1 max-h-60 overflow-auto">
                        {airportSuggestions.from.map((airport) => (
                          <div 
                            key={airport.iata}
                            className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                            onClick={() => selectAirport(airport, 'from')}
                          >
                            <div className="flex justify-between">
                              <span className="font-medium">{airport.iata}</span>
                              <span className="text-sm text-gray-500">{airport.country}</span>
                            </div>
                            <div className="text-sm">{airport.name}, {airport.city}</div>
                          </div>
                        ))}
                      </div>
                    )}
                  </div>
                </div>
                
                <div className="space-y-2">
                  <label className="text-sm font-medium">To</label>
                  <div className="relative">
                    <Plane className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500 h-4 w-4" />
                    <Input
                      placeholder="City or Airport"
                      value={to}
                      onChange={(e) => {
                        setTo(e.target.value);
                        searchForAirports(e.target.value, 'to');
                      }}
                      className="pl-10"
                    />
                    
                    {airportSuggestions.to.length > 0 && (
                      <div className="absolute z-10 w-full bg-white dark:bg-gray-800 border border-gray-200 dark:border-gray-700 rounded-md shadow-lg mt-1 max-h-60 overflow-auto">
                        {airportSuggestions.to.map((airport) => (
                          <div 
                            key={airport.iata}
                            className="px-4 py-2 hover:bg-gray-100 dark:hover:bg-gray-700 cursor-pointer"
                            onClick={() => selectAirport(airport, 'to')}
                          >
                            <div className="flex justify-between">
                              <span className="font-medium">{airport.iata}</span>
                              <span className="text-sm text-gray-500">{airport.country}</span>
                            </div>
                            <div className="text-sm">{airport
