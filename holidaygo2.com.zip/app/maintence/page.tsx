export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function MaintenancePage() {
  return (
    <Layout>
      <section className="min-h-[60vh] px-6 py-20 text-center text-white">
        <h1 className="text-3xl font-bold text-red-400 mb-4">Scheduled Maintenance</h1>
        <p className="text-slate-300 mb-6 max-w-md mx-auto">
          HolidayGo2.com is currently undergoing scheduled maintenance. Our agents are updating paths, patching trails, and restoring access.
        </p>
        <p className="text-sm text-slate-500 italic">
          Estimated return: 30 minutes. You may see Oracle, Troll, or Ms Trav-Elle during this transition.
        </p>
      </section>
    </Layout>
  );
}
