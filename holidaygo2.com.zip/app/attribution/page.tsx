export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function AttributionsPage() {
  const attributions = [
    {
      name: 'Lucide Icons',
      link: 'https://lucide.dev/',
      note: 'Used for UI iconography under MIT License',
    },
    {
      name: 'Unsplash',
      link: 'https://unsplash.com',
      note: 'Used for destination imagery (free license)',
    },
    {
      name: 'OpenAI + DeepSeek',
      link: 'https://openai.com',
      note: 'LLM and language routing for agentic responses',
    },
    {
      name: 'Vercel',
      link: 'https://vercel.com',
      note: 'Deployment and CDN platform',
    },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Attributions</h1>
        <ul className="space-y-4">
          {attributions.map((a, idx) => (
            <li key={idx} className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
              <a href={a.link} target="_blank" rel="noopener noreferrer" className="text-blue-400 underline text-sm">
                {a.name}
              </a>
              <p className="text-xs text-slate-400">{a.note}</p>
            </li>
          ))}
        </ul>
        <p className="text-xs text-slate-600 mt-8">
          Listed assets are used under open license or public usage policy.
        </p>
      </section>
    </Layout>
  );
}
