'use client';

import { ContactForm } from '@/components/contact/ContactForm';
import { Separator } from '@/components/ui/separator';
import { Mail, Phone, MessageSquare, MapPin, Clock } from 'lucide-react';

interface ContactInfoItemProps {
  icon: React.ReactNode;
  title: string;
  description: string;
  link?: string;
  linkText?: string;
}

function ContactInfoItem({ icon, title, description, link, linkText = "Contact Us" }: ContactInfoItemProps) {
  return (
    <div className="flex items-start">
      <div className="bg-primary/10 p-3 rounded-full mr-4">
        {icon}
      </div>
      <div>
        <h3 className="font-medium">{title}</h3>
        <p className="text-sm text-muted-foreground mb-1">{description}</p>
        {link && (
          <a href={link} className="text-sm text-primary hover:underline inline-flex items-center">
            {linkText}
          </a>
        )}
      </div>
    </div>
  );
}

interface FaqItemProps {
  question: string;
  answer: string;
}

function FaqItem({ question, answer }: FaqItemProps) {
  return (
    <div className="bg-white dark:bg-gray-800 shadow-sm rounded-lg p-4">
      <h3 className="font-medium mb-2">{question}</h3>
      <Separator className="my-2" />
      <p className="text-sm text-muted-foreground">{answer}</p>
    </div>
  );
}

export default function Contact() {
  return (
    <main className="flex-grow">
      {/* Hero Section */}
      <section className="bg-gray-100 dark:bg-gray-800/50 py-16 px-6">
        <div className="max-w-4xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-4">Contact Us</h1>
          <p className="text-lg text-muted-foreground max-w-2xl mx-auto">
            Our team is here to help with any questions, concerns, or feedback you might have.
            We aim to respond to all inquiries within 24 hours.
          </p>
        </div>
      </section>

      {/* Contact Information */}
      <section className="py-12 px-6">
        <div className="max-w-6xl mx-auto">
          <div className="grid grid-cols-1 md:grid-cols-2 gap-12">
            <div className="space-y-8">
              <div>
                <h2 className="text-2xl font-semibold mb-6">Get in Touch</h2>
                <p className="text-muted-foreground mb-8">
                  Whether you have a question about bookings, need help with your account,
                  or want to report an issue, our friendly team is ready to assist you.
                </p>
              </div>

              <div className="space-y-4">
                <ContactInfoItem
                  icon={<Mail className="h-5 w-5" />}
                  title="Email Us"
                  description="support@holidaygo2.com"
                  link="mailto:support@holidaygo2.com"
                />
                <ContactInfoItem
                  icon={<Phone className="h-5 w-5" />}
                  title="Call Us"
                  description="+1 (555) 123-4567"
                  link="tel:+15551234567"
                />
                <ContactInfoItem
                  icon={<MessageSquare className="h-5 w-5" />}
                  title="Live Chat"
                  description="Available 9am-6pm Mon-Fri"
                  link="#"
                  linkText="Start Chat"
                />
                <ContactInfoItem
                  icon={<MapPin className="h-5 w-5" />}
                  title="Our Office"
                  description="123 Holiday Street, Travel City, TC 12345"
                />
                <ContactInfoItem
                  icon={<Clock className="h-5 w-5" />}
                  title="Business Hours"
                  description="Monday-Friday: 9am-6pm, Weekend: 10am-4pm"
                />
              </div>
            </div>

            <div className="bg-white dark:bg-gray-800 shadow-md rounded-lg p-6 md:p-8">
              <h2 className="text-2xl font-semibold mb-6">Send Us a Message</h2>
              <ContactForm />
            </div>
          </div>
        </div>
      </section>

      {/* FAQ Section */}
      <section className="py-12 px-6 bg-gray-100 dark:bg-gray-800/50">
        <div className="max-w-4xl mx-auto">
          <h2 className="text-2xl font-semibold mb-6 text-center">Frequently Asked Questions</h2>
          <div className="space-y-6">
            <FaqItem
              question="How quickly can I expect a response?"
              answer="We aim to respond to all inquiries within 24 hours during business days. For urgent matters, please call our customer service line."
            />
            <FaqItem
              question="Can I change or cancel my booking?"
              answer="Yes, you can modify or cancel bookings through your account dashboard or by contacting our customer service team. Please note that cancellation policies vary by booking."
            />
            <FaqItem
              question="What information should I provide when reporting issues?"
              answer="Please include your booking reference, date of travel, and as many details about the issue as possible. Screenshots or photos can also be helpful when relevant."
            />
            <FaqItem
              question="How do I report a technical bug on the website?"
              answer="You can use the contact form and select 'Report bug' as the category. Please include which device and browser you're using, along with steps to reproduce the issue."
            />
          </div>
        </div>
      </section>
    </main>
  );
}
