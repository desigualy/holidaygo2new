'use client';
export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Script from 'next/script';
import { useEffect, useRef } from 'react';

export default function MapPage() {
  const mapRef = useRef<HTMLDivElement | null>(null);

  useEffect(() => {
    if (typeof window === 'undefined') return;

    window.initMap = () => {
      if (!window.google || !mapRef.current) return;

      new window.google.maps.Map(mapRef.current, {
        center: { lat: 48.8566, lng: 2.3522 }, // Paris
        zoom: 5,
      });
    };
  }, []);

  return (
    <Layout>
      <Script
        src={`https://maps.googleapis.com/maps/api/js?key=${process.env.NEXT_PUBLIC_GOOGLE_MAPS_API_KEY}&callback=initMap`}
        async
        defer
      />
      <section className="px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-4">Map Explorer</h1>
        <div ref={mapRef} className="w-full h-[500px] rounded shadow border border-slate-800" />
      </section>
    </Layout>
  );
}
