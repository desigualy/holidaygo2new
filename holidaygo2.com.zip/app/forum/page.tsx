'use client';
export const runtime = 'edge';

import Link from 'next/link';

interface Topic {
  id: string;
  title: string;
  author: string;
  replies: number;
}

export default function ForumPage() {
  const topics: Topic[] = [
    { id: '1', title: 'Best solo travel destinations under £500?', author: 'Nova88', replies: 12 },
    { id: '2', title: 'How safe is Istanbul right now?', author: 'JetPackJack', replies: 8 },
    { id: '3', title: 'Wheelchair-friendly hotel chains?', author: 'RoamAccess', replies: 4 },
  ];

  return (
    <main className="px-6 py-10 max-w-4xl mx-auto text-white">
      <div className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-bold text-cyan-400">Community Forum</h1>
        <Link href="/forum/new-post" className="bg-blue-600 hover:bg-blue-700 text-sm px-4 py-2 rounded text-white">
          Start New Topic
        </Link>
      </div>

      <ul className="space-y-4">
        {topics.map((topic) => (
          <li
            key={topic.id}
            className="border border-slate-700 p-4 rounded bg-slate-900 hover:bg-slate-800 transition"
          >
            <Link href={`/forum/topic/${topic.id}`} className="text-xl font-semibold text-blue-400">
              {topic.title}
            </Link>
            <div className="text-sm text-slate-400">
              Posted by {topic.author} · {topic.replies} replies
            </div>
          </li>
        ))}
      </ul>
    </main>
  );
}
