'use client';
export const runtime = 'edge';

import { useParams } from 'next/navigation';

interface Reply {
  id: string;
  author: string;
  message: string;
}

export default function TopicPage() {
  const { topicId } = useParams();
  const topicTitle = topicId === '1'
    ? 'Best solo travel destinations under £500?'
    : topicId === '2'
    ? 'How safe is Istanbul right now?'
    : 'Wheelchair-friendly hotel chains?';

  const replies: Reply[] = [
    { id: 'r1', author: 'WanderElla', message: 'I did Budapest solo for under £400 including flights and Airbnb.' },
    { id: 'r2', author: 'MapMule', message: 'Lisbon’s cheap, easy to navigate, and feels safe day or night.' },
  ];

  return (
    <main className="px-6 py-10 max-w-3xl mx-auto text-white">
      <h1 className="text-2xl font-bold text-cyan-400 mb-4">{topicTitle}</h1>
      <ul className="space-y-4 mb-6">
        {replies.map((reply) => (
          <li key={reply.id} className="p-4 bg-slate-900 border border-slate-700 rounded shadow">
            <p className="text-slate-200">{reply.message}</p>
            <div className="text-sm text-slate-400 mt-1">— {reply.author}</div>
          </li>
        ))}
      </ul>
      <form className="space-y-2">
        <textarea
          placeholder="Write a reply..."
          className="w-full h-24 p-2 rounded bg-slate-800 text-white"
        />
        <button type="submit" className="bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-white text-sm">
          Reply
        </button>
      </form>
    </main>
  );
}
