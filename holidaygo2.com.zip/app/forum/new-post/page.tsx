'use client';
export const runtime = 'edge';

import { useState } from 'react';
import { useRouter } from 'next/navigation';

export default function NewForumPostPage() {
  const [title, setTitle] = useState('');
  const [body, setBody] = useState('');
  const [status, setStatus] = useState('');
  const router = useRouter();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !body) {
      setStatus('Please complete all fields.');
      return;
    }

    // 🔁 Replace with actual post-to-DB logic later
    console.log('POST:', { title, body });
    setStatus('Topic created successfully.');
    setTimeout(() => router.push('/forum'), 1000);
  };

  return (
    <main className="min-h-screen px-6 py-10 max-w-xl mx-auto text-white">
      <h1 className="text-3xl font-bold text-cyan-400 mb-6">New Forum Topic</h1>
      <form onSubmit={handleSubmit} className="space-y-4">
        <input
          type="text"
          placeholder="Topic title"
          className="w-full p-2 rounded bg-slate-800 text-white"
          value={title}
          onChange={(e) => setTitle(e.target.value)}
          required
        />
        <textarea
          placeholder="Write your message..."
          className="w-full p-2 h-32 rounded bg-slate-800 text-white"
          value={body}
          onChange={(e) => setBody(e.target.value)}
          required
        />
        <button type="submit" className="px-4 py-2 bg-blue-600 hover:bg-blue-700 rounded">
          Post Topic
        </button>
        <p className="text-sm text-yellow-400">{status}</p>
      </form>
    </main>
  );
}
