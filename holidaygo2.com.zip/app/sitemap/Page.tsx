// app/sitemap/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

const routes = [
  { path: '/', label: 'Home' },
  { path: '/flights', label: 'Flights' },
  { path: '/hotels', label: 'Hotels' },
  { path: '/packages', label: 'Holiday Packages' },
  { path: '/forum', label: 'Travel Forum' },
  { path: '/profile', label: 'Your Profile' },
  { path: '/support', label: 'Help & Support' },
  { path: '/features', label: 'Platform Features' },
  { path: '/pricing', label: 'Pricing Intelligence' },
  { path: '/destinations', label: 'Dream Destinations' },
  { path: '/reviews', label: 'Traveler Reflections' },
  { path: '/register', label: 'Register' },
  { path: '/login', label: 'Log In' },
  { path: '/newsletter', label: 'Newsletter Signup' },
  { path: '/privacy', label: 'Privacy & Data Use' },
  { path: '/terms', label: 'Terms & Consent' },
];

export default function SitemapPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-3xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Sitemap</h1>
        <ul className="space-y-3">
          {routes.map((r, i) => (
            <li key={i}>
              <a href={r.path} className="text-blue-700 hover:underline text-sm">
                {r.label}
              </a>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
