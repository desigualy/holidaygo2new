'use client';

import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Card, CardContent } from '@/components/ui/card';
import { Separator } from '@/components/ui/separator';
import { Features } from '@/components/home/Features';
import { Search, Users, Globe, MessageSquare } from 'lucide-react';

export default function About() {
  return (
    <section className="relative pt-32 pb-16 px-6 bg-gradient-to-b from-primary/20 to-transparent">
      <div className="max-w-6xl mx-auto text-center">
        <h1 className="text-4xl md:text-5xl font-bold tracking-tight mb-4">
          About HolidayGo2
        </h1>
        <p className="text-xl text-muted-foreground max-w-3xl mx-auto">
          We're on a mission to make holiday comparisons transparent and help travellers find the best deals without hidden fees.
        </p>
      </div>

      {/* Our Story */}
      <section className="py-16">
        <div className="max-w-6xl mx-auto">
          <div className="grid md:grid-cols-2 gap-12 items-center">
            <div>
              <h2 className="text-3xl font-bold mb-6">Our Story</h2>
              <p className="text-lg text-muted-foreground mb-4">
                HolidayGo2 was founded in 2023 by a team of travel enthusiasts who were frustrated with the hidden fees and lack of transparency in the travel industry.
              </p>
              <p className="text-lg text-muted-foreground mb-4">
                We set out to create a platform that would provide complete transparency in holiday pricing, allowing travellers to make informed decisions without surprises at checkout.
              </p>
              <p className="text-lg text-muted-foreground mb-4">
                Today, we compare prices from over 20 leading travel providers to find you the best deals on holiday packages, with all costs clearly displayed upfront.
              </p>
            </div>
            <div className="relative rounded-xl overflow-hidden shadow-lg h-[400px]">
              <img 
                src="https://images.unsplash.com/photo-1564501049412-61c2a3083791?ixlib=rb-1.2.1&auto=format&fit=crop&w=800&q=80" 
                alt="Our team" 
                className="w-full h-full object-cover"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Our Values */}
      <section className="py-16 bg-secondary/30">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Our Values</h2>
          <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
            <Card className="bg-white dark:bg-gray-800 overflow-hidden">
              <div className="h-2 bg-blue-500 w-full" />
              <CardContent className="pt-6">
                <Search className="h-10 w-10 text-blue-500 mb-4" />
                <h3 className="text-xl font-medium mb-2">Transparency</h3>
                <p className="text-muted-foreground">
                  We show all fees and charges upfront so there are no surprises at checkout.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white dark:bg-gray-800 overflow-hidden">
              <div className="h-2 bg-green-500 w-full" />
              <CardContent className="pt-6">
                <Users className="h-10 w-10 text-green-500 mb-4" />
                <h3 className="text-xl font-medium mb-2">Customer First</h3>
                <p className="text-muted-foreground">
                  Every decision we make puts our customers' needs and experience first.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white dark:bg-gray-800 overflow-hidden">
              <div className="h-2 bg-purple-500 w-full" />
              <CardContent className="pt-6">
                <Globe className="h-10 w-10 text-purple-500 mb-4" />
                <h3 className="text-xl font-medium mb-2">Innovation</h3>
                <p className="text-muted-foreground">
                  We're constantly improving our technology to provide better search results and comparisons.
                </p>
              </CardContent>
            </Card>

            <Card className="bg-white dark:bg-gray-800 overflow-hidden">
              <div className="h-2 bg-amber-500 w-full" />
              <CardContent className="pt-6">
                <MessageSquare className="h-10 w-10 text-amber-500 mb-4" />
                <h3 className="text-xl font-medium mb-2">Honesty</h3>
                <p className="text-muted-foreground">
                  We're committed to honest reviews and representation of the holiday packages we display.
                </p>
              </CardContent>
            </Card>
          </div>
        </div>
      </section>

      {/* Why Choose Us */}
      <section className="py-20">
        <div className="max-w-6xl mx-auto">
          <h2 className="text-3xl font-bold text-center mb-12">Why Choose HolidayGo2</h2>
          <Features />
        </div>
      </section>

      {/* Team Section */}
      <section className="py-16 bg-gradient-to-b from-primary/5 to-transparent">
        <div className="max-w-6xl mx-auto text-center">
          <h2 className="text-3xl font-bold mb-6">Our Team</h2>
          <p className="text-lg text-muted-foreground max-w-3xl mx-auto mb-12">
            HolidayGo2 is made up of travel enthusiasts, tech experts, and customer service professionals dedicated to making travel planning easier.
          </p>
          <div className="flex justify-center">
            <Button asChild size="lg">
              <Link href="/contact">Get in Touch With Us</Link>
            </Button>
          </div>
        </div>
      </section>
    </section>
  );
}
