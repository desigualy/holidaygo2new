export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function CookiePolicyPage() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Cookie Policy</h1>
        <p className="text-slate-300 mb-4">
          HolidayGo2 uses cookies to enhance functionality, analyze usage, and personalize your travel experience.
        </p>

        <ul className="list-disc list-inside text-slate-400 text-sm space-y-2">
          <li>Session cookies to manage secure login and state</li>
          <li>Analytics cookies for traffic patterns and improvement</li>
          <li>Preference cookies to store language, font, and voice settings</li>
          <li>No third-party ad tracking or data resale</li>
        </ul>

        <p className="text-sm text-slate-500 mt-6">
          By using this site, you consent to the use of these cookies unless settings are changed.
        </p>

        <p className="text-xs text-slate-600 mt-8">
          Last updated: May 2025
        </p>
      </section>
    </Layout>
  );
}
