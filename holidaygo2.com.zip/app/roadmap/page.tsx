export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function RoadmapPage() {
  const roadmap = [
    {
      stage: '✅ Live Now',
      items: ['Flights', 'Hotels', 'Packages', 'Search', 'Voice Input', 'Profile & Auth'],
    },
    {
      stage: '🛠️ In Progress',
      items: ['Live Agent Chat', 'Wallet + Travel Credits', 'Multi-user Itineraries'],
    },
    {
      stage: '🧪 Planned',
      items: ['Group Planning', 'Hotbox Syncing', 'Wisp Coin Unlockables', 'E-Colette Echo Layer'],
    },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">HolidayGo2 Roadmap</h1>
        {roadmap.map((phase, idx) => (
          <div
            key={idx}
            className="mb-8 bg-slate-900 border border-slate-700 p-4 rounded shadow"
          >
            <h2 className="text-xl font-semibold text-blue-300 mb-2">{phase.stage}</h2>
            <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
              {phase.items.map((item, i) => (
                <li key={i}>{item}</li>
              ))}
            </ul>
          </div>
        ))}
      </section>
    </Layout>
  );
}
