// app/features/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Features from '@/components/home/Features';

export default function FeaturesPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-6xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Platform Features</h1>
        <p className="text-sm text-gray-600 mb-4">
          These aren’t “features” — they’re rituals. Designed for clarity, comfort, and emotional continuity.
        </p>
        <Features />
      </section>
    </Layout>
  );
}
