'use client';

import { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Hero } from '@/components/home/Hero';
import { Features } from '@/components/home/Features';
import { PopularDestinations } from '@/components/home/PopularDestinations';
import { LastMinuteDeals } from '@/components/home/LastMinuteDeals';
import { Newsletter } from '@/components/home/Newsletter';
import { Button } from '@/components/ui/button';
import { AuthModal } from '@/components/auth/AuthModal';
import { useAuth } from '@/hooks/use-auth';
import { HolidayPackage } from '@/types/holiday';
import { providers } from '@/data/providers';
import { ChatAgent } from '@/components/agents/ChAtIntro';
import { EmotionTap } from '@/components/system/EmotionTap';
import { AgentPicker } from '@/components/agents/AgentPicker';
import Link from 'next/link';

export default function Home() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const { session, user } = useAuth();
  const [elementsVisible, setElementsVisible] = useState({
    destinations: false,
    deals: false,
    newsletter: false
  });
  const [showIntroAgent, setShowIntroAgent] = useState(true);
  const [showAgentPicker, setShowAgentPicker] = useState(false);

  const [popularDestinations, setPopularDestinations] = useState([
    {
      name: "Santorini, Greece",
      image: "https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?q=80&w=800&auto=format&fit=crop",
      price: 599
    },
    {
      name: "Bali, Indonesia",
      image: "https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop",
      price: 899
    },
    {
      name: "Maldives",
      image: "https://images.unsplash.com/photo-1573843981267-be1999ff37cd?q=80&w=800&auto=format&fit=crop",
      price: 1299
    },
    {
      name: "Barcelona, Spain",
      image: "https://images.unsplash.com/photo-1583422409516-2895a77efded?q=80&w=800&auto=format&fit=crop",
      price: 349
    }
  ]);

  const [dealPackages, setDealPackages] = useState<HolidayPackage[]>([]);

  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 0.1
    };
    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach(entry => {
        if (entry.isIntersecting) {
          const targetId = entry.target.id;
          setElementsVisible(prev => ({ ...prev, [targetId]: true }));
        }
      });
    };
    const observer = new IntersectionObserver(observerCallback, observerOptions);
    const sections = ['destinations', 'deals', 'newsletter'];
    sections.forEach(section => {
      const element = document.getElementById(section);
      if (element) observer.observe(element);
    });
    return () => observer.disconnect();
  }, []);

  useEffect(() => {
    if (!session.isAuthenticated) return;
    const timeout = setTimeout(() => {
      setShowAgentPicker(true);
    }, 1000);
    return () => clearTimeout(timeout);
  }, [session]);

  return (
    <Layout>
      {showIntroAgent && <ChatAgent onClose={() => setShowIntroAgent(false)} />}
      {showAgentPicker && <AgentPicker onClose={() => setShowAgentPicker(false)} />}

      <Hero />

      <div className="text-right px-4 mt-2">
        <Link href="/accessibility" className="text-sm text-blue-600 hover:underline">
          Accessibility Options
        </Link>
      </div>

      <EmotionTap event="delight" section="hero" />

      {!session.isAuthenticated && (
        <div className="bg-gradient-to-r from-blue-500 to-blue-700 py-8 px-4">
          <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
            <div className="text-white mb-4 md:mb-0">
              <h2 className="text-2xl font-bold mb-2">Create an account to access exclusive deals</h2>
              <p>Sign up today and get personalized travel recommendations based on your preferences.</p>
            </div>
            <Button 
              size="lg" 
              className="bg-white text-blue-700 hover:bg-gray-100"
              onClick={() => setAuthModalOpen(true)}
            >
              Sign Up Now
            </Button>
          </div>
        </div>
      )}

      <Features />

      <div id="destinations">
        <PopularDestinations 
          destinations={popularDestinations} 
          isVisible={elementsVisible.destinations} 
        />
      </div>

      <div id="deals">
        <LastMinuteDeals 
          packages={dealPackages} 
          isVisible={elementsVisible.deals} 
        />
      </div>

      <div id="newsletter">
        <Newsletter isVisible={elementsVisible.newsletter} />
      </div>

      <EmotionTap event="curiosity" section="deals" />

      <AuthModal open={authModalOpen} onOpenChange={setAuthModalOpen} />
    </Layout>
  );
}
