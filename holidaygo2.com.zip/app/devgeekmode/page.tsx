'use client';
export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { useEffect, useState } from 'react';

export default function DevGeekModePage() {
  const [jwt, setJwt] = useState<string | null>(null);

  useEffect(() => {
    const token = localStorage.getItem('supabase.auth.token');
    if (token) {
      try {
        const parsed = JSON.parse(token);
        const currentSession = parsed?.currentSession?.access_token;
        setJwt(currentSession || null);
      } catch {
        setJwt(null);
      }
    }
  }, []);

  return (
    <Layout>
      <section className="px-6 py-12 max-w-5xl mx-auto space-y-6">
        <h1 className="text-3xl font-bold">Developer Console (Geek Mode)</h1>
        <p className="text-sm text-gray-600">
          Only enabled when toggled. JWT appears below if active:
        </p>
        {jwt ? (
          <div className="bg-gray-100 p-4 rounded font-mono text-xs break-words border border-gray-300">
            {jwt}
          </div>
        ) : (
          <p className="text-xs text-red-600">No session found or not authorized.</p>
        )}
      </section>
    </Layout>
  );
}
