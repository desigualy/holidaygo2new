'use client';

import { useState } from 'react';
import { Card, CardContent, CardHeader, CardTitle, CardDescription } from '@/components/ui/card';
import { Tabs, TabsList, TabsTrigger, TabsContent } from '@/components/ui/tabs';
import { Bell, ArrowDown, Trash2, Eye, Calendar } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';

export default function Alerts() {
  const [activeTab, setActiveTab] = useState('active');

  const alerts = {
    active: [
      {
        id: 'al1',
        destination: 'Barcelona, Spain',
        currentPrice: 349,
        targetPrice: 300,
        departureDate: '2025-06-15',
        createdAt: '2025-04-01',
        type: 'price_drop'
      },
      {
        id: 'al2',
        destination: 'Santorini, Greece',
        currentPrice: 599,
        targetPrice: 550,
        departureDate: '2025-07-20',
        createdAt: '2025-04-02',
        type: 'price_drop'
      },
      {
        id: 'al3',
        destination: 'Maldives',
        currentPrice: 1299,
        targetPrice: 1200,
        departureDate: '2025-08-10',
        createdAt: '2025-04-03',
        type: 'price_drop'
      }
    ],
    triggered: [
      {
        id: 'al4',
        destination: 'Rome, Italy',
        currentPrice: 299,
        targetPrice: 320,
        departureDate: '2025-05-25',
        createdAt: '2025-03-20',
        triggeredAt: '2025-04-05',
        type: 'price_drop'
      },
      {
        id: 'al5',
        destination: 'Paris, France',
        currentPrice: 289,
        targetPrice: 310,
        departureDate: '2025-05-15',
        createdAt: '2025-03-15',
        triggeredAt: '2025-04-01',
        type: 'price_drop'
      }
    ],
    expired: [
      {
        id: 'al6',
        destination: 'Amsterdam, Netherlands',
        finalPrice: 329,
        targetPrice: 300,
        departureDate: '2025-04-01',
        createdAt: '2025-02-10',
        expiredAt: '2025-03-25',
        type: 'price_drop'
      }
    ]
  };

  return (
    <div className="container mx-auto px-4 py-8">
      <div className="flex items-center mb-6">
        <Bell className="h-6 w-6 mr-3 text-primary" />
        <h1 className="text-3xl font-bold">Price Alerts</h1>
      </div>

      <p className="mb-8 text-muted-foreground">
        Get notified when prices drop for your favorite destinations.
        We'll monitor prices and alert you when they reach your target.
      </p>

      <Tabs value={activeTab} onValueChange={setActiveTab} className="mb-8">
        <TabsList className="grid grid-cols-3 mb-6">
          <TabsTrigger value="active" className="flex items-center gap-2">
            Active
            <Badge>{alerts.active.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="triggered" className="flex items-center gap-2">
            Triggered
            <Badge>{alerts.triggered.length}</Badge>
          </TabsTrigger>
          <TabsTrigger value="expired" className="flex items-center gap-2">
            Expired
            <Badge>{alerts.expired.length}</Badge>
          </TabsTrigger>
        </TabsList>

        <TabsContent value="active">
          <div className="grid gap-4">
            {alerts.active.map(alert => (
              <Card key={alert.id}>
                <CardContent className="p-6">
                  <div className="flex flex-col md:flex-row justify-between">
                    <div>
                      <h3 className="text-lg font-semibold">{alert.destination}</h3>
                      <div className="flex items-center text-sm text-muted-foreground mt-1">
                        <Calendar className="h-4 w-4 mr-1" />
                        Departure: {new Date(alert.departureDate).toLocaleDateString()}
                      </div>
                    </div>
                    <div className="mt-4 md:mt-0 flex items-center">
                      <div className="mr-6">
                        <div className="text-sm text-muted-foreground">Current price</div>
                        <div className="text-lg font-semibold">£{alert.currentPrice}</div>
                      </div>
                      <div className="mr-6">
                        <div className="text-sm text-muted-foreground">Target price</div>
                        <div className="text-lg font-semibold text-primary">£{alert.targetPrice}</div>
                      </div>
                      <div className="text-amber-500 flex items-center">
                        <ArrowDown className="h-4 w-4 mr-1" />
                        <span>£{alert.currentPrice - alert.targetPrice} to go</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex justify-end mt-4 gap-2">
                    <Button variant="outline" size="sm">
                      <Eye className="h-4 w-4 mr-2" />
                      View trip
                    </Button>
                    <Button variant="outline" size="sm" className="text-destructive">
                      <Trash2 className="h-4 w-4 mr-2" />
                      Remove
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        </TabsContent>

        <TabsContent value="triggered">
          <div className="grid gap-4">
            {alerts.triggered.map(alert => (
              <Card key={alert.id}>
                <CardContent className="p-6">
                  <Badge className="mb-3 bg-green-500 hover:bg-green-600">Price dropped!</Badge>
                  <div className="flex flex-col
