export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function AboutPage() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">About HolidayGo2</h1>
        <p className="text-slate-300 mb-4">
          HolidayGo2 is the world’s first agent-powered, voice-first travel platform.
          We help neurodiverse and overwhelmed travellers book smarter trips — faster.
        </p>

        <ul className="list-disc list-inside text-slate-400 text-sm space-y-2">
          <li>Built with Next.js, Supabase, and edge-native performance</li>
          <li>Backed by AI agents like Ch@, Oracle, and Ms Trav-Elle</li>
          <li>Supports offline planning, voice input, and emotional filtering</li>
          <li>Designed for real-world usability — not just marketing fluff</li>
        </ul>

        <p className="text-xs text-slate-600 mt-8">
          HolidayGo2 was founded in 2025. We are proudly independent and user-first.
        </p>
      </section>
    </Layout>
  );
}
