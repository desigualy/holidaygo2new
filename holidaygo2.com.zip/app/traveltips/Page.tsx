// app/TravelTips/page.tsx

import { Metadata } from 'next';
import Layout from '@/components/layout/Layout';

export const metadata: Metadata = {
  title: 'Travel Tips · HolidayGo2',
  description: 'Gentle advice from agents who understand the journey is more than logistics.',
};

const tips = [
  {
    agent: 'Ms Trav-Elle',
    tip: 'Pack light — but bring something that makes you feel at home wherever you land.',
  },
  {
    agent: 'Ch@',
    tip: 'Speak your intent. Even vague dreams have value when voiced aloud.',
  },
  {
    agent: 'Cart-Elle',
    tip: 'Let the place introduce itself before you judge it. Feeling takes time.',
  },
  {
    agent: 'DogsBod-i',
    tip: 'Back up your bookings. And your soul. Just in case.',
  },
  {
    agent: 'The Oracle',
    tip: 'Depart a day earlier than planned. Prediction favors the prepared.',
  },
];

export default function TravelTipsPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-4xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Agent Travel Tips</h1>
        <p className="text-sm text-gray-600 mb-6">
          These aren’t generic tips. They’re emotional strategies, offered with care by the same agents who guide your platform experience.
        </p>
        <ul className="space-y-4 text-sm">
          {tips.map((t, i) => (
            <li key={i} className="bg-white border rounded p-4 shadow-sm">
              <p className="text-gray-800 italic mb-1">“{t.tip}”</p>
              <p className="text-blue-700 font-semibold">— {t.agent}</p>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
