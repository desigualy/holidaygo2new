'use client';

import { useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion";
import { Search } from "lucide-react";

// FAQ Categories and Questions
const faqData = {
  booking: [
    {
      question: "How do I cancel or modify my booking?",
      answer: "You can cancel or modify your booking by logging into your account and navigating to 'My Bookings'. From there, select the booking you wish to change and follow the prompts. Please note that cancellation policies vary depending on the provider and the time until your departure."
    },
    {
      question: "What payment methods do you accept?",
      answer: "We accept all major credit and debit cards including Visa, Mastercard, American Express, and Discover. We also support PayPal for most bookings. Some regional payment methods may be available depending on your location."
    },
    {
      question: "When will I receive my booking confirmation?",
      answer: "You should receive your booking confirmation via email immediately after completing your purchase. If you don't receive it within 10 minutes, please check your spam folder or contact our customer support team."
    },
    {
      question: "Can I book for someone else?",
      answer: "Yes, you can book travel for friends or family members. During the booking process, you'll have the option to enter the traveler details. Just make sure to use their name exactly as it appears on their passport or ID."
    }
  ],
  payments: [
    {
      question: "Is there a booking fee?",
      answer: "We strive to be transparent with our pricing. While some bookings may include a small service fee, this will always be clearly displayed before you complete your purchase. There are no hidden fees on our platform."
    },
    {
      question: "Can I pay in installments?",
      answer: "For certain bookings over $300, we offer a 'Book Now, Pay Later' option which allows you to split your payment into installments. This option will be presented during checkout if your booking qualifies."
    },
    {
      question: "How secure is my payment information?",
      answer: "All payment transactions are securely processed using industry-standard SSL encryption. We do not store your full credit card details on our servers. Our payment processing complies with PCI DSS standards."
    },
    {
      question: "When is my credit card charged?",
      answer: "For most bookings, your credit card will be charged immediately upon confirmation. For some hotel reservations, you may only be charged when you check in or a few days before your stay, depending on the hotel's policy."
    }
  ],
  travel: [
    {
      question: "Do I need travel insurance?",
      answer: "While travel insurance is not mandatory, we strongly recommend it to protect your trip against unforeseen circumstances such as cancellations, delays, medical emergencies, or lost luggage. We offer comprehensive travel insurance options during the booking process."
    },
    {
      question: "What documents do I need for international travel?",
      answer: "For international travel, you'll typically need a passport valid for at least 6 months beyond your travel dates. Depending on your destination and nationality, you may also need visas or other travel permits. We recommend checking the specific requirements for your destination on your government's travel website."
    },
    {
      question: "How early should I arrive at the airport?",
      answer: "For domestic flights, we recommend arriving 2 hours before departure. For international flights, arrive
