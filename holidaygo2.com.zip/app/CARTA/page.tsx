// app/carta/page.tsx

export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import CARTA from '@/components/Mapseer/CARTA';

export default function CartaPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-5xl mx-auto space-y-8">
        <h1 className="text-3xl font-bold">CARTA: The Visual Mapseer</h1>
        <p className="text-sm text-gray-600">
          CARTA renders where you’re headed — streets, beaches, rooftops, ruins — tied to your soulprint trail.
        </p>
        <div className="border rounded bg-white shadow-sm p-4">
          <CARTA />
        </div>
        <p className="text-xs text-gray-400">
          If CARTA fails to render, check your Google Maps API key or region lock. This module does not fallback.
        </p>
      </section>
    </Layout>
  );
}
