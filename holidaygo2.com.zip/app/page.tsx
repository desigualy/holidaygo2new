'use client';
export const runtime = 'edge';

import { useState, useEffect } from 'react';
import Layout from '@/components/layout/Layout';
import Hero from '@/components/home/Hero';
import Features from '@/components/home/Features';
import PopularDestinations from '@/components/home/PopularDestinations';
import LastMinuteDeals from '@/components/home/LastMinuteDeals';
import Newsletter from '@/components/home/Newsletter';
import { Button } from '@/components/ui/button';
import AuthModal from '@/components/auth/AuthModal';
import { useAuth } from '@/hooks/use-auth';
import { HolidayPackage } from '@/types/holiday';
import { providers } from '@/data/providers';

export default function Home() {
  const [authModalOpen, setAuthModalOpen] = useState(false);
  const { session, user } = useAuth();
  const [elementsVisible, setElementsVisible] = useState({
    destinations: false,
    deals: false,
    newsletter: false,
  });

  const [popularDestinations] = useState([
    {
      name: 'Santorini, Greece',
      image: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?q=80&w=800&auto=format&fit=crop',
      price: 599,
    },
    {
      name: 'Bali, Indonesia',
      image: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop',
      price: 899,
    },
    {
      name: 'Maldives',
      image: 'https://images.unsplash.com/photo-1573843981267-be1999ff37cd?q=80&w=800&auto=format&fit=crop',
      price: 1299,
    },
    {
      name: 'Barcelona, Spain',
      image: 'https://images.unsplash.com/photo-1583422409516-2895a77efded?q=80&w=800&auto=format&fit=crop',
      price: 349,
    },
  ]);

  const [dealPackages] = useState<HolidayPackage[]>([
    {
      id: 'pkg1',
      title: '7 Nights in Santorini',
      destination: 'Santorini, Greece',
      departureAirport: 'London Heathrow',
      provider: providers[0],
      nights: 7,
      adults: 2,
      children: 0,
      departureDate: '2025-07-15',
      returnDate: '2025-07-22',
      priceBreakdown: {
        basePrice: 899,
        flightPrice: 700,
        hotelPrice: 600,
        transferPrice: 50,
        tax: 100,
        fees: 50,
        totalPrice: 1499,
        flights: 700,
        hotel: 600,
        transfers: 50,
        taxesAndFees: 149,
      },
      hotelStars: 4.8,
      boardBasis: 'Breakfast included',
      flightClass: 'Economy',
      baggage: '20kg',
      transferIncluded: true,
      roomType: 'Deluxe Room',
      imageUrl: 'https://images.unsplash.com/photo-1570077188670-e3a8d69ac5ff?q=80&w=800&auto=format&fit=crop',
      url: '#',
      savingsPercent: 15,
    },
    {
      id: 'pkg2',
      title: '5 Nights in Bali',
      destination: 'Bali, Indonesia',
      departureAirport: 'Manchester',
      provider: providers[1],
      nights: 5,
      adults: 2,
      children: 0,
      departureDate: '2025-06-10',
      returnDate: '2025-06-15',
      priceBreakdown: {
        basePrice: 1299,
        flightPrice: 800,
        hotelPrice: 900,
        transferPrice: 50,
        tax: 100,
        fees: 50,
        totalPrice: 1899,
        flights: 800,
        hotel: 900,
        transfers: 50,
        taxesAndFees: 149,
      },
      hotelStars: 4.9,
      boardBasis: 'All Inclusive',
      flightClass: 'Economy',
      baggage: '20kg',
      transferIncluded: true,
      roomType: 'Deluxe Suite',
      imageUrl: 'https://images.unsplash.com/photo-1537996194471-e657df975ab4?q=80&w=800&auto=format&fit=crop',
      url: '#',
      savingsPercent: 10,
    },
    {
      id: 'pkg3',
      title: '3 Nights in Barcelona',
      destination: 'Barcelona, Spain',
      departureAirport: 'London Gatwick',
      provider: providers[2],
      nights: 3,
      adults: 2,
      children: 0,
      departureDate: '2025-05-20',
      returnDate: '2025-05-23',
      priceBreakdown: {
        basePrice: 649,
        flightPrice: 300,
        hotelPrice: 400,
        transferPrice: 0,
        tax: 50,
        fees: 30,
        totalPrice: 780,
        flights: 300,
        hotel: 400,
        taxesAndFees: 80,
      },
      hotelStars: 4.7,
      boardBasis: 'Bed & Breakfast',
      flightClass: 'Economy',
      baggage: '15kg',
      transferIncluded: false,
      roomType: 'Standard Room',
      imageUrl: 'https://images.unsplash.com/photo-1583422409516-2895a77efded?q=80&w=800&auto=format&fit=crop',
      url: '#',
      savingsPercent: 5,
    },
  ]);

  useEffect(() => {
    const observerOptions = {
      root: null,
      rootMargin: '0px',
      threshold: 0.1,
    };

    const observerCallback = (entries: IntersectionObserverEntry[]) => {
      entries.forEach((entry) => {
        if (entry.isIntersecting) {
          const targetId = entry.target.id;
          setElementsVisible((prev) => ({
            ...prev,
            [targetId]: true,
          }));
        }
      });
    };

    const observer = new IntersectionObserver(observerCallback, observerOptions);
    ['destinations', 'deals', 'newsletter'].forEach((id) => {
      const el = document.getElementById(id);
      if (el) observer.observe(el);
    });

    return () => observer.disconnect();
  }, []);

  return (
    <Layout>
      <Hero />

      {!session?.isAuthenticated && (
        <div className="bg-gradient-to-r from-blue-500 to-blue-700 py-8 px-4">
          <div className="container mx-auto flex flex-col md:flex-row items-center justify-between">
            <div className="text-white mb-4 md:mb-0">
              <h2 className="text-2xl font-bold mb-2">Create an account to access exclusive deals</h2>
              <p>Sign up today and get personalized travel recommendations based on your preferences.</p>
            </div>
            <Button
              size="lg"
              className="bg-white text-blue-700 hover:bg-gray-100"
              onClick={() => setAuthModalOpen(true)}
            >
              Sign Up Now
            </Button>
          </div>
        </div>
      )}

      <Features />
      <PopularDestinations destinations={popularDestinations} isVisible={elementsVisible.destinations} />
      <LastMinuteDeals packages={dealPackages} isVisible={elementsVisible.deals} />
      <Newsletter isVisible={elementsVisible.newsletter} />
      <AuthModal open={authModalOpen} onOpenChange={setAuthModalOpen} />
    </Layout>
  );
}
