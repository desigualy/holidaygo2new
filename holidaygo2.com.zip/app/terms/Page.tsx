'use client';

import { Layout } from "@/components/layout/Layout";
import { FileText } from "lucide-react";

export default function Terms() {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="mb-8 text-center">
          <FileText className="h-12 w-12 mx-auto text-primary mb-3" />
          <h1 className="text-3xl font-bold">Terms & Conditions</h1>
          <p className="text-muted-foreground mt-2">Last updated: May 1, 2025</p>
        </div>
        
        <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 md:p-8">
          <div className="prose dark:prose-invert max-w-none">
            <h2>1. Introduction</h2>
            <p>
              Welcome to HolidayAgent. These Terms and Conditions govern your use of our website and services. 
              By accessing or using HolidayAgent, you agree to be bound by these Terms. If you disagree with any part 
              of the terms, you may not access the service.
            </p>
            
            <h2>2. Definitions</h2>
            <p>
              <strong>"Service"</strong> refers to the HolidayAgent website operated by Travel Tech Ltd.
            </p>
            <p>
              <strong>"User"</strong> refers to the individual accessing or using the Service, or the company, 
              or other legal entity on behalf of which such individual is accessing or using the Service, as applicable.
            </p>
            
            <h2>3. Use of Service</h2>
            <p>
              HolidayAgent provides a platform for comparing and booking holiday packages from various providers. 
              The information presented is for general information purposes only. We make no guarantees regarding the 
              accuracy, completeness, or reliability of this information.
            </p>
            
            <h2>4. Bookings and Payments</h2>
            <p>
              When you make a booking through our service:
            </p>
            <ul>
              <li>You agree to provide accurate and complete information.</li>
              <li>The contract for the holiday package is between you and the selected travel provider.</li>
              <li>You are responsible for reviewing the specific terms and conditions of the travel provider.</li>
              <li>All payments are processed securely through our payment processors.</li>
            </ul>
            
            <h2>5. User Accounts</h2>
            <p>
              When you create an account with us, you must provide information that is accurate, complete, and current 
              at all times. Failure to do so constitutes a breach of the Terms, which may result in immediate termination 
              of your account on our Service.
            </p>
            
            <h2>6. Intellectual Property</h2>
            <p>
              The Service and its original content, features, and functionality are and will remain the exclusive property 
              of HolidayAgent and its licensors. The Service is protected by copyright, trademark, and other laws.
            </p>
            
            <h2>7. Limitation of Liability</h2>
            <p>
              In no event shall HolidayAgent, nor its directors, employees, partners, agents, suppliers, or affiliates, 
              be liable for any indirect, incidental, special, consequential or punitive damages, including without limitation, 
              loss of profits, data, use, goodwill, or other intangible losses, resulting from your access to or use of or 
              inability to access or use the Service.
            </p>
            
            <h2>8. Changes to Terms</h2>
            <p>
              We reserve the right, at our sole discretion, to modify or replace these Terms at any time. By continuing 
              to access or use our Service after those revisions become effective, you agree to be bound by the revised terms.
            </p>
            
            <h2>9. Contact Us</h2>
            <p>
              If you have any questions about these Terms, please contact us at legal@holidayagent.com.
            </p>
          </div>
        </div>
      </div>
    </Layout>
  );
}
