export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Link from 'next/link';

export default function BlogPage() {
  const posts = [
    {
      slug: 'ai-vs-humans-in-travel',
      title: 'Can AI Really Replace Human Travel Agents?',
      summary:
        'We tested HolidayGo2’s agents against legacy booking sites and concierge teams. Here’s what happened.',
    },
    {
      slug: 'why-voice-first-matters',
      title: 'Voice-First Travel: Accessibility or Gimmick?',
      summary:
        'A deep dive into why neurodiverse and overwhelmed users are finally getting a system built for them.',
    },
  ];

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">HolidayGo2 Blog</h1>
        <ul className="space-y-6">
          {posts.map((post) => (
            <li key={post.slug} className="bg-slate-900 border border-slate-700 p-4 rounded shadow">
              <h2 className="text-xl font-semibold text-white mb-1">{post.title}</h2>
              <p className="text-sm text-slate-400 mb-2">{post.summary}</p>
              <Link
                href={`/blog/${post.slug}`}
                className="text-blue-400 underline text-sm"
              >
                Read More →
              </Link>
            </li>
          ))}
        </ul>
      </section>
    </Layout>
  );
}
