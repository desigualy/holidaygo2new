export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { notFound } from 'next/navigation';

interface Post {
  title: string;
  content: string;
}

const posts: Record<string, Post> = {
  'ai-vs-humans-in-travel': {
    title: 'Can AI Really Replace Human Travel Agents?',
    content: `We ran a blind test with three agents: one human concierge, one traditional travel app, and one powered by Ch@ and Ms Trav-Elle.

The AI pair outperformed in speed, stress reduction, and itinerary complexity. But empathy? That still belongs to humans… for now.`,
  },
  'why-voice-first-matters': {
    title: 'Voice-First Travel: Accessibility or Gimmick?',
    content: `Many platforms treat voice input like a novelty. HolidayGo2 doesn't. We built our stack to respect users with dyslexia, low vision, and cognitive overload.

This isn't a gimmick. It's a necessity.`,
  },
};

export default function BlogPostPage({ params }: { params: { slug: string } }) {
  const post = posts[params.slug];

  if (!post) return notFound();

  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">{post.title}</h1>
        <article className="text-base whitespace-pre-wrap text-slate-200 leading-relaxed">
          {post.content}
        </article>
      </section>
    </Layout>
  );
}
