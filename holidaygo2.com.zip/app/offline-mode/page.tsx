export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import Link from 'next/link';

export default function OfflineModePage() {
  return (
    <Layout>
      <section className="max-w-3xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-4">Offline Mode</h1>
        <p className="text-slate-300 mb-6">
          Lost connection? No problem. HolidayGo2 automatically enters offline mode and lets you keep planning.
        </p>

        <div className="space-y-6">
          <div className="bg-slate-900 p-4 rounded border border-slate-700 shadow">
            <h2 className="text-xl font-semibold mb-2">Saved Trips</h2>
            <ul className="text-sm text-slate-200 space-y-1">
              <li>• Rome – 3 nights – £312</li>
              <li>• Dubrovnik – 4 nights – £421</li>
            </ul>
          </div>

          <div className="bg-slate-900 p-4 rounded border border-slate-700 shadow">
            <h2 className="text-xl font-semibold mb-2">Last Sync</h2>
            <p className="text-sm text-slate-400">Synced 2 hours ago via Wi-Fi.</p>
          </div>

          <div className="bg-slate-900 p-4 rounded border border-slate-700 shadow">
            <h2 className="text-xl font-semibold mb-2">Reconnect</h2>
            <p className="text-sm text-slate-400 mb-2">
              You're currently offline. For live data, reconnect to the internet.
            </p>
            <Link
              href="/search"
              className="inline-block bg-blue-600 hover:bg-blue-700 px-4 py-2 rounded text-white text-sm"
            >
              Return to Search
            </Link>
          </div>
        </div>
      </section>
    </Layout>
  );
}
