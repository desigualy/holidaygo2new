// app/archive/search/filters/index.tsx

'use client';

import { useState } from 'react';
import { Card } from '@/components/ui/card';

export default function FiltersIndexPage() {
  const [filters, setFilters] = useState({
    direct: false,
    luxury: false,
    family: false,
    offSeason: false,
  });

  const toggle = (key: keyof typeof filters) =>
    setFilters((f) => ({ ...f, [key]: !f[key] }));

  return (
    <main className="px-6 py-12 max-w-3xl mx-auto">
      <h1 className="text-2xl font-bold mb-4">Archived Filters</h1>
      <p className="text-sm text-gray-600 mb-6">
        These are legacy filters from an earlier search engine. 
        Some may still influence fallback queries handled by Miss Triv or Ms Trav-Elle.
      </p>

      <div className="grid gap-4">
        {Object.entries(filters).map(([key, value]) => (
          <Card key={key}>
            <label className="flex items-center gap-3">
              <input
                type="checkbox"
                checked={value}
                onChange={() => toggle(key as keyof typeof filters)}
              />
              <span className="capitalize">{key.replace(/([A-Z])/g, ' $1')}</span>
            </label>
          </Card>
        ))}
      </div>
    </main>
  );
}
