// app/archive/search/results/page.tsx

import { Metadata } from 'next';
import Layout from '@/components/layout/Layout';
import { ResultCard } from '@/components/search/ResultCard';
import { HolidayPackage } from '@/types/holiday';

export const metadata: Metadata = {
  title: 'Archived Results · HolidayGo2',
  description: 'Legacy results view for historic or fallback queries.',
};

// Mocked sample results
const results: HolidayPackage[] = [
  {
    id: 'trip001',
    destination: 'Lisbon, Portugal',
    description: '4 nights near Alfama with ocean views.',
    price: 420,
    image_url: '/gallery/city.jpg',
  },
  {
    id: 'trip002',
    destination: 'Madeira Island',
    description: 'Lush cliffs, wine tasting, 5 nights.',
    price: 680,
    image_url: '/gallery/island.jpg',
  },
  {
    id: 'trip003',
    destination: 'Granada, Spain',
    description: 'Alhambra views + Flamenco street life.',
    price: 390,
    image_url: '/gallery/desert.jpg',
  },
];

export default function ArchiveResultsPage() {
  return (
    <Layout>
      <section className="px-6 py-12 max-w-5xl mx-auto">
        <h1 className="text-3xl font-bold mb-6">Archived Search Results</h1>
        <p className="text-sm text-gray-600 mb-6">
          These results were retrieved from a fallback index. 
          Display is visual-only — actions and bookings are disabled.
        </p>
        <div className="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-3 gap-4">
          {results.map((pkg) => (
            <ResultCard key={pkg.id} pkg={pkg} />
          ))}
        </div>
      </section>
    </Layout>
  );
}
