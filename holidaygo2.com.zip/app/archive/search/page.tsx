export const runtime = 'edge';

import Layout from '@/components/layout/Layout';
import { SearchForm } from '@/components/search/SearchForm';

export const metadata = {
  title: 'Archived Search · HolidayGo2',
  description: 'Explore past search activity.',
};

export default function ArchivedSearchPage() {
  return (
    <Layout>
      <div className="max-w-4xl mx-auto py-10 text-white">
        <h1 className="text-2xl font-bold mb-4 text-slate-200">Archived Search</h1>
        <SearchForm onSearch={() => {}} />
      </div>
    </Layout>
  );
}
