// app/archive/search/layout.tsx

export const runtime = 'edge';

export default function ArchiveSearchLayout({ children }: { children: React.ReactNode }) {
  return <>{children}</>;
}
