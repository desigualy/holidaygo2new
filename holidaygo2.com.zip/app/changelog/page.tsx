export const runtime = 'edge';

import Layout from '@/components/layout/Layout';

export default function ChangelogPage() {
  const logs = [
    {
      date: '2025-05-17',
      changes: [
        '🎯 Rebuilt full site using App Router structure',
        '🎨 Matched all layouts to old.zip (Node.js legacy)',
        '🚫 Removed broken pages and placeholders from prior build',
        '🧠 Canon-locked all 63 pages to match project vision',
      ],
    },
    {
      date: '2025-05-12',
      changes: [
        '🧩 Supabase integration patched for session + RLS',
        '🎤 Voice recognition scaffolded via Web Speech API',
        '🧭 Map view migrated from static iframe to JS SDK',
      ],
    },
    {
      date: '2025-05-05',
      changes: [
        '🌍 Offline Mode added with last sync display',
        '👁 Accessibility controls wrapped with dynamic font preview',
        '🧪 Experimental: E-Colette Echo log prototype',
      ],
    },
  ];

  return (
    <Layout>
      <section className="max-w-4xl mx-auto px-6 py-10 text-white">
        <h1 className="text-3xl font-bold text-cyan-400 mb-6">Changelog</h1>
        {logs.map((log, idx) => (
          <div key={idx} className="mb-6 bg-slate-900 border border-slate-700 p-4 rounded shadow">
            <h2 className="text-lg font-semibold text-blue-300 mb-2">{log.date}</h2>
            <ul className="list-disc list-inside text-sm text-slate-300 space-y-1">
              {log.changes.map((change, i) => (
                <li key={i}>{change}</li>
              ))}
            </ul>
          </div>
        ))}
      </section>
    </Layout>
  );
}
