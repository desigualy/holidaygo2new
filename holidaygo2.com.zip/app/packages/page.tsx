'use client';

import { useState, useEffect } from 'react';
import { Card, CardContent } from '@/components/ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { ResultCard } from '@/components/search/ResultCard';
import { SearchForm, SearchFormValues } from '@/components/search/SearchForm';
import { HolidayPackage } from '@/types/holiday';
import { toast } from 'sonner';

const Packages = () => {
  const [packages, setPackages] = useState<HolidayPackage[]>([]);
  const [filteredPackages, setFilteredPackages] = useState<HolidayPackage[]>([]);
  const [isLoading, setIsLoading] = useState(true);
  const [selectedTab, setSelectedTab] = useState("all");

  useEffect(() => {
    const fetchPackages = async () => {
      setIsLoading(true);
      try {
        // Check if we have cached packages first
        const cachedPackages = JSON.parse(localStorage.getItem('allPackages') || '[]');
        
        if (cachedPackages.length > 0) {
          setPackages(cachedPackages);
          setFilteredPackages(cachedPackages);
          setIsLoading(false);
          return;
        }
        
        // Simulate API call delay
        await new Promise(resolve => setTimeout(resolve, 1000));
        
        // Sample vacation packages data
        const samplePackages: HolidayPackage[] = [
          {
            id: "vp-1",
            title: "All-Inclusive Caribbean Escape",
            destination: "Punta Cana, Dominican Republic",
            departureAirport: "New York (JFK)",
            provider: {
              id: "suntravel",
              name: "Sun Travel",
              logo: "/assets/logos/suntravel.png"
            },
            nights: 7,
            adults: 2,
            children: 0,
            departureDate: "2025-06-15",
            returnDate: "2025-06-22",
            priceBreakdown: {
              basePrice: 1299,
              flightPrice: 650,
              hotelPrice: 1150,
              transferPrice: 50,
              tax: 149,
              fees: 50,
              totalPrice: 1999,
              flights: 650,
              hotel: 1150,
              transfers: 50,
              taxesAndFees: 149
            },
            hotelStars: 4.5,
            boardBasis: "All Inclusive",
            flightClass: "Economy",
            baggage: "23kg",
            transferIncluded: true,
            roomType: "Ocean View Suite",
            imageUrl: "https://images.unsplash.com/photo-1568084680786-a84f91d1153c?q=80&w=800&auto=format&fit=crop",
            url: "#",
            savingsPercent: 15
          },
          {
            id: "vp-2",
            title: "European Adventure Package",
            destination: "Barcelona, Madrid, and Seville",
            departureAirport: "London Heathrow",
            provider: {
              id: "eurotrips",
              name: "EuroTrips",
              logo: "/assets/logos/eurotrips.png"
            },
            nights: 10,
            adults: 2,
            children: 0,
            departureDate: "2025-09-10",
            returnDate: "2025-09-20",
            priceBreakdown: {
              basePrice: 1899,
              flightPrice: 800,
              hotelPrice: 1400,
              transferPrice: 100,
              tax: 199,
              fees: 100,
              totalPrice: 2599,
              flights: 800,
              hotel: 1400,
              transfers: 100,
              taxesAndFees: 299
            },
            hotelStars: 4,
            boardBasis: "Bed & Breakfast",
            flightClass: "Economy",
            baggage: "20kg",
            transferIncluded: true,
            roomType: "Standard Room",
            imageUrl: "https://images.unsplash.com/photo-1543783207-ec64e4d95325?q=80&w=800&auto=format&fit=crop",
            url: "#",
            savingsPercent: 10
          },
          {
            id: "vp-3",
            title: "Family Fun in Orlando",
            destination: "Orlando, Florida",
            departureAirport: "Chicago O'Hare",
            provider: {
              id: "familyvacations",
              name: "Family Vacations",
              logo: "/assets/logos/familyvacations.png"
            },
            nights: 7,
            adults: 2,
            children: 2,
            departureDate: "2025-07-20",
            returnDate: "2025-07-27",
            priceBreakdown: {
              basePrice: 2499,
              flightPrice: 1200,
              hotelPrice: 1800,
              transferPrice: 100,
              tax: 250,
              fees: 150,
              totalPrice: 3500,
              flights: 1200,
              hotel: 1800,
              transfers: 100,
              taxesAndFees: 400
            },
            hotelStars: 4,
            boardBasis: "Room Only",
            flightClass: "Economy",
            baggage: "23kg",
            transferIncluded: true,
            roomType: "Family Suite",
            imageUrl: "https://images.unsplash.com/photo-1575318634028-6a0cfcb60c59?q=80&w=800&auto=format&fit=crop",
            url: "#",
            savingsPercent: 18
          },
          {
            id: "vp-4",
            title: "Luxury Asian Tour",
            destination: "Tokyo, Kyoto, and Osaka",
            departureAirport: "San Francisco (SFO)",
            provider: {
              id: "asianadventures",
              name: "Asian Adventures",
              logo: "/assets/logos/asianadventures.png"
            },
            nights: 14,
            adults: 2,
            children: 0,
            departureDate: "2025-11-05",
            returnDate: "2025-11-19",
            priceBreakdown: {
              basePrice: 3299,
              flightPrice: 1800,
              hotelPrice: 2400,
              transferPrice: 200,
              tax: 350,
              fees: 250,
              totalPrice: 5000,
              flights: 1800,
              hotel: 2400,
              transfers: 200,
              taxesAndFees: 600
            },
            hotelStars: 5,
            boardBasis: "Half Board",
            flightClass: "Premium Economy",
            baggage: "30kg",
            transferIncluded: true,
            roomType: "Deluxe Room",
            imageUrl: "https://images.unsplash.com/photo-1528360983277-13d401cdc186?q=80&w=800&auto=format&fit=crop",
            url: "#",
            savingsPercent: 12
          }
        ];
        
        // Cache packages for future use
        localStorage.setItem('allPackages', JSON.stringify(samplePackages));
        
        setPackages(samplePackages);
        setFilteredPackages(samplePackages);
      } catch (error) {
        console.error("Error fetching packages:", error);
        toast.error("Failed to load vacation packages");
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchPackages();
  }, []);

  const handleSearch = (values: SearchFormValues) => {
    setIsLoading(true);
    
    setTimeout(() => {
      const searchResults = packages.filter((pkg) => {
        const matchesDestination = values.destination 
          ? pkg.destination.toLowerCase().includes(values.destination.toLowerCase())
          : true;
        
        const matchesDeparture = values.from
          ? pkg.departureAirport.toLowerCase().includes(values.from.toLowerCase())
          : true;
        
        return matchesDestination && matchesDeparture;
      });
      
      setFilteredPackages(searchResults);
      setIsLoading(false);
      
      toast(`Found ${searchResults.length} matching vacation packages`);
    }, 800);
  };

  const handleTabChange = (value: string) => {
    setSelectedTab(value);
    setIsLoading(true);
    
    setTimeout(() => {
      if (value === "all") {
        setFilteredPackages(packages);
      } else if (value === "family") {
        const familyPackages = packages.filter(pkg => pkg.children > 0);
        setFilteredPackages(familyPackages);
      } else if (value === "couples") {
        const couplesPackages = packages.filter(pkg => pkg.adults === 2 && pkg.children === 0);
        setFilteredPackages(couplesPackages);
      } else if (value === "luxury") {
        const luxuryPackages = packages.filter(pkg => pkg.hotelStars >= 4.5);
        setFilteredPackages(luxuryPackages);
      }
      
      setIsLoading(false);
    }, 500);
  };

  return (
    <div className="container mx-auto px-4 py-8 mt-20">
      <h1 className="text-3xl font-bold mb-2">Vacation Packages</h1>
      <p className="text-muted-foreground mb-8">
        Browse our selection of all-inclusive vacation packages and bundle deals.
      </p>
      
      {/* Search Form */}
      <div className="mb-8">
        <SearchForm 
          onSearch={handleSearch}
          isCompact={true} 
          initialValues={{
            destination: '',
            from: '',
            travelers: { adults: 2, children: 0, infants: 0 }
          }}
        />
      </div>
      
      {/* Package Types */}
      <div className="mb-6">
        <Tabs value={selectedTab} onValueChange={handleTabChange}>
          <TabsList className="mb-4">
            <TabsTrigger value="all">All Packages</TabsTrigger>
            <TabsTrigger value="family">Family Packages</TabsTrigger>
            <TabsTrigger value="couples">Couples Getaways</TabsTrigger>
            <TabsTrigger value="luxury">Luxury Retreats</TabsTrigger>
          </TabsList>
          
          <TabsContent value="all">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : filteredPackages.length > 0 ? (
              <div className="space-y-6">
                {filteredPackages.map((pkg) => (
                  <ResultCard 
                    key={pkg.id} 
                    package={pkg} 
                    isBestValue={pkg.savingsPercent && pkg.savingsPercent > 15}
                    enhancedData={{ joyScore: 0.85 }}
                  />
                ))}
              </div>
            ) : (
              <Card className="text-center p-12">
                <CardContent>
                  <h2 className="text-2xl font-medium mb-4">No Matching Packages</h2>
                  <p>We couldn't find any packages matching your search criteria. Try adjusting your filters.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="family">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : filteredPackages.length > 0 ? (
              <div className="space-y-6">
                {filteredPackages.map((pkg) => (
                  <ResultCard 
                    key={pkg.id} 
                    package={pkg}
                    isBestValue={pkg.id === "vp-3"}
                  />
                ))}
              </div>
            ) : (
              <Card className="text-center p-12">
                <CardContent>
                  <h2 className="text-2xl font-medium mb-4">No Family Packages Available</h2>
                  <p>We don't have any family packages matching your criteria at the moment. Try broadening your search.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="couples">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : filteredPackages.length > 0 ? (
              <div className="space-y-6">
                {filteredPackages.map((pkg) => (
                  <ResultCard 
                    key={pkg.id} 
                    package={pkg}
                    isBestValue={pkg.id === "vp-1"}
                  />
                ))}
              </div>
            ) : (
              <Card className="text-center p-12">
                <CardContent>
                  <h2 className="text-2xl font-medium mb-4">No Couples Packages Available</h2>
                  <p>We don't have any couples packages matching your criteria at the moment. Try broadening your search.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
          
          <TabsContent value="luxury">
            {isLoading ? (
              <div className="flex justify-center py-12">
                <div className="animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary"></div>
              </div>
            ) : filteredPackages.length > 0 ? (
              <div className="space-y-6">
                {filteredPackages.map((pkg) => (
                  <ResultCard 
                    key={pkg.id} 
                    package={pkg}
                    isBestValue={pkg.id === "vp-4"}
                  />
                ))}
              </div>
            ) : (
              <Card className="text-center p-12">
                <CardContent>
                  <h2 className="text-2xl font-medium mb-4">No Luxury Packages Available</h2>
                  <p>We don't have any luxury packages matching your criteria at the moment. Try broadening your search.</p>
                </CardContent>
              </Card>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
};

export default Packages;
