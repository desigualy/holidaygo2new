'use client';

import { useState, useEffect } from "react";
import { useSearchParams, useRouter } from 'next/navigation';
import { toast } from "@/hooks/use-toast";
import { Card, CardContent } from "@/components/ui/card";
import { Skeleton } from "@/components/ui/skeleton";
import { Building } from "lucide-react";
import SearchPageHeader from '@/components/hotels/SearchPageHeader';
import HotelCard from '@/components/hotels/HotelCard';
import PopularDestination from '@/components/hotels/PopularDestination';
import FilterSection from '@/components/hotels/FilterSection';
import hotelService, { Hotel } from '@/services/hotelService';
import EdgeAISection from './components/EdgeAISection';
import SearchTabs from './components/SearchTabs';
import SearchLayout from './components/SearchLayout';

const Search = () => {
  const searchParams = useSearchParams();
  const router = useRouter();

  // State for search form
  const [location, setLocation] = useState(searchParams.get('location') || 'Mumbai, India');
  const [checkIn, setCheckIn] = useState<Date | undefined>(undefined);
  const [checkOut, setCheckOut] = useState<Date | undefined>(undefined);
  const [guests, setGuests] = useState(searchParams.get('guests') || '2');
  
  // State for results and loading
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [searched, setSearched] = useState(false);
  
  // State for filters
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 500]);
  const [minRating, setMinRating] = useState(0);
  const [sortBy, setSortBy] = useState('recommended');
  
  // Get popular destinations
  const popularDestinations = hotelService.getPopularDestinations();

  // Search for hotels
  const searchHotels = async () => {
    if (!location) {
      toast({
        title: "Location required",
        description: "Please enter a valid location to search hotels",
        variant: "destructive"
      });
      return;
    }

    setLoading(true);
    setError(null);

    try {
      // Update URL parameters
      router.push(`/search?location=${location}&guests=${guests}&checkIn=${checkIn?.toISOString()}&checkOut=${checkOut?.toISOString()}`);
      
      const results = await hotelService.searchHotels({
        location,
        checkIn: checkIn?.toISOString(),
        checkOut: checkOut?.toISOString(),
        guests: parseInt(guests, 10),
        minPrice: priceRange[0],
        maxPrice: priceRange[1],
        minRating
      });
      
      setHotels(results);
      setSearched(true);
      
      // If no results, show a toast
      if (results.length === 0) {
        toast({
          title: "No hotels found",
          description: "Try adjusting your search criteria or explore our popular destinations.",
          variant: "default"
        });
      }
    } catch (err) {
      console.error('Error fetching hotels:', err);
      setError('Failed to fetch hotels. Please try again later.');
      toast({
        title: "Error",
        description: "Failed to fetch hotels. Please try again later.",
        variant: "destructive"
      });
    } finally {
      setLoading(false);
    }
  };

  // Apply filters
  const applyFilters = () => {
    searchHotels();
  };
  
  // Reset filters
  const resetFilters = () => {
    setPriceRange([0, 500]);
    setMinRating(0);
    setSortBy('recommended');
    searchHotels();
  };
  
  // Handle sort
  useEffect(() => {
    if (hotels.length > 0) {
      let sortedHotels = [...hotels];
      
      switch (sortBy) {
        case 'price-low':
          sortedHotels.sort((a, b) => 
            a.price_breakdown.gross_price - b.price_breakdown.gross_price
          );
          break;
        case 'price-high':
          sortedHotels.sort((a, b) => 
            b.price_breakdown.gross_price - a.price_breakdown.gross_price
          );
          break;
        case 'rating':
          sortedHotels.sort((a, b) => b.review_score - a.review_score);
          break;
        default:
          break;
      }
      
      setHotels(sortedHotels);
    }
  }, [sortBy]);
  
  // Search on initial load if location is in URL
  useEffect(() => {
    if (searchParams.get('location')) {
      searchHotels();
    }
  }, [searchParams]);

  return (
    <div className="min-h-screen flex flex-col pt-0">
      <main className="flex-grow">
        <div className="container mx-auto px-4 py-8">
          <div className="mb-6">
            <h1 className="text-3xl font-bold text-gray-900">Hotel Search</h1>
            <p className="text-muted-foreground mt-2">
              Find and compare hotels, apartments, and other accommodations worldwide.
            </p>
          </div>

          <SearchSection 
            location={location}
            setLocation={setLocation}
            checkIn={checkIn}
            setCheckIn={setCheckIn}
            checkOut={checkOut}
            setCheckOut={setCheckOut}
            guests={guests}
            setGuests={setGuests}
            handleSearch={searchHotels}
            isLoading={loading}
          />

          {error && (
            <div className="bg-destructive/10 p-4 rounded-lg mb-6 text-destructive">
              {error}
            </div>
          )}

          {searched && (
            <FilterSection 
              priceRange={priceRange}
              setPriceRange={setPriceRange}
              minRating={minRating}
              setMinRating={setMinRating}
              sortBy={sortBy}
              setSortBy={setSortBy}
              applyFilters={applyFilters}
              resetFilters={resetFilters}
            />
          )}

          {loading ? (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
              {[1, 2, 3, 4, 5, 6].map((i) => (
                <Card key={i} className="overflow-hidden">
                  <Skeleton className="h-48 w-full" />
                  <CardContent className="p-4">
                    <Skeleton className="h-6 w-3/4 mb-2" />
                    <Skeleton className="h-4 w-full mb-2" />
                    <Skeleton className="h-4 w-2/3" />
                  </CardContent>
                </Card>
              ))}
            </div>
          ) : hotels.length > 0 ? (
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h2 className="text-xl font-bold">Hotels in {location}</h2>
                <div className="text-sm text-muted-foreground">
                  {hotels.length} {hotels.length === 1 ? 'property' : 'properties'} found
                </div>
              </div>
              
              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {hotels.map((hotel) => (
                  <HotelCard key={hotel.id} hotel={hotel} />
                ))}
              </div>
            </div>
          ) : searched ? (
            <Card className="py-12">
              <CardContent className="flex flex-col items-center justify-center text-center">
                <Building className="h-12 w-12 text-muted-foreground mb-4" />
                <h2 className="text-xl font-semibold mb-2">No results found</h2>
                <p className="text-muted-foreground max-w-md mb-6">
                  Try adjusting your search criteria or explore our popular destinations.
                </p>
              </CardContent>
            </Card>
          ) : (
            <div className="bg-muted p-12 rounded-lg text-center">
              <Building className="h-12 w-12 mx-auto mb-4 text-muted-foreground" />
              <h2 className="text-2xl font-medium mb-4">Find Your Perfect Stay</h2>
              <p className="text-muted-foreground mb-6">Enter a destination and search dates to discover amazing hotels.</p>
            </div>
          )}
          
          <div className="mt-16">
            <h2 className="text-2xl font-bold mb-6">Popular Destinations</h2>
            <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-6 gap-4">
              {popularDestinations.map((destination, index) => (
                <PopularDestination 
                  key={index}
                  name={destination.name}
                  img={destination.img}
                />
              ))}
            </div>
          </div>
        </div>
      </main>
    </div>
  );
};

export default Search;
