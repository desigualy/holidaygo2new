'use client';

import { useEffect, useState } from "react";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import { JobPosition } from "@/types/career";
import { DEPARTMENTS, JOB_POSITIONS } from "@/data/jobPositions";
import CompanyValues from "@/components/careers/CompanyValues";
import JobFilter from "@/components/careers/JobFilter";
import JobsList from "@/components/careers/JobsList";
import JobDetails from "@/components/careers/JobDetails";
import ProspectorApplication from "@/components/careers/ProspectorApplication";

export default function Careers() {
  const [selectedDepartment, setSelectedDepartment] = useState("All Departments");
  const [filteredJobs, setFilteredJobs] = useState<JobPosition[]>(JOB_POSITIONS);
  const [selectedJob, setSelectedJob] = useState<JobPosition | null>(null);
  const [activeTab, setActiveTab] = useState("positions");

  useEffect(() => {
    if (selectedDepartment === "All Departments") {
      setFilteredJobs(JOB_POSITIONS);
    } else {
      setFilteredJobs(JOB_POSITIONS.filter(job => job.department === selectedDepartment));
    }
  }, [selectedDepartment]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, []);

  return (
    <div className="container mx-auto py-12 px-4">
      <div className="max-w-3xl mx-auto text-center mb-12">
        <h1 className="text-3xl sm:text-4xl font-bold mb-4">Join Our Team</h1>
        <p className="text-lg text-muted-foreground mb-6">
          We're building the future of travel and we need passionate people to help us get there.
        </p>
        <div className="flex flex-wrap justify-center gap-3">
          <Badge variant="outline" className="text-sm py-1 px-3">Flexible Work Options</Badge>
          <Badge variant="outline" className="text-sm py-1 px-3">Competitive Salary</Badge>
          <Badge variant="outline" className="text-sm py-1 px-3">Travel Benefits</Badge>
          <Badge variant="outline" className="text-sm py-1 px-3">Health Insurance</Badge>
          <Badge variant="outline" className="text-sm py-1 px-3">Learning Budget</Badge>
        </div>
      </div>

      <div className="max-w-5xl mx-auto mb-8">
        <CompanyValues />
      </div>

      <div className="max-w-6xl mx-auto">
        <Tabs defaultValue="positions" value={activeTab} onValueChange={setActiveTab} className="w-full">
          <div className="flex justify-between items-center mb-6">
            <h2 className="text-2xl font-bold">Career Opportunities</h2>
            <TabsList>
              <TabsTrigger value="positions">Open Positions</TabsTrigger>
              <TabsTrigger value="sales">Sales Team</TabsTrigger>
            </TabsList>
          </div>

          <TabsContent value="positions">
            <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
              <div className="lg:col-span-1">
                <JobFilter
                  departments={DEPARTMENTS}
                  selectedDepartment={selectedDepartment}
                  onDepartmentChange={setSelectedDepartment}
                />
              </div>
              <div className="lg:col-span-3">
                <Tabs defaultValue={selectedJob ? "details" : "list"} className="w-full">
                  <TabsList className="mb-4">
                    <TabsTrigger value="list">Job Listings</TabsTrigger>
                    <TabsTrigger value="details" disabled={!selectedJob}>Job Details</TabsTrigger>
                  </TabsList>
                  <TabsContent value="list">
                    <JobsList
                      jobs={filteredJobs}
                      onSelectJob={(job) => {
                        setSelectedJob(job);
                      }}
                    />
                  </TabsContent>
                  <TabsContent value="details">
                    {selectedJob && (
                      <JobDetails
                        job={selectedJob}
                        onBack={() => setSelectedJob(null)}
                      />
                    )}
                  </TabsContent>
                </Tabs>
              </div>
            </div>
          </TabsContent>

          <TabsContent value="sales">
            <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
              <div className="lg:col-span-4 order-2 lg:order-1">
                <div className="bg-primary/5 p-6 rounded-lg sticky top-24">
                  <h3 className="text-xl font-semibold mb-4">Join Our Sales Team</h3>
                  <p className="mb-4">
                    At HolidayGo2, our canvassers and prospectors are the frontline of our business.
                    We're looking for enthusiastic individuals who can:
                  </p>
                  <ul className="space-y-2 mb-6">
                    <li className="flex items-start">
                      <Badge className="mt-1 mr-2">1</Badge>
                      <span>Connect with potential customers and generate leads</span>
                    </li>
                    <li className="flex items-start">
                      <Badge className="mt-1 mr-2">2</Badge>
                      <span>Present our travel packages with enthusiasm and knowledge</span>
                    </li>
                    <li className="flex items-start">
                      <Badge className="mt-1 mr-2">3</Badge>
                      <span>Meet targets and contribute to the company's growth</span>
                    </li>
                    <li className="flex items-start">
                      <Badge className="mt-1 mr-2">4</Badge>
                      <span>Develop professionally in a supportive environment</span>
                    </li>
                  </ul>
                  <div className="bg-background p-4 rounded-lg mb-4">
                    <h4 className="font-medium mb-2">We offer:</h4>
                    <ul className="space-y-1 text-sm">
                      <li>• Competitive base salary + commission structure</li>
                      <li>• Comprehensive training program</li>
                      <li>• Travel industry discounts</li>
                      <li>• Clear career progression path</li>
                      <li>• Supportive team environment</li>
                    </ul>
                  </div>
                  <p className="text-sm text-muted-foreground">
                    No previous experience? No problem! We provide full training for the right candidates.
                  </p>
                </div>
              </div>

              <div className="lg:col-span-8 order-1 lg:order-2">
                <ProspectorApplication />
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}
