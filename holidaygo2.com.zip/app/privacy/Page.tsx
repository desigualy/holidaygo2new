'use client';

import { useState, useEffect } from 'react';
import { Layout } from '@/components/layout/Layout';
import { Shield } from "lucide-react";
import { Footer } from '@/components/layout/Footer';
import { Separator } from '@/components/ui/separator';

export default function Privacy() {
  return (
    <div className="min-h-screen flex flex-col bg-gray-50 dark:bg-gray-900">
      <Layout.Header />
      
      <main className="flex-grow pt-24 pb-16 px-4 md:px-6">
        <div className="max-w-4xl mx-auto">
          <div className="mb-8 text-center">
            <Shield className="h-12 w-12 mx-auto text-primary mb-3" />
            <h1 className="text-3xl font-bold">Privacy Policy</h1>
            <p className="text-muted-foreground mt-2">Last updated: May 1, 2025</p>
          </div>
          
          <div className="bg-white dark:bg-gray-800 rounded-xl shadow-sm p-6 md:p-8">
            <div className="prose dark:prose-invert max-w-none">
              <h2>1. Introduction</h2>
              <p>
                At HolidayAgent, we take your privacy seriously. This Privacy Policy explains how we collect, use, 
                disclose, and safeguard your information when you visit our website or use our services. Please read 
                this policy carefully to understand our practices regarding your personal data.
              </p>
              
              <h2>2. Information We Collect</h2>
              <p>
                We collect personal information that you voluntarily provide to us when you:
              </p>
              <ul>
                <li>Register for an account</li>
                <li>Search for holiday packages</li>
                <li>Make a booking</li>
                <li>Sign up for our newsletter</li>
                <li>Contact our customer service team</li>
              </ul>
              <p>
                This information may include:
              </p>
              <ul>
                <li>Name, email address, phone number, and billing address</li>
                <li>Payment information (credit card details are processed securely by our payment processors)</li>
                <li>Travel preferences and search history</li>
                <li>Passport information when required for booking</li>
              </ul>
              
              <h2>3. How We Use Your Information</h2>
              <p>
                We use the information we collect to:
              </p>
              <ul>
                <li>Provide, maintain, and improve our services</li>
                <li>Process and manage your bookings</li>
                <li>Send you important service information</li>
                <li>Respond to your inquiries and support requests</li>
                <li>Send marketing communications (if you've opted in)</li>
                <li>Personalize your experience</li>
                <li>Analyze usage patterns to improve our website</li>
              </ul>
              
              <h2>4. Cookies and Tracking Technologies</h2>
              <p>
                We use cookies and similar tracking technologies to track activity on our website and store certain 
                information. You can instruct your browser to refuse all cookies or to indicate when a cookie is being sent.
              </p>
              
              <h2>5. Data Sharing and Disclosure</h2>
              <p>
                We may share your information with:
              </p>
              <ul>
                <li>Travel providers to fulfill your bookings</li>
                <li>Service providers who perform services on our behalf</li>
                <li>Analytics and search engine providers that assist us in the improvement of our website</li>
                <li>Legal authorities when required by law</li>
              </ul>
              
              <h2>6. Data Security</h2>
              <p>
                We implement appropriate security measures to protect your personal information. However, no method of 
                transmission over the Internet or electronic storage is 100% secure, and we cannot guarantee absolute security.
              </p>
              
              <h2>7. Your Rights</h2>
              <p>
                Depending on your location, you may have rights regarding your personal data, including:
              </p>
              <ul>
                <li>Right to access</li>
                <li>Right to rectification</li>
                <li>Right to erasure</li>
                <li>Right to restrict processing</li>
                <li>Right to data portability</li>
                <li>Right to object</li>
                <li>Rights related to automated decision-making and profiling</li>
              </ul>
              
              <h2>8. Changes to This Privacy Policy</h2>
              <p>
                We may update our Privacy Policy from time to time. We will notify you of any changes by posting the 
                new Privacy Policy on this page and updating the "Last updated" date.
              </p>
              
              <h2>9. Contact Us</h2>
              <p>
                If you have any questions about this Privacy Policy, please contact us at privacy@holidayagent.com.
              </p>
            </div>
          </div>
        </div>
      </main>
      
      <Footer />
    </div>
  );
}
