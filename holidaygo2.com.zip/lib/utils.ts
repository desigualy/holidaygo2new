// lib/utils.ts

export function formatCurrency(value: number): string {
  return `£${value.toFixed(2)}`;
}

export function titleCase(str: string): string {
  return str
    .toLowerCase()
    .split(' ')
    .map((s) => s.charAt(0).toUpperCase() + s.slice(1))
    .join(' ');
}

export function sleep(ms: number): Promise<void> {
  return new Promise((res) => setTimeout(res, ms));
}
