// lib/tone.ts

export function detectEmotionalTone(input: string): 'neutral' | 'excited' | 'frustrated' | 'curious' {
  const lowered = input.toLowerCase();

  if (/amazing|love|wow|can't wait/.test(lowered)) return 'excited';
  if (/angry|upset|hate|annoyed|stupid/.test(lowered)) return 'frustrated';
  if (/\?$/.test(lowered) || /wonder|maybe|what if/.test(lowered)) return 'curious';

  return 'neutral';
}

export function toneToColor(tone: string): string {
  switch (tone) {
    case 'excited':
      return '#00B8D9';
    case 'frustrated':
      return '#FF5630';
    case 'curious':
      return '#FFC400';
    default:
      return '#CCC';
  }
}
