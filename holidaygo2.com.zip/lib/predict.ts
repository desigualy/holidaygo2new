// lib/predict.ts

interface PriceSample {
  date: string;
  price: number;
}

export function predictNextPrice(samples: PriceSample[]): number {
  if (samples.length < 2) return samples[0]?.price || 0;

  const last = samples[samples.length - 1].price;
  const prev = samples[samples.length - 2].price;
  const delta = last - prev;

  return Math.max(0, Math.round(last + delta * 0.8));
}

export function averagePrice(samples: PriceSample[]): number {
  if (!samples.length) return 0;
  const total = samples.reduce((sum, s) => sum + s.price, 0);
  return Math.round(total / samples.length);
}
