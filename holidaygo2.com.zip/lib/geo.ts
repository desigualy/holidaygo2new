// lib/geo.ts

export function formatLatLng(lat: number, lng: number): string {
  return `${lat.toFixed(4)}, ${lng.toFixed(4)}`;
}

export function getGeoBiasFromLocale(locale: string): string {
  if (locale.startsWith('en-GB')) return 'uk';
  if (locale.startsWith('en-US')) return 'us';
  if (locale.startsWith('fr')) return 'fr';
  return 'global';
}
