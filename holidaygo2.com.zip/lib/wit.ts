// lib/wit.ts

const WIT_API = 'https://api.wit.ai/message?v=20230501&q=';

export async function parseIntent(input: string, token: string) {
  const res = await fetch(`${WIT_API}${encodeURIComponent(input)}`, {
    headers: {
      Authorization: `Bearer ${token}`,
    },
  });

  if (!res.ok) {
    throw new Error('Failed to fetch intent from Wit.ai');
  }

  const data = await res.json();
  return data.entities || {};
}
