export async function routeLLM(input: string): Promise<string> {
  try {
    const response = await fetch('/api/llm', {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify({ input }),
    });

    if (!response.ok) throw new Error('LLM API error');
    const data = await response.json();
    return data.output || 'No response received.';
  } catch (err) {
    return 'Ch@ encountered an error while processing your request.';
  }
}
