// hooks/useSessionContinuity.ts

'use client';

import { useEffect } from 'react';

export default function useSessionContinuity() {
  useEffect(() => {
    const now = Date.now();
    localStorage.setItem('lastVisit', now.toString());
  }, []);
}
