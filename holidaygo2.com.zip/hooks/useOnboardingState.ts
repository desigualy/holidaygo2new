// hooks/useOnboardingState.ts

'use client';

import { useEffect, useState } from 'react';

export default function useOnboardingState() {
  const [hasSeenIntro, setHasSeenIntro] = useState(false);

  useEffect(() => {
    const seen = localStorage.getItem('hasSeenIntro');
    if (seen === 'true') {
      setHasSeenIntro(true);
    }
  }, []);

  const completeOnboarding = () => {
    localStorage.setItem('hasSeenIntro', 'true');
    setHasSeenIntro(true);
  };

  return { hasSeenIntro, completeOnboarding };
}
