// hooks/useTrollScan.ts

'use client';

import { useEffect, useState } from 'react';

export default function useTrollScan(input: string) {
  const [flagged, setFlagged] = useState(false);

  useEffect(() => {
    const keywords = ['idiot', 'dumb', 'useless', 'hate', 'stupid'];
    const lowered = input.toLowerCase();
    const matched = keywords.some((word) => lowered.includes(word));
    setFlagged(matched);
  }, [input]);

  return flagged;
}
