import { supabase } from '@/lib/supabaseClient';

export async function authMiddleware() {
  const {
    data: { session },
  } = await supabase.auth.getSession();

  return session;
}
