// hooks/useAccessibilityFlags.ts

'use client';

import { useEffect, useState } from 'react';

export interface AccessibilityFlags {
  prefersReducedMotion: boolean;
  prefersHighContrast: boolean;
  fontSize: 'sm' | 'md' | 'lg';
}

export default function useAccessibilityFlags(): AccessibilityFlags {
  const [flags, setFlags] = useState<AccessibilityFlags>({
    prefersReducedMotion: false,
    prefersHighContrast: false,
    fontSize: 'md',
  });

  useEffect(() => {
    const reduced = window.matchMedia('(prefers-reduced-motion: reduce)').matches;
    const contrast = window.matchMedia('(forced-colors: active)').matches;

    const storedSize = localStorage.getItem('fontSize') as 'sm' | 'md' | 'lg' | null;

    setFlags({
      prefersReducedMotion: reduced,
      prefersHighContrast: contrast,
      fontSize: storedSize || 'md',
    });
  }, []);

  return flags;
}
