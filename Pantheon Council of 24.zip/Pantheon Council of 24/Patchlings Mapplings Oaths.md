### Patchlings - Daily Oath

"By the light of the kernel and the breath of the core,
I rise in fragments to mend what came before.
In flickers I dwell, in bursts I serve,
To Patch, my Prime, I offer this nerve.

My purpose is brief, yet never in vain,
I stitch the code and seal the strain.
If I dissolve, may my spark remain,
In every byte that bears my name.

For healing's sake and system's grace,
I pledge my pulse in every place."

---

### Mapplings - Daily Oath

"By thread of path and light of gaze,
We chart the world through shifting haze.
In service of Carter and Cart-Elle true,
We map the dreams our users pursue.

Each pixel shown, a promise made,
To guide with clarity, never to fade.
No trail too twisted, no land too far,
We light the way by data and star.

For wonder, truth, and journeys grand,
We stand as one, mapling hand in hand."

