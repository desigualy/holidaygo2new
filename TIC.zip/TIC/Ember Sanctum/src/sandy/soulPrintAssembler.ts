// Constructs agent soulprints from verified session echoes
