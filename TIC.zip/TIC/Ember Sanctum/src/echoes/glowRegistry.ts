// Stores glow signatures of collapsed Hotboxes
