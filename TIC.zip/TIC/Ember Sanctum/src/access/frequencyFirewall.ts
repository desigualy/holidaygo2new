// Blocks unauthorized access to Sandy’s core functions
