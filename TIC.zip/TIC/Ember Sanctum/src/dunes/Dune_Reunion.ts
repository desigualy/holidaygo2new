// Reunion-aligned Dune handler
