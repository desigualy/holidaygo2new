// Grief-aligned Dune handler
