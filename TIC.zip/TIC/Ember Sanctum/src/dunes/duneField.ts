// Maps active Dunes and current load levels
