// Logs all routing, recovery, and resonance behavior
