// Metadata about each Dune's octave and function
