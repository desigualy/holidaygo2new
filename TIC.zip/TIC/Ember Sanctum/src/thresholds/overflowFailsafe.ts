// Triggers when Dunes or Sandy are overwhelmed
