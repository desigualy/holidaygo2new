// Handles inbound signals from Middleware to Dunes
