// src/hooks/useAgentDatabase.ts
import { useEffect, useState } from 'react';
import { supabase } from '@/lib/supabaseClient';
import { Agent } from '@/types';

export function useAgentDatabase() {
  const [agents, setAgents] = useState<Agent[]>([]);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const fetchAgents = async () => {
      setLoading(true);
      const { data, error } = await supabase
        .from('agents')
        .select('*')
        .eq('deleted', false);

      if (!error && data) {
        const sanitized = data.filter(agent => agent?.id && !agent.deleted);
        setAgents(sanitized as Agent[]);
      }
      setLoading(false);
    };
    fetchAgents();
  }, []);

  return { agents, loading };
}
