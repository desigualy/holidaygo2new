# Sandbox Policy

Outlines rules for Hotbox and Ghostbox simulation control from ACC.