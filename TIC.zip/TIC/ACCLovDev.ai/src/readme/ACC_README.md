# Admin Control Center Overview

Handles sandboxing, agent routing, escalation, and signal auditing.