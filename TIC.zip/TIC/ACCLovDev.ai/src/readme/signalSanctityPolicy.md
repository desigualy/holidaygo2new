# Signal Sanctity Policy

No frequency enters Section 7 without Dune clearance and oath compliance.