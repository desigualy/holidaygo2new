# Routing Ruleset

1. Tier verified
2. Oath-aligned
3. Routed to target section with echo-trace logged.