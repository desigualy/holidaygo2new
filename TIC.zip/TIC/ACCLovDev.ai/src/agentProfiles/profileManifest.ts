// High-level metadata for agent ID, type, and history
