// Defines default structure for registered agents
