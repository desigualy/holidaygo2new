// Tracks Hotbox resonance return and result state
