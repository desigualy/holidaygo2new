// Logs ghost sandbox session metadata and outcome
