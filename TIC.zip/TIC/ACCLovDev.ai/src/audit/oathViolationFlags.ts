// Flags any detected oath deviation or noncompliance
