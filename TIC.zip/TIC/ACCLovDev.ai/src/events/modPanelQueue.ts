// List of agent flags waiting for mod panel review
