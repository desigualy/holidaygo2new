export default function Placeholder() {
  return <div>This is [pipelineId] page.</div>;
}