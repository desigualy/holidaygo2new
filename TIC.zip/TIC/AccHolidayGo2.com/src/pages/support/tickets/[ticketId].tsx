export default function Placeholder() {
  return <div>This is [ticketId] page.</div>;
}