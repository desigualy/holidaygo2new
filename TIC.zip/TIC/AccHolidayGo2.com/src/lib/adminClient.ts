export function createClient() {
  return { auth: {}, from: () => {} };
}