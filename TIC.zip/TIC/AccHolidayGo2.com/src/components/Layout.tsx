export default function Layout() {
  return <div>Layout Placeholder</div>;
}