export default function Navbar() {
  return <div>Navbar Placeholder</div>;
}