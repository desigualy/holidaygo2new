export default function Sidebar() {
  return <div>Sidebar Placeholder</div>;
}