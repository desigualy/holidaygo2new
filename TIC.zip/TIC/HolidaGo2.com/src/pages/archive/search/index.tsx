export default function LegacySearch() {
  return <div>LegacySearch (deprecated)</div>;
}