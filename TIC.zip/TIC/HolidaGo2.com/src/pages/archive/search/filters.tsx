export default function LegacyFilters() {
  return <div>LegacyFilters (deprecated)</div>;
}