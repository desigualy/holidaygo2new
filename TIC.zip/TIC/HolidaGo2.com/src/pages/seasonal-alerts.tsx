export default function Placeholder() {
return <div>This is seasonal-alerts page.</div>;
}

