export default function FlightDetails() {
  return <div>FlightDetails works!</div>;
}