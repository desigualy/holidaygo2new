export default function FlightSearch() {
  return <div>FlightSearch works!</div>;
}