export default function FlightCheckout() {
  return <div>FlightCheckout works!</div>;
}