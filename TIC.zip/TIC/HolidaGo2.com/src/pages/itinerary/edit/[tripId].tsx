export default function Placeholder() {
return <div>This is [tripId] page.</div>;
}