export default function PackageExplorer() {
  return <div>PackageExplorer works!</div>;
}