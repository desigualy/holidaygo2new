export default function Placeholder() {
return <div>This is [bookingId] page.</div>;
}