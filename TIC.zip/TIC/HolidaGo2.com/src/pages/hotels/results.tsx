export default function HotelResults() {
  return <div>HotelResults works!</div>;
}