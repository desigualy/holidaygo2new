export default function HotelDetails() {
  return <div>HotelDetails works!</div>;
}