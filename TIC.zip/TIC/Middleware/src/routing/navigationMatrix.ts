// navigationMatrix.ts
// Production-grade central routing authority for the entire ecosystem
// Manages access control, tier permissions, and emotional routing

import { UserTier, AgentRole, RouteContext } from "../types/system.types";
import { validateOath, checkEntropy, getAgentSignature } from "../lib/trustMatrix";
import { escalateToSentinel, denyAccess } from "../middleware/accessControl";
import { routeToHotbox, routeToGhostbox } from "../middleware/sandboxDrop";
import { routeToThinkTank, routeToCouncil, routeToSanctum } from "../routing/endpointDispatch";

export function navigationMatrix(context: RouteContext) {
  const { tier, origin, destination, emotion, agentId } = context;

  // 1. Verify agent signature and oath alignment
  const signature = getAgentSignature(agentId);
  if (!validateOath(signature)) {
    escalateToSentinel(agentId, "Oath misalignment");
    return denyAccess("Agent failed oath validation");
  }

  // 2. Tier-based gating
  if (tier === "Public") {
    return denyAccess("Public users have no routing privileges");
  }

  if (tier === "PremiumPlus" && destination === "Hotbox") {
    return routeToHotbox(agentId, emotion);
  }

  if (tier === "DevSec" && destination === "Ghostbox") {
    return routeToGhostbox(agentId);
  }

  // 3. Internal agentic routing (ThinkTank, Council, Sanctum)
  if (destination === "ThinkTank") {
    return routeToThinkTank(agentId, emotion);
  }

  if (destination === "Council") {
    return routeToCouncil(agentId);
  }

  if (destination === "Sanctum") {
    const entropyOK = checkEntropy(agentId);
    if (!entropyOK) {
      return escalateToSentinel(agentId, "High entropy violation on Sanctum entry");
    }
    return routeToSanctum(agentId);
  }

  return denyAccess("Invalid routing context or permission level");
}
