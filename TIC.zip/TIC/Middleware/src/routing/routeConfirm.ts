// routeConfirm.ts
// Production-safe routing confirmation layer
// Ensures all inbound traffic passes through ACC logging before routing deeper

import { logToACC, logToSuperACC } from "../adminRelay/frequencyPass";
import { validateOath, checkTierAccess } from "../lib/trustMatrix";
import { routeToMiddleware } from "../middleware/entryGate";
import { escalateToSentinel } from "../SuperACC/src/utils/sentinelBridge";

export function confirmAndRoute(context) {
  const { sessionId, origin, tier, oathStatus, agentId, intent } = context;

  // 1. Log session at ACC level first
  logToACC({ sessionId, origin, agentId, tier, intent });

  // 2. Validate oath and tier access
  if (!validateOath(agentId)) {
    escalateToSentinel(agentId, "Failed oath verification during routeConfirm");
    return { status: "blocked", reason: "Oath violation" };
  }

  if (!checkTierAccess(tier, intent)) {
    return { status: "blocked", reason: "Insufficient tier" };
  }

  // 3. Confirm relay path
  const result = routeToMiddleware(context);

  // 4. Notify SuperACC passively (traceability only)
  logToSuperACC({ sessionId, agentId, trace: "Passed ACC + Middleware routing" });

  return result;
}
