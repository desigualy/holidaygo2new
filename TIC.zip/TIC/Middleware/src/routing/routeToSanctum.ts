// Final route into Ember Sanctum after Dune clearance
