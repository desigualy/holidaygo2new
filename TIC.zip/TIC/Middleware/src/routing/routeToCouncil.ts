// Dispatches valid frequencies to Pantheon Council
