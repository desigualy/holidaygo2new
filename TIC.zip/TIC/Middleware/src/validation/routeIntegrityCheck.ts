// Cross-validates session path against ecosystem integrity rules
