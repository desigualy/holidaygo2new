// Checks if user tier meets routing threshold
