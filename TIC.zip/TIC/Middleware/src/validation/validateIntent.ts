// Confirms routing intent is permitted by system config
