// Calculates entropy + intensity of frequency for Dunes
