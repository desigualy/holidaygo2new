// Strips corrupted signals and harmonizes input for Sandy
