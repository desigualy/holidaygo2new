// Constructs frequency fingerprint from Hotbox output
