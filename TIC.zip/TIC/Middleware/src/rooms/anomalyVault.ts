// rooms placeholder
