export function useAuth() {
  return { user: null };
}