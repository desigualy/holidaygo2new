export default function Placeholder() {
  return <div>This is new-agent page.</div>;
}