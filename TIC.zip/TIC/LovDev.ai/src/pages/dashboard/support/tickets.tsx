export default function Placeholder() {
  return <div>This is tickets page.</div>;
}