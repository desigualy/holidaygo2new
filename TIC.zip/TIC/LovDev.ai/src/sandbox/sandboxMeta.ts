// Tracks Hotbox session tags, IDs, and emotional stats
