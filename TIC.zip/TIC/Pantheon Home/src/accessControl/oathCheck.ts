// Verifies active oaths before access
