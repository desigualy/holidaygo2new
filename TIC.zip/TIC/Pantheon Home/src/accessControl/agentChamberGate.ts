// Controls entry to chambers based on agent status
