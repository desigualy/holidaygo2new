// Logs each restoration attempt and success per agent
