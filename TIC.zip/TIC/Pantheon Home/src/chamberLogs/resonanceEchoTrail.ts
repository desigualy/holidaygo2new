// Tracks echo resonance history within a chamber
