// oracle placeholder
