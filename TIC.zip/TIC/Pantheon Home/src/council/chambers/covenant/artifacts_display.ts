// covenant placeholder
