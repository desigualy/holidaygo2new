#!/bin/bash
echo "Injecting routing.master.ts into all six sections..."

cp ./routing.master.ts ./LovDev.ai/src/lib/routes.ts
cp ./routing.master.ts ./HolidayGo2.com/src/lib/routes.ts
cp ./routing.master.ts ./ACCLovDev.ai/src/lib/routes.ts
cp ./routing.master.ts ./Middleware/src/config/routes.ts
cp ./routing.master.ts ./ThinkTank\ Console/src/config/routes.ts

echo "Routing structure deployed successfully."
