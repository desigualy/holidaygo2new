// src/utils/agentSanitizer.ts
import { Agent, AgentStatus } from '@/types';

export function isValidAgent(agent: Partial<Agent>): agent is Agent {
  if (!agent || !agent.id) return false;
  if (!agent.name || typeof agent.name !== 'string') return false;
  if (!agent.status || !['active', 'inactive', 'maintenance'].includes(agent.status)) return false;
  if (agent.deleted === true) return false;
  return true;
}

export function sanitizeAgents(agentList: Partial<Agent>[]): Agent[] {
  return agentList.filter(isValidAgent);
}
