// src/lib/sessionGuard.ts
import { supabase } from '@/lib/supabaseClient'
import { Session } from '@supabase/supabase-js'

export async function validateSession(): Promise<Session | null> {
  const { data, error } = await supabase.auth.getSession()
  if (error) {
    console.warn('Session fetch failed:', error.message)
    return null
  }
  if (!data.session) {
    console.info('No session found')
    return null
  }
  return data.session
}

export function isAuthorizedRole(role: string): boolean {
  return ['admin', 'support'].includes(role)
}

export async function enforceSupabaseAuth(): Promise<'authorized' | 'unauthorized' | 'no-session'> {
  const session = await validateSession()
  if (!session) return 'no-session'

  const userRole = session.user?.user_metadata?.role || 'anon'

  if (!isAuthorizedRole(userRole)) {
    console.warn('Unauthorized role:', userRole)
    return 'unauthorized'
  }

  return 'authorized'
}
