## Lovdev.ai - FrontendAgent Generator (MVP Build)

### Overview
This module defines the generator logic for the FrontendAgent, responsible for building the UI layer based on structured user intent. It consumes `project_config.json` and outputs a fully scaffolded frontend using React and TailwindCSS.

---

### Input: `project_config.json` (Example)
```json
{
  "project_name": "TravelGo",
  "features": ["login", "calendar", "payment"],
  "design_style": "modern",
  "deployment_target": "vercel"
}
```

---

### Output Directory Structure
```
/frontend
├── public
│   └── index.html
├── src
│   ├── main.tsx
│   ├── App.tsx
│   ├── index.css
│   ├── components/
│   ├── pages/
│   │   ├── Home.tsx
│   │   ├── Login.tsx
│   │   └── Calendar.tsx
│   └── layouts/
├── tailwind.config.ts
├── postcss.config.js
└── tsconfig.json
```

---

### Generator Responsibilities

1. **Base Scaffold Generation**
   - Create directories: `components/`, `pages/`, `layouts/`
   - Scaffold `main.tsx`, `App.tsx`, `index.css`

2. **Page Generator Logic**
   - Use `features[]` to generate pages:
     - `login` → Login.tsx
     - `calendar` → Calendar.tsx
     - `payment` → Payment.tsx
   - Fallback: if a page fails, retry once, else alert Walk-On Monitor

3. **Design System Adapter**
   - Match `design_style` token:
     - `modern` → Use Tailwind with glassmorphic classes
     - `minimal` → Sparse spacing, mono font, grayscale
     - `vibrant` → Gradient backgrounds, larger padding

4. **Tailwind Setup Generator**
   - Write `tailwind.config.ts` with chosen theme
   - Insert `@tailwind` directives into `index.css`
   - Configure PostCSS middleware

5. **Routing Logic**
   - Use React Router DOM
   - Auto-generate route paths per page

---

### Example: `Home.tsx`
```tsx
export default function Home() {
  return (
    <div className="p-6 bg-gradient-to-br from-blue-500 to-purple-600 text-white">
      <h1 className="text-4xl font-bold">Welcome to TravelGo</h1>
      <p className="mt-2">Plan your perfect journey with ease.</p>
    </div>
  );
}
```

---

### Edge Handling
- If config is missing or invalid:
  - Notify ARC → log `FrontendBuildError`
  - Return fallback page (`UnderConstruction.tsx`)

---

### Future Enhancements
- Component library templates (buttons, inputs, modals)
- Animation token mapping (Framer Motion)
- Theme switching agent
- Preview embed into Walk-On Monitor

This generator forms the UI foundation for all ARC-initiated builds in lovdev.ai.

