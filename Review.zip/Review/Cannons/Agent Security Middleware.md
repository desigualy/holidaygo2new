// src/middleware/agentIntegrityGuard.ts
import { NextRequest, NextResponse } from 'next/server';
import { validateSession, isAuthorizedRole } from '@/lib/sessionGuard';
import { logMiddlewareEvent } from '@/utils/middlewareLog';

const SENSITIVE_AGENT_ROUTES = ['/admin/agents', '/admin/agents/', '/admin/agents/:id'];

export async function middleware(request: NextRequest) {
  const url = request.nextUrl;
  const pathname = url.pathname;
  const roleSafeRoutes = ['/login', '/public', '/'];

  // Skip non-sensitive paths
  if (!SENSITIVE_AGENT_ROUTES.some(route => pathname.startsWith(route))) {
    return NextResponse.next();
  }

  const { session, user, error } = await validateSession();

  if (error === 'unauthorized') {
    logMiddlewareEvent({
      route: pathname,
      event: 'unauthorized access attempt',
      reason: 'no session',
    });
    return NextResponse.redirect(new URL('/login', request.url));
  }

  if (!isAuthorizedRole(session, ['admin', 'support'])) {
    logMiddlewareEvent({
      route: pathname,
      event: 'role block',
      reason: `role ${session?.user?.role} not authorized`,
    });
    return NextResponse.redirect(new URL('/forbidden', request.url));
  }

  // Passes all checks
  return NextResponse.next();
}

export const config = {
  matcher: ['/admin/agents/:path*'],
};
