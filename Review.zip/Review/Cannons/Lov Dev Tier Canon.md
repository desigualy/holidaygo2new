## Canon: LovDev.ai Tier Structure and Feature Access

This document canonizes the full access structure, file layout, and platform capability mapping for all three tiers of the **LovDev.ai** front-end platform.

---

### TIER LEVELS (Canonical)

#### **Free Tier**
- Entry-level access
- Designed for exploration, testing, and inclusive creative entry
- Includes:
  - ARK (basic interface + templated build)
  - Dreamweaver (Echo Mode only)
  - Oracle (silent emotional stabilizer)
  - Read-only agent viewer
  - Speech-to-text input for accessibility

#### **Premium Tier**
- Mid-level creative empowerment
- Includes:
  - ARK (expanded builder features)
  - Dreamweaver (interactive prompt mode)
  - Oracle (monitors outputs, silent feedback)
  - Architect (passive schema validation)
  - Analytics (performance + partial logs)
  - Support ticketing
  - System settings & updates
  - Speech-to-text accessibility retained

#### **Premium Plus Tier**
- Full capability release
- Includes:
  - Full ARK runtime konstruction
  - Full Dreamweaver interactive sandbox
  - Oracle (direct stabilizer access)
  - Architect (active review + validation)
  - GB (manual trigger access)
  - Full analytics and system logs
  - API hooks (if provisioned)
  - All tiers of agentic access, visual insights, and stabilizers

---

### AGENT MAPPING BY TIER
| Agent       | Free       | Premium            | Premium Plus         |
|-------------|------------|--------------------|----------------------|
| ARK         | ✓ Basic    | ✓ Expanded         | ✓ Full Konstructor   |
| Dreamweaver | Echo Only | ✓ Interactive (Limited) | ✓ Full Sandbox    |
| Oracle      | ✓ Silent   | ✓ Silent Monitor   | ✓ Direct Stabilizer  |
| Architect   | —          | ✓ Passive Review   | ✓ Active Validator   |
| GB          | —          | —                  | ✓ Triggerable        |

---

### FILE STRUCTURE BY TIER
See "LovDev_Tier_Specific_Trees" for canonical routing per access level.

---

### ACCESSIBILITY COMMITMENT (Universal)
- Speech-to-text input is **mandatory across all tiers**
- Enabled by `useSpeechToText.ts` and surfaced in UI
- Integrated into agent input flows and sandbox interfaces

---

This canon confirms the final, no-exception tier system for LovDev.ai and aligns all features, files, and agent access boundaries in preparation for full platform deployment.

