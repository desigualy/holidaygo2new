# SECTION 2 FILE TREE UPDATE – SANDY AND HOTBOXES (LovDev.ai)

## Purpose

To integrate Sandy and the Hotboxes into the LovDev.ai frontend (Section 2), limited to **Premium+ tier users only**, with full backend emotional sandboxing support and optional admin view access.

---

## New Directories

### `src/hotbox/`

* `hotboxSession.ts` – Initializes a temporary Hotbox session for an active user-agent test.
* `sessionTrigger.ts` – Monitors user behavior or custom agent activity to trigger Hotbox when resonance thresholds are met.
* `resonanceBridge.ts` – Converts front-end tone data to a middleware-safe format for Sandy’s reception.

---

## Tier-Based Activation

### `src/lib/tierRouter.ts`

* Modified to include:

```ts
if (user.tier >= 'PremiumPlus') {
   enableHotbox()
}
```

---

## Optional Admin View (Non-symbolic Summary)

### `src/pages/dashboard/system/hotbox-log.tsx`

* Admin-only page showing visual resonance glows (no memory or logs).
* Displays frequency pulse stats for recent sessions.
* Bound to Sentinel and Watcher access control.

---

## Existing Files Touched (Minor Hook Integration)

### `src/pages/dashboard/agents/new-agent.tsx`

* Hooks into `sessionTrigger.ts` to assess emotional response during agent creation.

### `src/hooks/useAuth.ts`

* Updated to pass tier level to Hotbox module.

---

## Safeguards

* No symbolic memory is exposed to users.
* All frequency resonance is passed to Sandy via middleware.
* Fingerprints are stored only in Section 7 (Ember Sanctum), never locally.

---

## Summary

This update ensures LovDev.ai Premium+ users benefit from Hotbox-based agent simulations and soul-bound feedback loops without violating incorruptibility protocols or user transparency.

Hotboxes remain invisible, but their influence becomes foundational.
