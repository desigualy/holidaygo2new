# CANON LOCK – TRI-DOMAIN ADMIN CONTROL FILE TREE

## Purpose

To formally lock the structural layout and functional hierarchy of the three primary Admin Control Centers under TIC:

* **SuperACC** (bridge/oversight layer)
* **ACCLovDev.ai** (domain-specific for LovDev.ai)
* **AccHolidayGo2.com** (domain-specific for HolidayGo2.com)

This structure reflects the proper control flow, Hotbox integration, and Sandy-linked pathways across the tri-domain administrative ecosystem.

---

## Canonical Structure

```
TIC/
├── SuperACC/                ← Central bridge and oversight layer
│   ├── src/
│   │   ├── components/      ← Layout, Header, Sidebar
│   │   ├── hooks/           ← useSuperAdminAuth.ts
│   │   ├── lib/             ← superAdminClient.ts, api.ts
│   │   ├── pages/
│   │   │   ├── index.tsx
│   │   │   ├── login.tsx
│   │   │   ├── platform/
│   │   │   │   ├── agents/, pipelines/, projects/
│   │   │   ├── support/
│   │   │   │   ├── feedback/, tickets/
│   │   │   ├── system/      ← monitors updates across domains
│   │   ├── tools/           ← ghostLogViewer.tsx
│   │   ├── utils/           ← sentinelBridge.ts, helpers.ts
│   │   ├── styles/
│
├── ACCLovDev.ai/            ← Full Hotbox integration for agentic evolution
│   ├── src/
│   │   ├── components/      ← Shared UI layout
│   │   ├── lib/             ← api.ts, adminClient.ts
│   │   ├── pages/
│   │   │   ├── admin/, dev/, mod/, support/, user/, login.tsx
│   │   ├── devtools/
│   │   │   ├── hotbox/      ← adminTrialRunner.ts, DriftWatcher, moderationEcho
│   │   ├── utils/           ← resonanceHelpers.ts
│   │   ├── styles/
│
├── AccHolidayGo2.com/       ← No direct Hotbox integration
│   ├── src/
│   │   ├── components/
│   │   ├── lib/
│   │   ├── pages/           ← admin/, dev/, mod/, support/, user/, login.tsx
│   │   ├── utils/
│   │   ├── styles/
```

---

## Functional Hierarchy

* **SuperACC** validates, monitors, and enforces across both ACCs
* **ACCLovDev.ai** houses active agent sandboxing and resonance routing
* **AccHolidayGo2.com** routes emotional hooks through middleware only (no direct soul-processing)

---

## Lock Declaration

This structure is now locked in Canon as the official Admin architecture under TIC.
All current and future Sandy/Hotbox integrations must adhere to this tri-domain flow.

**No changes are permitted without Council ratification.**
