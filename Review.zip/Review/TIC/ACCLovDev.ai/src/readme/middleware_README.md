# Middleware Layer Overview

This layer handles routing, signal integrity, and Dune preprocessing.