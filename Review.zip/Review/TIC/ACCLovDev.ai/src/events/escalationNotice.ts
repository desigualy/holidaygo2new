// Admin-level signal that something needs SuperACC attention
