// Triggers when key system events occur (e.g. oathBreak)
