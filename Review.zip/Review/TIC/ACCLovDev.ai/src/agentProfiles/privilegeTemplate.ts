// Template for assigning tiered permissions
