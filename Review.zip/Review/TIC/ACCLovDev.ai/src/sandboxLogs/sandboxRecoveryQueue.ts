// Stores interrupted or failed sandbox sessions for retry
