// Logs agent interactions and command history
