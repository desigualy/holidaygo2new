// Captures timestamped session activity for review
