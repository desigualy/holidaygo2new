// Renders access gate for locked features
