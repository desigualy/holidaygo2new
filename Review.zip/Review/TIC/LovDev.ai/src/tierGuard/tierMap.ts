// Maps tier levels to feature flags
