// Parses emotional tone from user-agent input
