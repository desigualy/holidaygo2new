// Entry point to initiate Hotbox session
