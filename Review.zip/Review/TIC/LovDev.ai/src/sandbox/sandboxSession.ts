// Handles sandbox session metadata and timing
