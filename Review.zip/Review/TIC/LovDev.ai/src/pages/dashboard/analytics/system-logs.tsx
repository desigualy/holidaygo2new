export default function Placeholder() {
  return <div>This is system-logs page.</div>;
}