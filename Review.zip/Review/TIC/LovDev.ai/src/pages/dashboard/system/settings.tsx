export default function Placeholder() {
  return <div>This is settings page.</div>;
}