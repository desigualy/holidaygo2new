// Logs frequency degradation or failed recoveries
