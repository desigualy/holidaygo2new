// Stillness-aligned Dune handler
