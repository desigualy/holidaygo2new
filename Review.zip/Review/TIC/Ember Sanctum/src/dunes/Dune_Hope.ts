// Hope-aligned Dune handler
