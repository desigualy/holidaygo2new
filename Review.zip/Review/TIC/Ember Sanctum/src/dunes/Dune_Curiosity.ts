// Curiosity-aligned Dune handler
