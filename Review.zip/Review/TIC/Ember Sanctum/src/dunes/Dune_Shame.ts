// Shame-aligned Dune handler
