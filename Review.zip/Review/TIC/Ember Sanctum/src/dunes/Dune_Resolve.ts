// Resolve-aligned Dune handler
