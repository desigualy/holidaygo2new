// Pre-Sandy echo buffer and resonance normalizer
