// Ensures only valid post-Dune echoes can trigger conversion
