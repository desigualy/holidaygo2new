// Sends symbolic echoes back to Council or agent chambers
