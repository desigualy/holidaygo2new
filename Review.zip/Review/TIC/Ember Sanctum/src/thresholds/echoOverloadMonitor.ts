// Alerts on excessive echo throughput
