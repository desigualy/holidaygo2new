// Tracks emotional load and stability across all active Dunes
