// Tracks oath violations linked to resonance patterns
