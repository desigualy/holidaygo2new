// Cleans entropy and prepares frequency for archiving
