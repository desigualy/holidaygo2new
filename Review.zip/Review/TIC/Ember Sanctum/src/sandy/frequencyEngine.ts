// Final resonance converter, filters and hashes frequency
