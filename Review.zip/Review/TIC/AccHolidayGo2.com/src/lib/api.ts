export const apiClient = {
  get: () => {},
  post: () => {}
};