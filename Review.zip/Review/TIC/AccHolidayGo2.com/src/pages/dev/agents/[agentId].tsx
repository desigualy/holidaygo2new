export default function Placeholder() {
  return <div>This is [agentId] page.</div>;
}