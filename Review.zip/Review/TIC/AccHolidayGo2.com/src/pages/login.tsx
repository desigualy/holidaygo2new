export default function Placeholder() {
  return <div>This is login page.</div>;
}