export default function Placeholder() {
  return <div>This is updates page.</div>;
}