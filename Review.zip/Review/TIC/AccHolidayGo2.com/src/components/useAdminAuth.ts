export function useAdminAuth() {
  return { user: null };
}