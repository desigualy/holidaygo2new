export default function FlightResults() {
  return <div>FlightResults works!</div>;
}