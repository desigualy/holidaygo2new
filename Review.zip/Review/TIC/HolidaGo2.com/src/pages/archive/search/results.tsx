export default function LegacyResults() {
  return <div>LegacyResults (deprecated)</div>;
}