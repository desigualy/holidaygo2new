export default function Placeholder() {
return <div>This is font-adjustments page.</div>;
}