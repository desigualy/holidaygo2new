export default function Placeholder() {
return <div>This is [entryId] page.</div>;
}