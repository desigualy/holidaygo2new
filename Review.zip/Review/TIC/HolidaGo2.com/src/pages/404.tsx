export default function Placeholder() {
return <div>This is 404 page.</div>;
}