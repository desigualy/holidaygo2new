export default function PackageDetails() {
  return <div>PackageDetails works!</div>;
}