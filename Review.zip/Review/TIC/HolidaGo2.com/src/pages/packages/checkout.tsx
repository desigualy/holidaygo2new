export default function PackageCheckout() {
  return <div>PackageCheckout works!</div>;
}