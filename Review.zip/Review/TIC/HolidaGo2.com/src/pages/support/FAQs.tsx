export default function SupportFAQs() {
  return <div>SupportFAQs works!</div>;
}