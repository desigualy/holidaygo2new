export default function Placeholder() {
return <div>This is results page.</div>;
}