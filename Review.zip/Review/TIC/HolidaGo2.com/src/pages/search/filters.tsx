export default function Placeholder() {
return <div>This is filters page.</div>;
}