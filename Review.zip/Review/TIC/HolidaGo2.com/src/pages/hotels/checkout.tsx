export default function HotelCheckout() {
  return <div>HotelCheckout works!</div>;
}