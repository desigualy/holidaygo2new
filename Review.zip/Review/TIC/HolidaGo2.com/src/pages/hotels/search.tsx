export default function HotelSearch() {
  return <div>HotelSearch works!</div>;
}