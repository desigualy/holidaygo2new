// gb placeholder
