import React from 'react';

const Navbar: React.FC = () => {
  return (
    <nav className="navbar">
      <div className="logo">LovDev.ai</div>
      <div className="nav-actions">
        {/* Future: Auth status, user menu */}
      </div>
    </nav>
  );
};

export default Navbar;
