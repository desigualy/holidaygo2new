import React from 'react';
import { Link } from 'react-router-dom';

const Sidebar: React.FC = () => {
  return (
    <aside className="sidebar">
      <ul>
        <li><Link to="/dashboard">Dashboard</Link></li>
        <li><Link to="/dashboard/agents">Agents</Link></li>
        <li><Link to="/dashboard/analytics">Analytics</Link></li>
        <li><Link to="/dashboard/system">System</Link></li>
        <li><Link to="/dashboard/support">Support</Link></li>
      </ul>
    </aside>
  );
};

export default Sidebar;
