import React from 'react';

const IndexPage: React.FC = () => {
  return (
    <section className="public-home">
      <h1>Welcome to LovDev.ai</h1>
      <p>Build meaningful connections. Start now.</p>
    </section>
  );
};

export default IndexPage;
