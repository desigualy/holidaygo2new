import React from 'react';
export default function DashboardHome() {
  return <h2>Dashboard Overview</h2>;
}
