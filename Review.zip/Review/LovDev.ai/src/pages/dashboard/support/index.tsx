import React from 'react';
export default function SupportHome() {
  return <h3>Support Overview</h3>;
}
