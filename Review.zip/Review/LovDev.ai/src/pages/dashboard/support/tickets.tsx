import React from 'react';
export default function SupportTickets() {
  return <h3>Support Tickets</h3>;
}
