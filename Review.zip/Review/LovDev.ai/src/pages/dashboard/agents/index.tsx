import React from 'react';
export default function AgentsList() {
  return <h3>Agents Directory</h3>;
}
