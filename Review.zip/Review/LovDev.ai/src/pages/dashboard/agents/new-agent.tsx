import React from 'react';
export default function NewAgent() {
  return <h3>Create New Agent</h3>;
}
