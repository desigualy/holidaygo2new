import React from 'react';
import { useParams } from 'react-router-dom';

export default function AgentDetail() {
  const { agentId } = useParams();
  return <h3>Details for Agent: {agentId}</h3>;
}
