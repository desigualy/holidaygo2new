import React from 'react';
export default function AnalyticsHome() {
  return <h3>Analytics Dashboard</h3>;
}
