import React from 'react';
export default function SystemLogs() {
  return <h3>System Logs</h3>;
}
