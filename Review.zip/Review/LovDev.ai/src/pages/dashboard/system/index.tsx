import React from 'react';
export default function SystemHome() {
  return <h3>System Overview</h3>;
}
