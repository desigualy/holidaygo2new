import React from 'react';
export default function SystemUpdates() {
  return <h3>System Updates</h3>;
}
