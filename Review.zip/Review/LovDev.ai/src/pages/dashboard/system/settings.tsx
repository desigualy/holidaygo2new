import React from 'react';
export default function SystemSettings() {
  return <h3>System Settings</h3>;
}
