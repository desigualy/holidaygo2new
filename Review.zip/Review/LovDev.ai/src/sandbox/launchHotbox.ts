import { checkTierAccess } from '../tierGuard/checkTierAccess';
import { createSandboxSession } from './sandboxSession';

export async function launchHotbox(userId: string, tier: string) {
  const hasAccess = checkTierAccess(tier);
  if (!hasAccess) throw new Error('Hotbox access denied');

  const session = createSandboxSession(userId);
  return session;
}
