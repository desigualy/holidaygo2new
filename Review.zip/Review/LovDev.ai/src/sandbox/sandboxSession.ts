import { createMeta } from './sandboxMeta';

export function createSandboxSession(userId: string, emotion: string = 'focus') {
  const meta = createMeta(userId, emotion);
  const end = () => ({ ...meta, endedAt: Date.now(), durationMs: Date.now() - meta.startedAt });
  return { ...meta, end };
}
