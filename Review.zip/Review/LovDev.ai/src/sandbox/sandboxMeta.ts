export interface SandboxMeta {
  userId: string;
  emotion: string;
  originTrace: string;
  startedAt: number;
}

export function createMeta(userId: string, emotion: string): SandboxMeta {
  return {
    userId,
    emotion,
    originTrace: `${userId}-${Date.now()}`,
    startedAt: Date.now(),
  };
}
