# Hotbox Flow

1. User triggers via Premium access
2. Emotional session launched
3. Echo routed to Middleware