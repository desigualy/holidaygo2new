# Premium+ Access Policy

Only PremiumPlus users may initiate live Hotbox sessions.