export function parseTone(text: string): string {
  if (text.includes('sorry') || text.includes('anxious')) return 'anxiety';
  if (text.includes('great') || text.includes('awesome')) return 'joy';
  if (text.includes('wait') || text.includes('calm')) return 'calm';
  return 'focus';
}
