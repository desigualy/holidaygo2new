export function tagResonance(input: string, userId: string) {
  const timestamp = Date.now();
  const traceId = `${userId}-${timestamp}`;
  return {
    tag: 'emotionalSignal',
    payload: {
      text: input,
      intensity: Math.random().toFixed(2),
      originTrace: traceId,
    }
  };
}
