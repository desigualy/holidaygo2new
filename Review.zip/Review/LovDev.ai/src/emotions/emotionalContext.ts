export const emotionalContextMap = {
  joy: { color: 'emerald', icon: 'smile', intensity: 0.8 },
  anxiety: { color: 'red', icon: 'alert-triangle', intensity: 0.9 },
  calm: { color: 'blue', icon: 'cloud', intensity: 0.5 },
  focus: { color: 'amber', icon: 'target', intensity: 0.7 },
};
