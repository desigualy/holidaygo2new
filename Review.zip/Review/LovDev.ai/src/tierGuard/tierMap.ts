export const tierMap: Record<string, { hotbox: boolean }> = {
  Free: { hotbox: false },
  Premium: { hotbox: false },
  PremiumPlus: { hotbox: true },
};
