import { tierMap } from './tierMap';

export function checkTierAccess(tier: string): boolean {
  return tierMap[tier]?.hotbox === true;
}
