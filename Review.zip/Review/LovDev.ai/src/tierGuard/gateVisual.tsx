import React from 'react';

interface Props {
  message?: string;
}

const GateVisual: React.FC<Props> = ({ message = "Upgrade to access this feature." }) => {
  return (
    <div className="gate-visual">
      <p>{message}</p>
    </div>
  );
};

export default GateVisual;
