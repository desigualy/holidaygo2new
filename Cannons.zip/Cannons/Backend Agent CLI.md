#!/usr/bin/env bash

# === BackendAgent CLI Generator ===
# Generates Express.js backend from project_config.json

CONFIG_FILE="project_config.json"
PROJECT_NAME="backend"
SRC_DIR="$PROJECT_NAME/src"

# Step 1: Validate Config
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "[BackendAgent] Error: project_config.json not found."
  exit 1
fi

# Step 2: Parse Config
PROJECT_TITLE=$(jq -r .project_name $CONFIG_FILE)
FEATURES=$(jq -r '.features[]' $CONFIG_FILE)

# Step 3: Create File Structure
mkdir -p $SRC_DIR/{routes,controllers,middleware,utils}

# Step 4: Create index.ts
cat <<EOF > $SRC_DIR/index.ts
import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

app.use(cors());
app.use(express.json());

// Routes
$(for feature in $FEATURES; do echo "import ${feature}Routes from './routes/${feature}.routes'; app.use('/api/${feature}', ${feature}Routes);"; done)

app.get('/health', (req, res) => res.send('API is live'));

app.listen(PORT, () => console.log(`Server running on port ${PORT}`));
EOF

# Step 5: Generate Routes + Controllers
for feature in $FEATURES; do
  # Route file
  cat <<EOF > $SRC_DIR/routes/${feature}.routes.ts
import express from 'express';
import { handle${feature^} } from '../controllers/${feature}.controller';

const router = express.Router();

router.get('/', handle${feature^});

export default router;
EOF

  # Controller file
  cat <<EOF > $SRC_DIR/controllers/${feature}.controller.ts
export const handle${feature^} = async (req, res) => {
  res.send({ feature: '${feature}', status: 'Working!' });
};
EOF

  echo "[BackendAgent] Created route/controller: ${feature}"
done

# Step 6: Middleware
cat <<EOF > $SRC_DIR/middleware/error.middleware.ts
export function errorHandler(err, req, res, next) {
  console.error(err.stack);
  res.status(500).send({ error: 'Something went wrong!' });
}
EOF

# Step 7: .env.example
cat <<EOF > $PROJECT_NAME/.env.example
PORT=5000
DB_URL=postgres://localhost:5432/${PROJECT_TITLE}
JWT_SECRET=changeme
EOF

# Step 8: tsconfig.json
cat <<EOF > $PROJECT_NAME/tsconfig.json
{
  "compilerOptions": {
    "target": "ESNext",
    "module": "CommonJS",
    "rootDir": "./src",
    "outDir": "./dist",
    "strict": true,
    "esModuleInterop": true,
    "forceConsistentCasingInFileNames": true
  }
}
EOF

# Step 9: package.json
cat <<EOF > $PROJECT_NAME/package.json
{
  "name": "$PROJECT_TITLE-backend",
  "version": "1.0.0",
  "scripts": {
    "dev": "ts-node src/index.ts"
  },
  "dependencies": {
    "cors": "^2.8.5",
    "dotenv": "^16.0.0",
    "express": "^4.18.2"
  },
  "devDependencies": {
    "ts-node": "^10.0.0",
    "typescript": "^5.0.0"
  }
}
EOF

echo "[BackendAgent] Backend scaffold complete."
exit 0
