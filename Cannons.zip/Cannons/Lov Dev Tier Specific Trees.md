## LovDev.ai Tier-Specific File Access Trees

These trees reflect the **actual accessible routes and components per tier** based on current and planned functionality. Logic enforcement is handled via `useTierAccess.ts` and `AccessControlWrapper.tsx`.

---

### FREE TIER
```
LovDev.ai/
  pages/
    index.tsx
    login.tsx
    register.tsx
    accessibility/
      speech-to-text.tsx
    dashboard/
      index.tsx
      agents/
        index.tsx (read-only)
        [agentId].tsx (read-only)
      dreamspace/
        echo.tsx
      tiers/
        free.tsx
```

---

### PREMIUM TIER
```
LovDev.ai/
  pages/
    index.tsx
    login.tsx
    register.tsx
    accessibility/
      speech-to-text.tsx
    dashboard/
      index.tsx
      agents/
        index.tsx
        [agentId].tsx
        new-agent.tsx
      analytics/
        index.tsx
        performance.tsx
      support/
        index.tsx
        tickets.tsx
      system/
        index.tsx
        settings.tsx
        updates.tsx
      dreamspace/
        interactive.tsx (partial prompt access)
      oracle/
        resonance-log.tsx (silent only)
      architect/
        schema-review.tsx (passive)
      tiers/
        premium.tsx
```

---

### PREMIUM PLUS TIER
```
LovDev.ai/
  pages/
    index.tsx
    login.tsx
    register.tsx
    accessibility/
      speech-to-text.tsx
    dashboard/
      index.tsx
      agents/
        index.tsx
        [agentId].tsx
        new-agent.tsx
      analytics/
        index.tsx
        performance.tsx
        system-logs.tsx
      support/
        index.tsx
        tickets.tsx
      system/
        index.tsx
        settings.tsx
        updates.tsx
      dreamspace/
        interactive.tsx (full access)
      oracle/
        resonance-log.tsx
        stabilizer.tsx
      ark/
        konstruct.tsx
        builder.tsx
      architect/
        schema-review.tsx
        validator.tsx
      gb/
        momentum-check.tsx
        trigger.tsx
      tiers/
        premium-plus.tsx
```

---

These trees canonize the **actual user-visible structure** per tier, ensuring access separation, emotional safety, and progressive empowerment across LovDev.ai.

