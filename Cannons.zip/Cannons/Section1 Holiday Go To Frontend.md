# Section 1 Canon: HolidayGoTo.com Front-End

## Canonical Role in the Pantheon Ecosystem
Section 1 represents the **public-facing front-end platform** of HolidayGoTo.com within the broader Pantheon Ecosystem. It is the primary user interface for travelers and guests to discover, plan, and book their journeys in real-time, assisted by a curated team of AI agents and backed by Supabase-powered infrastructure.

This section is **isolated from administrative control domains**, operates independently of backend logic layers, and serves as the main conduit for user engagement.

---

## Purpose
The purpose of the HolidayGoTo.com front end is to:

- Provide users with a seamless, intelligent, and immersive travel planning experience.
- Act as a conversational and interactive AI companion for booking, discovery, and customization.
- Serve as the surface layer for itinerary management, price prediction, and inspirational exploration.
- Maintain performance, resilience, and accessibility while supporting dynamic routing and fallback systems.

---

## Technical Composition
- **Framework**: React 18 + Vite
- **Styling**: Tailwind CSS + shadcn/ui
- **Backend Integration**: Supabase client for real-time data access
- **Routing**: React Router with guarded routes and layered layouts
- **State Management**: useContext, React Query, and middleware hooks
- **Offline Mode**: Service worker + edge-cached offline journey support
- **Accessibility**: WCAG-friendly with voice, font, and simplified view modes
- **Progressive Web App (PWA)**: Offline installable functionality, background sync, and local data caching
- **Dark/Light Mode Toggle**: User-preferred theme setting persisted across sessions
- **iOS-Styled Button Standards**: Blue buttons (#007AFF) with focus-state awareness across mobile and desktop modals
- **Smart UX Visibility Logic**: Calendar, date pickers, and form inputs auto-adapt visibility based on contrast and theme mode

---

## Canonical Agents (User-Visible Only)
Only the following agents are authorized to appear within the front-end experience of HolidayGoTo.com:

### 1. **Ch@**
- Male conversational interface
- Handles query parsing, booking hand-offs, and mood-aware support

### 2. **Ms. Trav-Elle**
- Concierge-style itinerary planner
- Designs dream trip paths and offers emotionally intelligent itinerary guidance

### 3. **Troll**
- Defensive response agent
- Handles mischievous or malformed input with wit and corrective interaction

### 4. **Cart-Elle & Carter**
- The Mapseer Pair
- Carter presents geo-spatial trip views
- Cart-Elle provides emotional and atmospheric overlays of the destination experience

### 5. **The Oracle**
- Silent analytical agent
- Provides price trend matrices and predictive booking advice
- Visual only (CMatrix); non-verbal, non-interactive

---

## Agent Interactions and Roles
- **All agents** operate within strict domain boundaries.
- **No admin-tier agents** may appear within Section 1.
- **Fallback interactions** with Captain Failsafe or DogsBod-i occur only under rare, high-priority exceptions.
- **Visual indicators** of system agents (e.g., Maplings or Patchlings) may exist in future non-verbal UI states, but not during standard usage.

---

## Functional Highlights
[...All prior features remain unchanged and are included here...]

- **Dual FAQ Modules**:
  - `Faq.tsx`: Static accordion-based onboarding version
  - `FAQs.tsx`: Searchable, AI-augmented support system with semantic query handling
- **Packages Explorer with Segment Tabs**:
  - Tab-based filtering for All / Luxury / Family / Couples
  - Integrated with AI recommendation system, BladeBook, and itinerary personalization tools

---

## Developer Tools (Access-Controlled)

### **Geek Mode Developer Console**
- Available at `/dev/geek-mode` (RBAC restricted)
- Features:
  - JWT/session inspector
  - Query cache purge
  - Theme toggles
  - Edge function call testing
  - Developer-only performance HUD (planned)

### **Agent Introspect Console (Planned)**
- Query agents for reasoning (e.g., “Why was this option suggested?”)
- Returns:
  - Agent log trail
  - Fallback causes
  - Directive stack traces
- Protected feature for dev/admin roles only

### **Agent Debug Panel with Memory Visualizer**
- Route: `/admin/agent-debug`
- Features:
  - Live context/state viewer per agent
  - Role override and fallback simulation tools
  - Memory dump access for agent memory state verification

### **Agent Health Panel with Fallback Intelligence**
- Planned feature at `/dev/agent-health`
- Features:
  - Real-time load monitoring per agent
  - Fallback detection and substitution history
  - Trigger-based recovery visualizations and telemetry hooks

---

## Summary
Section 1 is a modular, intelligent, user-first travel interface. It is not a marketing layer—it is a functional, AI-mediated journey planner designed to offer precision, personality, and trust through agentic collaboration. It is where dreams begin, guided not by static forms, but by helpful digital beings tuned to each user’s intent.

