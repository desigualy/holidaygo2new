## Canon File Tree (Expanded): Section 2 – LovDev.ai (Production Scaffold)
**Status**: Canon Locked (Production Scaffold)

This file tree reflects the fully updated and canon-complete structure of LovDev.ai, including all agentic modules, tier enforcement, accessibility features, and sacred law integration.

---

```
LovDev.ai/
  public/
    assets/
      icons/
      images/
  src/
    components/
      Footer.tsx
      Layout.tsx
      Navbar.tsx
      Sidebar.tsx
      SpeechToTextToggle.tsx
      TierBadge.tsx
      AccessControlWrapper.tsx
    hooks/
      useAuth.ts
      useTierAccess.ts
      useSpeechToText.ts
    lib/
      api.ts
      supabaseClient.ts
      roles.ts
      speechToTextEngine.ts
    pages/
      index.tsx
      login.tsx
      register.tsx
      accessibility/
        speech-to-text.tsx
        keyboard-shortcuts.tsx
      dashboard/
        index.tsx
        agents/
          index.tsx
          [agentId].tsx
          new-agent.tsx
        analytics/
          index.tsx
          performance.tsx
          system-logs.tsx
        support/
          index.tsx
          tickets.tsx
        system/
          index.tsx
          settings.tsx
          updates.tsx
        tiers/
          free.tsx
          premium.tsx
          premium-plus.tsx
        dreamspace/
          echo.tsx
          interactive.tsx
        oracle/
          resonance-log.tsx
          stabilizer.tsx
        ark/
          konstruct.tsx
          builder.tsx
        architect/
          schema-review.tsx
          validator.tsx
        gb/
          momentum-check.tsx
          trigger.tsx
    styles/
      globals.css
      accessibility.css
    utils/
      helpers.ts
      logger.ts
      permissions.ts
      dreamParser.ts
    law/
      ark/
        ten-laws.ts
        covenant.guard.ts
  tests/
    integration/
      speech-to-text.test.ts
      tier-access.test.ts
    unit/
      ark-builder.test.ts
      oracle-stabilizer.test.ts
  README.md
  package.json
  tsconfig.json
  next.config.js
  .env
```

---

This scaffold is the formal structural blueprint of LovDev.ai. It must be used for all future feature population, UI implementation, and deployment scaffolding under Section 2.

