# HolidayGo2.com — Final Reviewed Frontend Layout (Canon Locked)

## Folder: `public_domains/HolidayGo2.com/src/pages/`

```
src/pages/
├── index.tsx                            # Homepage
├── search/
│   ├── index.tsx                        # Search Landing Page
│   ├── results.tsx                      # Search Results Page
│   └── filters.tsx                      # Search Filters Page
├── deals.tsx                             # Travel Deals Page
├── itinerary/
│   ├── index.tsx                        # Itinerary Overview
│   ├── view/[tripId].tsx                # View Specific Itinerary
│   └── edit/[tripId].tsx                # Edit Specific Itinerary
├── login.tsx                             # Login Page
├── register.tsx                          # Registration Page
├── profile/
│   ├── index.tsx                        # Profile Dashboard
│   ├── settings.tsx                     # User Settings
│   ├── history.tsx                      # Travel History
│   ├── bookings/
│   │   ├── index.tsx                    # View All Bookings
│   │   ├── [bookingId].tsx              # View Specific Booking
│   │   └── cancel/[bookingId].tsx       # Cancel Specific Booking
├── forum/
│   ├── index.tsx                        # Forum Main Page
│   ├── new-post.tsx                     # Create New Forum Post
│   └── topic/[topicId].tsx              # View Specific Forum Topic
├── bladebook/
│   ├── index.tsx                        # BladeBook Main Page
│   ├── new-entry.tsx                    # Create New BladeBook Entry
│   └── entry/[entryId].tsx              # View Specific BladeBook Story
├── support/
│   ├── index.tsx                        # Support Main Page
│   ├── new-ticket.tsx                   # Create New Support Ticket
│   └── tickets.tsx                      # View Support Tickets
├── accessibility/
│   ├── index.tsx                        # Accessibility Settings Main Page
│   ├── voice-control.tsx                # Voice Control Settings
│   └── font-adjustments.tsx             # Font and UI Adjustments
├── seasonal-alerts.tsx                   # Seasonal Travel Alerts
├── offline-mode/
│   ├── index.tsx                        # Offline Mode Overview
│   ├── trips.tsx                        # Saved Trips for Offline Access
│   └── errors.tsx                       # Offline Error Handling
├── 404.tsx                               # 404 Not Found Page
├── maintenance.tsx                       # Maintenance Mode Page
├── upgrade-required.tsx                  # Force Upgrade Notification Page
```

---

# Canon Lock Statement

As of this moment,
the above `src/pages/` structure for `HolidayGo2.com`
is hereby locked into the Pantheon Canon Playbook
as the **Final Reviewed Frontend Layout for the HolidayGo2.com Platform**.

No structural changes are permitted without an official Canon Update Ritual.
