#!/usr/bin/env bash

# === DBAgent CLI Generator ===
# Generates Supabase-compatible SQL schema and .env file from project_config.json

CONFIG_FILE="project_config.json"
PROJECT_NAME="database"
SCHEMA_DIR="$PROJECT_NAME/schema"

# Step 1: Validate Config
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "[DBAgent] Error: project_config.json not found."
  exit 1
fi

# Step 2: Parse Config
PROJECT_TITLE=$(jq -r .project_name $CONFIG_FILE)
FEATURES=$(jq -r '.features[]' $CONFIG_FILE)

# Step 3: Create Directories
mkdir -p $SCHEMA_DIR

# Step 4: Base SQL Schema
cat <<EOF > $SCHEMA_DIR/base_schema.sql
-- Base users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  password TEXT NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);
EOF

# Step 5: Feature-Based Schema Extensions
for feature in $FEATURES; do
  case $feature in
    "calendar")
      cat <<EOF >> $SCHEMA_DIR/base_schema.sql

-- Calendar entries
CREATE TABLE calendar_events (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  title TEXT,
  date DATE,
  time TIME,
  created_at TIMESTAMP DEFAULT now()
);
EOF
      ;;
    "payment")
      cat <<EOF >> $SCHEMA_DIR/base_schema.sql

-- Payment transactions
CREATE TABLE payments (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id UUID REFERENCES users(id),
  amount DECIMAL,
  currency TEXT,
  status TEXT,
  created_at TIMESTAMP DEFAULT now()
);
EOF
      ;;
  esac
  echo "[DBAgent] Appended schema for feature: $feature"
done

# Step 6: .env.example
cat <<EOF > $PROJECT_NAME/.env.example
SUPABASE_URL=https://your-supabase-instance.supabase.co
SUPABASE_KEY=your-anon-key
EOF

echo "[DBAgent] Database schema and environment setup complete."
exit 0
