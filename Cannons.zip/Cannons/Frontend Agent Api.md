// === FrontendAgent API (Express + Node.js) ===
// Accepts JSON config and returns zipped frontend scaffold

const express = require('express');
const fs = require('fs');
const path = require('path');
const archiver = require('archiver');
const { execSync } = require('child_process');
const app = express();

app.use(express.json());

app.post('/generate/frontend', async (req, res) => {
  const config = req.body;
  const tempDir = path.join(__dirname, 'frontend_build');
  const outputZip = path.join(__dirname, 'frontend_output.zip');

  try {
    // Write config to file
    fs.mkdirSync(tempDir, { recursive: true });
    fs.writeFileSync(path.join(tempDir, 'project_config.json'), JSON.stringify(config, null, 2));

    // Run CLI generator script
    execSync(`bash ./FrontendAgent_CLI.sh`, { cwd: __dirname, stdio: 'inherit' });

    // Zip result
    const output = fs.createWriteStream(outputZip);
    const archive = archiver('zip', { zlib: { level: 9 } });
    archive.pipe(output);
    archive.directory(path.join(__dirname, 'frontend'), false);
    await archive.finalize();

    res.download(outputZip);
  } catch (err) {
    console.error('[FrontendAgent API] Error:', err);
    res.status(500).json({ error: 'Frontend generation failed' });
  }
});

app.listen(4001, () => console.log('FrontendAgent API listening on port 4001'));

// Note: Ensure `FrontendAgent_CLI.sh` exists and is executable
