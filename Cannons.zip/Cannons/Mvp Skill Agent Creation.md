## Lovdev.ai - MVP Skill Agent Creation

### Objective
Define and scaffold the first three MVP Skill Agents for ARC:
- FrontendAgent
- BackendAgent
- DBAgent

These agents will interpret task assignments from the Agentic Core and autonomously generate code, scaffold file structures, and manage their domain responsibilities during a build lifecycle.

---

### Agent 1: FrontendAgent

**Role:**
- Create user interface using React + TailwindCSS
- Apply design tokens from onboarding wizard
- Scaffold `pages/`, `components/`, `layouts/`

**Capabilities:**
- Reads `project_config.json` → UI schema
- Uses TailwindCLI or PostCSS middleware
- Can render base routing with React Router DOM
- Generates:
  - `App.tsx`
  - `main.tsx`
  - `index.css`
  - `pages/Home.tsx`, `Login.tsx`, etc.

**Output Example:**
```tsx
// Home.tsx
export default function Home() {
  return (
    <section className="p-4">
      <h1 className="text-3xl font-bold">Welcome to Your Travel App</h1>
    </section>
  );
}
```

---

### Agent 2: BackendAgent

**Role:**
- Build Node.js or NestJS backend services
- Handle REST API and optional GraphQL
- Set up routes, middleware, and service logic

**Capabilities:**
- Reads task requirements from intent parser
- Creates `routes/`, `controllers/`, `services/`
- Supports: Express.js (MVP), NestJS (Phase 2)
- Auto-generates:
  - `index.ts`
  - `routes/user.ts`
  - `controllers/auth.ts`
  - CORS + error middleware

**Output Example:**
```ts
// routes/user.ts
import express from 'express';
const router = express.Router();

router.get('/profile', (req, res) => {
  res.send({ name: 'User', role: 'guest' });
});

export default router;
```

---

### Agent 3: DBAgent

**Role:**
- Set up Supabase or PostgreSQL schema
- Interpret field-level logic from onboarding
- Seed data and manage migrations

**Capabilities:**
- Reads database structure from project_config
- Generates:
  - SQL migration files
  - Supabase `schema.prisma` or SQL DDL
  - `.env` with DB URL and API keys

**Output Example:**
```sql
-- users table
CREATE TABLE users (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  email TEXT UNIQUE NOT NULL,
  created_at TIMESTAMP DEFAULT now()
);
```

---

### Integration Plan
- Agents receive tasks from Agentic Core
- Operate inside isolated worker threads
- Return status + errors to Execution Sandbox
- Final state updates Walk-On Monitor

---

### Next Milestones
- Build actual generators (Front → Back → DB)
- Create fallback logic for schema validation
- Add self-healing if files are missing/incomplete
- Wrap agents into modular CLI tools or API endpoints

These MVP agents will give lovdev.ai a complete vertical execution chain from UI → API → DB, all via ARC’s instruction flow.

