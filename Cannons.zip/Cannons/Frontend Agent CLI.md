#!/usr/bin/env bash

# === FrontendAgent CLI Generator ===
# Generates React + Tailwind frontend from project_config.json

CONFIG_FILE="project_config.json"
PROJECT_NAME="frontend"
SRC_DIR="$PROJECT_NAME/src"

# Step 1: Validate Config
if [[ ! -f "$CONFIG_FILE" ]]; then
  echo "[FrontendAgent] Error: project_config.json not found."
  exit 1
fi

# Step 2: Parse Project Name
PROJECT_TITLE=$(jq -r .project_name $CONFIG_FILE)
FEATURES=$(jq -r '.features[]' $CONFIG_FILE)
DESIGN=$(jq -r .design_style $CONFIG_FILE)

# Step 3: Create File Structure
mkdir -p $SRC_DIR/{components,pages,layouts}
mkdir -p $PROJECT_NAME/public

# Step 4: Generate index.html
cat <<EOF > $PROJECT_NAME/public/index.html
<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="UTF-8" />
    <meta name="viewport" content="width=device-width, initial-scale=1.0" />
    <title>$PROJECT_TITLE</title>
  </head>
  <body>
    <div id="root"></div>
  </body>
</html>
EOF

# Step 5: Generate main.tsx
cat <<EOF > $SRC_DIR/main.tsx
import React from 'react';
import ReactDOM from 'react-dom/client';
import App from './App';
import './index.css';

ReactDOM.createRoot(document.getElementById('root')!).render(<App />);
EOF

# Step 6: Generate App.tsx
cat <<EOF > $SRC_DIR/App.tsx
import { BrowserRouter, Routes, Route } from 'react-router-dom';
import Home from './pages/Home';
$(for feature in $FEATURES; do echo "import ${feature^} from './pages/${feature^}';"; done)

export default function App() {
  return (
    <BrowserRouter>
      <Routes>
        <Route path="/" element={<Home />} />
        $(for feature in $FEATURES; do echo "<Route path='/${feature}' element={<${feature^} />} />"; done)
      </Routes>
    </BrowserRouter>
  );
}
EOF

# Step 7: Generate index.css
cat <<EOF > $SRC_DIR/index.css
@tailwind base;
@tailwind components;
@tailwind utilities;
EOF

# Step 8: Generate pages
cat <<EOF > $SRC_DIR/pages/Home.tsx
export default function Home() {
  return <div className="p-6 text-3xl">Welcome to $PROJECT_TITLE</div>;
}
EOF

for feature in $FEATURES; do
  FNAME="$SRC_DIR/pages/${feature^}.tsx"
  echo "export default function ${feature^}() { return <div className=\"p-6\">This is the ${feature^} page.</div>; }" > $FNAME
  echo "[FrontendAgent] Created page: ${feature^}.tsx"
done

# Step 9: Tailwind config
cat <<EOF > $PROJECT_NAME/tailwind.config.ts
export default {
  content: ['./src/**/*.{js,ts,jsx,tsx}'],
  theme: {
    extend: {},
  },
  plugins: [],
};
EOF

# Step 10: PostCSS config
cat <<EOF > $PROJECT_NAME/postcss.config.js
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
};
EOF

# Step 11: tsconfig.json
cat <<EOF > $PROJECT_NAME/tsconfig.json
{
  "compilerOptions": {
    "target": "ESNext",
    "useDefineForClassFields": true,
    "module": "ESNext",
    "moduleResolution": "Bundler",
    "strict": true,
    "jsx": "react-jsx",
    "baseUrl": "./src"
  },
  "include": ["src"]
}
EOF

echo "[FrontendAgent] Frontend scaffold complete."
exit 0
