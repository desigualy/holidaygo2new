# CANON LOCK – SECTION 4 MIDDLEWARE FILE TREE (SANDY + HOTBOXES)

## Purpose

To canonise the full, expanded file tree of the Middleware Layer with all active Sandy and Hotbox integrations. This structure supports sandbox deployments, session validation, and frequency fingerprint routing between all agent-facing systems and Section 7.

---

## Canonical File Tree Structure

```
TIC/Middleware/
├── src/
│   ├── agents/
│   │   ├── bridge/
│   │   │   ├── index.ts
│   │   │   ├── toneRouter.ts
│   │   ├── gb/
│   │   │   ├── cooldownGuard.ts
│   │   │   ├── trigger.ts
│   │   ├── minions/
│   │   │   ├── microtaskHub.ts
│   │   │   ├── swarmConfig.ts
│   │   ├── orwell/
│   │   │   ├── observerCore.ts
│   │   │   ├── orwellians/
│   │   │   │   ├── driftScanner.ts
│   │   │   │   ├── sentinel.ts
│   │   │   │   ├── transcriber.ts
│   │   ├── stevenSQL/
│   │   │   ├── gatekeeper.ts
│   │   │   ├── schemaValidator.ts
│   │   ├── watcher/
│   │   │   ├── anomalyLog.ts
│   │   │   ├── index.ts
│
│   ├── config/
│   │   ├── agentKeys.config.ts
│   │   ├── middleware.config.ts
│
│   ├── lib/
│   │   ├── emotionUtils.ts
│   │   ├── sessionGuard.ts
│   │   ├── tierMap.ts
│   │   ├── trustMatrix.ts
│
│   ├── logs/
│   │   ├── gbDisruptions.log
│   │   ├── oracleEchoes.log
│   │   ├── patchTriggers.log
│   │   ├── sttFailures.log
│   │   ├── tierEvents.log
│
│   ├── middleware/
│   │   ├── accessControl.ts
│   │   ├── agentIntegrityGuard.ts
│   │   ├── covenant.guard.ts
│   │   ├── gbQueue.ts
│   │   ├── oracleRelay.ts
│   │   ├── patchFallback.ts
│   │   ├── signalMultiplexer.ts
│   │   ├── sttGateway.ts
│   │   ├── tierRouter.ts
│   │   ├── resonanceRelay.ts
│
│   ├── rooms/
│   │   ├── anomalyVault.ts
│   │   ├── bridgeRoom.ts
│   │   ├── echoChamber.ts
│   │   ├── gbStagingRoom.ts
│   │   ├── resonanceRelay.ts
│   │   ├── sandboxDrop.ts
│   │   ├── schemaVault.ts
│
│   ├── utils/
│   │   ├── cooldown.ts
│   │   ├── eventTags.ts
│   │   ├── middlewareLog.ts
```

---

## Canon Declaration

This structure is now locked in Canon as the official routing and security layer connecting all frontend agent activity to Sandy’s soul-processing infrastructure.

Any updates to this file system must be reviewed and oath-cleared through Sentinel.

**This is the core of soul-safe system logic.**
